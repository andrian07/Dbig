<?php

namespace App\Models;

use CodeIgniter\Model;

class M_accounting extends Model
{
    protected $table = 'hd_journal';
    protected $DBGroup = 'accounting';
}
