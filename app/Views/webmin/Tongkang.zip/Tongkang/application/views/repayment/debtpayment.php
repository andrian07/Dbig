  <?php 
  
  define('DOC_ROOT_PATH', $_SERVER['DOCUMENT_ROOT'].'/');
  require DOC_ROOT_PATH . $this->config->item('headerlink');
  ?>


  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Pelunasan Hutang</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="<?php echo base_url(); ?>Admin">Home</a></li>
              <li class="breadcrumb-item active">Pelunasan Hutang</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>


    <!-- Main content -->
    <section class="content">

      <div class="row">
        <!-- /.col -->
        <div class="col-md-12">
          <div class="card">
            <div class="card-body">
              <form id="frmrepayment" data-an-count="1" data-an-form-handler="gblfn">
                <div class="row">
                  <div class="col-sm-12 col-md-3">
                    <?php foreach($datas['list_supplier_debt_supplier'] as $rows){ ?>
                      <!-- text input --> 
                      <div class="form-group">
                        <label>Nama Supplier</label>
                        <input id="supplier_id" name="supplier_id" type="hidden" class="form-control" value="<?php echo $rows->supplier_id; ?>" readonly="">
                        <input id="supplier_name" name="supplier_name" type="text" class="form-control" value="<?php echo $rows->supplier_name; ?>" readonly="">
                      </div>
                    </div>

                    <div class="col-sm-12 col-md-2">
                      <!-- text input -->
                      <div class="form-group">
                        <label>Tanggal Pembayaran</label>
                        <input id="repayment_date" name="repayment_date" type="date" class="form-control" value="<?php echo date('Y-m-d'); ?>">
                      </div>
                    </div>


                    <div class="col-sm-12 col-md-2">
                      <!-- text input -->
                      <div class="form-group">
                        <label>User</label>
                        <input id="display_user" type="text" class="form-control" value="Owner" readonly="">
                      </div>
                    </div>
                    <div class="col-sm-12 col-md-3">
                      <!-- text input -->
                      <div class="form-group">
                        <label>Total Hutang</label>
                        <input id="supplier_total_debt" name="supplier_total_debt" type="text" class="form-control text-right" value="Rp. <?php echo number_format($rows->total_debt); ?>" readonly="">
                      </div>
                    </div>
                  </div>
                <?php } ?>
              </form>
            </div><!-- /.card-body -->
          </div>
          <!-- /.card -->
        </div>
        <!-- /.col -->
      </div>

      <!-- Default box -->
      <div class="card">
        <div class="card-header">
          <div class="row">
            <input id="purchase_id" name="purchase_id" type="hidden" value="">

            <div class="col-sm-12 col-md-3">
              <!-- text input -->
              <div class="form-group">
                <label>No Invoice</label>
                <input id="purchase_invoice" type="text" name="purchase_invoice" class="form-control" readonly="">
              </div>
            </div>

            <div class="col-sm-12 col-md-4">
              <!-- text input -->
              <div class="form-group">
                <label>Tanggal Invoice</label>
                <input id="purchase_date" name="purchase_date" type="date" class="form-control" placeholder="Tanggal Invoice" value="" readonly="">
              </div>
            </div>



            <div class="col-sm-12 col-md-5">
              <!-- text input -->
              <div class="form-group">
                <label>Keterangan</label>
                <input id="repayment_remark" name="repayment_remark" type="text" class="form-control" value="" max-length="500">
              </div>
            </div>



            <div class="col-sm-12 col-md-3">
              <!-- text input -->
              <div class="form-group">
                <label>Saldo Hutang</label>
                <input id="remaining_debt" name="remaining_debt" type="text" class="form-control text-right" value="0" readonly="">
              </div>
            </div>

            <div class="col-sm-12 col-md-3">
              <!-- text input -->
              <div class="form-group">
                <label>Pembayaran</label>
                <input id="repayment_total" name="repayment_total" type="text" class="form-control text-right calculation" data-parsley-vrepaymenttotal="" value="0" required="">
              </div>
            </div>



            <div class="col-sm-12 col-md-5">
              <!-- text input -->
              <div class="form-group">
                <label>Sisa Hutang</label>
                <input id="new_remaining_debt" name="new_remaining_debt" type="text" class="form-control text-right" data-parsley-vnewdebt="" value="0" readonly="">
              </div>
            </div>


            <div class="col-sm-1">
              <!-- text input -->
              <label>&nbsp;</label>
              <div class="form-group">
                <div class="col-12">
                  <button id="btnadd_temp" class="btn btn-md btn-primary rounded-circle float-right"><i class="fas fa-plus"></i></button>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="card-body">
          <table id="example" class="table table-striped table-bordered dataTable no-footer" style="width:100%">
            <thead>
              <tr>
                <th>No Invoice</th>
                <th>Tanggal Invoice</th>
                <th>Saldo Hutang</th>
                <th>Pembayaran</th>
                <th>Sisa Hutang</th>
                <th>Aksi</th>
              </tr>
            </thead>
            <tbody>
              <?php foreach($datas['list_purchase_debt_temp'] as $row){ ?>
                <tr>
                  <td><?php echo $row->hd_purchase_invoice; ?></td>
                  <td><?php echo $row->hd_purchase_date; ?></td>
                  <td>Rp. <?php echo number_format($row->hd_purchase_debt_remaining); ?></td>
                  <td>Rp. <?php echo number_format($row->temp_debt_pay); ?></td>
                  <td>Rp. <?php echo number_format($row->hd_purchase_debt_remaining - $row->temp_debt_pay); ?></td>
                  <td>
                    <button class="btn btn-sm btn-warning table-menu edittemp" data-id="<?php echo $row->hd_purchase_id; ?>" data-title="Edit"><i class="fas fa-money-bill-wave"></i></button>
                  </td>
                </tr>
              <?php } ?>
            </tbody>
          </table>
        </div>
        <div class="row form-space">

          <div class="col-lg-6">

          </div>

          <div class="col-lg-6 text-right">

            <div class="form-group row">
              <label for="footer_total_pay" class="col-sm-7 col-form-label text-right:">Total Pembayaran:</label>
              <div class="col-sm-5">
                <input id="footer_total_pay" name="footer_total_pay" type="text" class="form-control text-right" value="0" readonly="">
              </div>
            </div>

            <div class="form-group row">
              <label for="footer_total_nota" class="col-sm-7 col-form-label text-right:">Jumlah Nota:</label>
              <div class="col-sm-5">
                <input id="footer_total_nota" name="footer_total_nota" type="text" class="form-control text-right" value="0" readonly="">
              </div>
            </div>



            <div class="form-group row">
              <div class="col-sm-12">
                <button id="btncancel" class="btn btn-danger"><i class="fas fa-times-circle"></i> Batal</button>
                <button id="btnsave" class="btn btn-success button-header-custom-save"><i class="fas fa-save"></i> Simpan</button>
              </div>
            </div>

          </div>


        </div>
        <!-- /.card-body -->

        <!-- /.card-footer-->
      </div>
      <!-- /.card -->

    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  <!-- /.content-wrapper -->

  <?php 
  require DOC_ROOT_PATH . $this->config->item('footerlink');
  ?>

  <script type="text/javascript">

   $(document).ready(function() {
    let remaining_debt = new AutoNumeric('#remaining_debt', { currencySymbol : 'Rp. ' });
    let repayment_total = new AutoNumeric('#repayment_total', { currencySymbol : 'Rp. ' });
    let new_remaining_debt = new AutoNumeric('#new_remaining_debt', { currencySymbol : 'Rp. ' });
    let footer_total_pay = new AutoNumeric('#footer_total_pay', { currencySymbol : 'Rp. ' });
    let footer_total_nota = new AutoNumeric('#footer_total_nota', 'integer');
    
    
    setfootervalue();

    $('.edittemp').click(function(e){
      e.preventDefault();
      let id = $(this).attr("data-id");
      console.log(id);
      $.ajax({
        type: "GET",
        dataType: "json",
        url: "<?php echo base_url(); ?>Repayment/get_debt_repayment?id="+id,
        success : function(data){
          if (data.code == "200"){
            let rows = data.result[0];
            $("#purchase_id").val(rows.hd_purchase_id);
            $("#purchase_invoice").val(rows.hd_purchase_invoice);
            $("#purchase_date").val(rows.hd_purchase_date);
            remaining_debt.set(rows.hd_purchase_debt_remaining);
            new_remaining_debt.set(rows.hd_purchase_debt_remaining);
          }else{
           Swal.fire(
            'Warning!',
            'Data Not Found',
            'warning'
            )
         }
       }
     });
    });

    $('#btnadd_temp').click(function(e){
      e.preventDefault();
      let purchase_id = $("#purchase_id").val();
      let purchase_invoice = $("#purchase_invoice").val();
      let repayment_remark = $("#repayment_remark").val();
      let repayment_total_val = parseFloat(repayment_total.getNumericString());
      let new_remaining_debt_val = parseFloat(new_remaining_debt.getNumericString());

      $.ajax({
        type: "POST",
        url: "<?php echo base_url(); ?>Repayment/processadddebt",
        dataType: "json",
        data: {purchase_id:purchase_id, purchase_invoice:purchase_invoice, repayment_remark:repayment_remark, repayment_total_val:repayment_total_val, new_remaining_debt_val:new_remaining_debt_val},
        success : function(data){
          if (data.code == "200"){
            location.reload();
            Swal.fire('Saved!', '', 'success');
          } else {
            Swal.fire({
              icon: 'error',
              title: 'Oops...',
              text: data.msg,
            })
          }
        }
      });
    });

    $('#btnsave').click(function(e){
      e.preventDefault();
      let supplier_id = $("#supplier_id").val();
      let repayment_date = $("#repayment_date").val();
      let footer_total_pay_val = parseFloat(footer_total_pay.getNumericString());
      let footer_total_nota_val = parseFloat(footer_total_nota.getNumericString());

      $.ajax({
        type: "POST",
        url: "<?php echo base_url(); ?>Repayment/processsavedebt",
        dataType: "json",
        data: {supplier_id:supplier_id, repayment_date:repayment_date, footer_total_pay_val:footer_total_pay_val, footer_total_nota_val:footer_total_nota_val},
        success : function(data){
          if (data.code == "200"){
            window.location.href = "<?php echo base_url(); ?>Repayment/debt";
            Swal.fire('Saved!', '', 'success');
          } else {
            Swal.fire({
              icon: 'error',
              title: 'Oops...',
              text: data.msg,
            })
          }
        }
      });
    });

    $(document).on('input', '.calculation', function(e) {
      e.preventDefault();
      let remaining_debt_cal = parseFloat(remaining_debt.getNumericString());
      let repayment_total_cal = parseFloat(repayment_total.getNumericString());
      new_remaining_debt.set(remaining_debt_cal - repayment_total_cal);
    });

    function setfootervalue(){
      $.ajax({
        type: "GET",
        dataType: "json",
        url: "<?php echo base_url(); ?>Repayment/getfooterdebt",
        success : function(data){
          if (data.code == "200"){
            let rows = data.result[0];
            footer_total_pay.set(rows.total_pay_footer); 
            footer_total_nota.set(rows.total_inv_footer);
          }
        }
      });
    }

  });
</script>