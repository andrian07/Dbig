
<!-- DEBUG-VIEW START 1 APPPATH/Views/webmin/purchase/purchaseorder_invoice.php -->
<!DOCTYPE html>
<html>
<head>


  <!-- Google Font: Source Sans Pro -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="<?php echo base_url(); ?>asset/plugins/invoice/invoice.css">
  <title></title>
</head>
<body>
  <div class="invoice-a4" style="margin-top:-30px;">
    <div class="letterhead">
      <div style="text-align: center;"> 
        <h2 style="text-decoration: underline; color:#000000">BUKTI PENGELUARAN</h2>
        <p style="margin-top:-20px; font-size: 15px;"><?php echo $datas['list_hd_expenditure'][0]->hd_expenditure_invoice; ?></p>
      </div>
    </div>

    <div class="content-invoice">
      <?php foreach($datas['list_hd_expenditure'] as $row) { ?>
        <div class="header-info">
        <div class="header-info-left">
        <table>
          <tr>
            <td>Posting</td><td>:</td><td>_______________</td>
          </tr>
          <tr>
            <td>Tanggal</td><td>:</td><td><?php $date = date_create($row->hd_expenditure_date); echo date_format($date,"d-M-Y"); ?></td>
          </tr>
        </table>
        </div>
        <div class="header-info-right">
        <table>
          <tr>
            <td>Nama</td><td>:</td><td style="text-transform: uppercase;"><?php echo $row->hd_expenditure_customer_name; ?></td>
          </tr>
          <tr>
            <td>Keterangan</td><td>:</td><td><?php echo $row->hd_expenditure_desc; ?></td>
          </tr>
        </table>
        </div>
      </div>
      <?php } ?>
      <table class="item">
        <thead>
         <tr>
          <th>No</th>
          <th width="65%;">Uraian</th>
          <th>Proyek</th>
          <th>Jumlah</th>
        </tr>
      </thead>
      <tbody>

       <?php 
       $i = 1;
       foreach($datas['list_dt_expenditure'] as $row){ ?>
        <tr>
          <td class="text-center"><?php echo $i ?></td>
          <td><?php echo $row->dt_expenditure_item ?></td>
          <td></td>
          <td class="text-center">Rp. <?php echo number_format($row->dt_expenditure_total) ?></td>
        </tr>
      <?php 
      $i ++;
      } ?>
      <?php
      $row_min = 9 - $datas['count_dt_expenditure'][0]->total_row;
       for($j = 1; $j < $row_min; $j++){ ?>
        <tr>
          <td class="text-center" style="height: 15px;"></td>
          <td></td>
          <td></td>
          <td></td>
        </tr>
      <?php 
      } ?>
    </tbody>
    <tfoot>
       <?php foreach($datas['list_hd_expenditure'] as $row) { ?>
      <tr>
        <td colspan="2" style="border: none;">Via Kas Besar PAT</td>
        <th>Total</th>
        <th class="text-center">Rp. <?php echo number_format($row->hd_expenditure_total) ?></th>
      </tr>
    <?php } ?>
    </tfoot>
  </table>

  <h3 style="font-size:17px; text-decoration: underline;">Terbilang:</h3>
  <i><p style="font-size:17px; text-decoration-style: italic; margin-top: -15px;"><?php echo $datas['terbilang']; ?> rupiah</p></i>
</div>

<table class="item" style="text-align:center;">
  <tr>
      <td width="25%">Fiat <br /><br /><br /><br /><br />
      (&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;)
      </td>
      <td width="25%">Kasir<br /><br /><br /><br /><br />
      (&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;)
      </td>
      <td width="25%">Penerima<br /><br /><br /><br /><br />
      (&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;)</td>
      <td width="25%">Pembukuan<br /><br /><br /><br /><br />
      (&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;)</td>
  </tr>
</table>
<p>Printed By: <?php echo $_SESSION['user_name'] ?>(<?php echo date("d/m/Y H:i:s") ?>)</p>
</div>
</body>
</html>
<!-- DEBUG-VIEW ENDED 1 APPPATH/Views/webmin/purchase/purchaseorder_invoice.php -->
