  <?php 
  
  define('DOC_ROOT_PATH', $_SERVER['DOCUMENT_ROOT'].'/');
  require DOC_ROOT_PATH . $this->config->item('headerlink');
  ?>

  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Input Pengeluaran</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="<?php echo base_url(); ?>Admin">Home</a></li>
              <li class="breadcrumb-item active">Input Pengeluaran</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="card card-default">
        <div class="card-header">
          <h3 class="card-title">Form Input Pengeluaran</h3>

          <div class="card-tools">
            <button type="button" class="btn btn-tool" data-card-widget="collapse">
              <i class="fas fa-minus"></i>
            </button>
          </div>
        </div>
        <!-- /.card-header -->

        <div class="card-body">

          <div class="row">
            <div class="col-md-4">
              <div class="form-group">
                <label class="col-form-label">No Invoice:</label>
                <?php if (isset($_GET['id']) != null){ ?>
                  <input type="hidden" id="po_id" class="form-control" value="<?php echo $_GET['id']; ?>" readonly="">
                <?php  }else{ ?>
                  <input type="hidden" id="po_id" class="form-control" value="" readonly="">
                <?php } ?>
                <input type="text" id="hd_po_invoice" class="form-control" value="AUTO" readonly="">
              </div>
              <div class="row">
                <div class="col-md-12">
                  <div class="form-group">
                    <label class="col-form-label">Tanggal:</label>
                    <input type="date" class="form-control" id="date" value="<?php echo date("Y-m-d");   ?>">
                  </div>
                </div>
              </div>
            </div>
            <div class="col-md-4">
              <div class="row">
                <div class="col-md-12">
                  <div class="form-group">
                    <label class="col-form-label">Pelanggan:</label>
                    <input type="text" class="form-control" id="customer_id">
                    </select>
                  </div>
                  <div class="form-group">
                    <label class="col-form-label">Dibuat Oleh:</label>
                    <input type="text" class="form-control" id="user_id" value="<?php echo $_SESSION['user_name']; ?>" readonly="">
                  </div>  
                </div>
              </div>

            </div>
            <div class="col-md-4">
              <div class="form-group">
                <label class="col-form-label">No Referensi:</label>
                <input type="text" class="form-control" id="hd_expenditure_reference" >
              </div>
            </div>


          </div>
        </div>
        <!-- /.card-body -->
      </div>

      <!-- Default box -->
      <div class="card">
        <div class="card-header">
          <div class="row well well-sm">

            <div class="col-md-4">

              <label>Keterangan Biaya:</label>
              <input type="hidden" id="temp_id" name="temp_id" class="form-control">
              <input type="text" class="form-control" id="temp_item" >
            </div>

            <div class="col-sm-2">
              <label>Harga</label>
              <input type="text" id="temp_price" name="temp_price" class="form-control text-right calculation" value="0" required="" >
            </div>



            <div class="col-sm-2">

              <!-- text input -->

              <div class="form-group">

                <label>Qty</label>

                <input id="temp_qty" name="temp_qty" type="text" class="form-control text-right calculation" value="1" required="">

              </div>

            </div>

            <div class="col-sm-3">

              <!-- text input -->

              <div class="form-group">

                <label>Total</label>

                <input id="temp_total" name="temp_total" type="text" class="form-control text-right" value="0" readonly>

              </div>

            </div>

            <div class="col-sm-1">

              <!-- text input -->

              <label>&nbsp;</label>

              <div class="form-group">

                <button id="btnadd_temp" class="btn btn-md btn-primary rounded-circle float-right"><i class="fas fa-plus"></i></button>

              </div>

            </div>

          </div>
          <div class="card-body" style="padding:0 !important;">
            <table id="example" class="table table-striped table-bordered dataTable no-footer" style="width:100%">
              <thead>
                <tr>
                  <th>Keterangan Biaya</th>
                  <th>Harga</th>
                  <th>Qty</th>
                  <th>Total</th>
                  <th>Aksi</th>
                </tr>
              </thead>
              <tbody>
               <?php foreach($datas['list__temp_expenditure'] as $row){ ?>
                <tr>
                  <td><?php echo $row->temp_expenditure_item; ?></td>
                  <td>Rp. <?php echo number_format($row->temp_expenditure_price) ; ?></td>
                  <td><?php echo $row->temp_expenditure_qty; ?></td>
                  <td>Rp. <?php echo number_format($row->temp_expenditure_total); ?></td>
                  <td>
                    <button class="btn btn-sm btn-warning table-menu edittemp" data-id="<?php echo $row->temp_expenditure_id; ?>" data-title="Edit"><i class="fas fa-edit"></i></button>
                    <button class="btn btn-sm btn-danger table-menu" onclick="deletes('<?php echo $row->temp_expenditure_id; ?>', '<?php echo $row->temp_expenditure_item; ?>')" data-title="Hapus"><i class="fas fa-trash"></i></button>
                  </td>
                </tr>
              <?php } ?>
            </tbody>
          </table>
        </div>
        <!-- /.card-body -->
        <div class="row form-space footer-form">

          <div class="col-lg-5">

            <div class="form-group">

              <div class="col-sm-12">
               <textarea class="form-control" id="desc" rows="6" placeholder="Catatan"></textarea>
             </div>

           </div>

         </div>

         <div class="col-lg-7 text-right">

          <div class="form-group row">
            <label for="footer_sub_total" class="col-sm-7 col-form-label text-right:">Sub Total:</label>
            <div class="col-sm-5">
              <input id="footer_sub_total" name="footer_sub_total" type="text" class="form-control text-right" value="0" readonly="">
            </div>
          </div>


          <div class="form-group row">
            <label for="footer_total_pay" class="col-sm-7 col-form-label text-right:">Total Bayar:</label>
            <div class="col-sm-5">
              <input id="footer_total_pay" name="footer_total_pay" type="text" class="form-control text-right cal_remaining_debt" value="0">
            </div>
          </div>

          <div class="form-group row">
            <label for="footer_remaining_debt" class="col-sm-7 col-form-label text-right:">Sisa Pembayaran:</label>
            <div class="col-sm-5">
              <input id="footer_remaining_debt" name="footer_remaining_debt" type="text" class="form-control text-right" value="0" readonly="">
            </div>
          </div>

          <div class="form-group row">
            <div class="col-sm-12">
              <button id="btncancel" class="btn btn-danger"><i class="fas fa-times-circle"></i> Batal</button>
              <button id="btn_save" class="btn btn-success button-header-custom-save"><i class="fas fa-save"></i> Simpan</button>
            </div>
          </div>

        </div>


      </div>
      <!-- /.card-footer-->
    </div>
    <!-- /.card -->

  </section>
  <!-- /.content -->
</div>
<!-- /.content-wrapper -->
<!-- /.content-wrapper -->
<?php 
require DOC_ROOT_PATH . $this->config->item('footerlink');
?> 
<script type="text/javascript">

 $(document).ready(function() {
  let temp_price = new AutoNumeric('#temp_price', { currencySymbol : 'Rp. ' });
  let temp_total = new AutoNumeric('#temp_total', { currencySymbol : 'Rp. ' });
  let temp_qty = new AutoNumeric('#temp_qty', 'integer');
  let footer_sub_total = new AutoNumeric('#footer_sub_total', { currencySymbol : 'Rp. ' });
  let footer_total_pay = new AutoNumeric('#footer_total_pay', { currencySymbol : 'Rp. ' });
  let footer_remaining_debt = new AutoNumeric('#footer_remaining_debt', { currencySymbol : 'Rp. ' });

  setfootervalue();

  $(document).on('input', '.calculation', function(e) {
    e.preventDefault();
    let temp_price_cal = parseFloat(temp_price.getNumericString());
    let temp_qty_cal = parseFloat(temp_qty.getNumericString());
    temp_total.set(temp_price_cal * temp_qty_cal);
  });

  $(document).on('input', '.cal_remaining_debt', function(e) {
    e.preventDefault();
    let footer_sub_total_cal = parseFloat(footer_sub_total.getNumericString());
    let footer_total_pay_cal = parseFloat(footer_total_pay.getNumericString());
    footer_remaining_debt.set(footer_sub_total_cal - footer_total_pay_cal);
  });

  $('.edittemp').click(function(e){
    e.preventDefault();
    let id = $(this).attr("data-id");
    $.ajax({
      type: "GET",
      dataType: "json",
      url: "<?php echo base_url(); ?>Expenditure/getEditExpenditure?id="+id,
      success : function(data){
        if (data.code == "200"){
         $("#temp_id").val(data.result.temp_expenditure_id);
         $("#temp_item").val(data.result.temp_expenditure_item);
         temp_price.set(data.result.temp_expenditure_price);
         temp_qty.set(data.result.temp_expenditure_qty);
         temp_total.set(data.result.temp_expenditure_total);
       }
     }
   });
  });


  $('#btnadd_temp').click(function(e){
    e.preventDefault();
    let temp_id = $("#temp_id").val();
    let temp_item = $("#temp_item").val();
    let temp_price_val = parseFloat(temp_price.getNumericString());
    let temp_qty_val = parseFloat(temp_qty.getNumericString());
    let temp_total_val = parseFloat(temp_total.getNumericString());

    $.ajax({
      type: "POST",
      url: "<?php echo base_url(); ?>Expenditure/processaddtempexpenditure",
      dataType: "json",
      data: {temp_id:temp_id, temp_item:temp_item, temp_price:temp_price_val, temp_qty:temp_qty_val, temp_total:temp_total_val},
      success : function(data){
        if (data.code == "200"){
          location.reload();
          Swal.fire('Saved!', '', 'success');
        } else {
          Swal.fire({
            icon: 'error',
            title: 'Oops...',
            text: data.msg,
          })
        }
      }
    });
  });

  $('#btn_save').click(function(e){
    e.preventDefault();
    let customer_id = $("#customer_id").val();
    let hd_expenditure_reference = $("#hd_expenditure_reference").val();
    let date = $("#date").val();
    let footer_sub_total_val = parseFloat(footer_sub_total.getNumericString());
    let footer_total_pay_val = parseFloat(footer_total_pay.getNumericString());
    let footer_remaining_debt_val = parseFloat(footer_remaining_debt.getNumericString());
    let desc = $("#desc").val();
    let actiontype = 'add';

    $.ajax({
      type: "POST",
      url: "<?php echo base_url(); ?>Expenditure/processSaveExpenditure",
      dataType: "json",
      data: {customer_id:customer_id, hd_expenditure_reference:hd_expenditure_reference, date:date, footer_sub_total_val:footer_sub_total_val, footer_total_pay_val:footer_total_pay_val, footer_remaining_debt_val:footer_remaining_debt_val,desc:desc,actiontype:actiontype},
      success : function(data){
        if (data.code == "200"){
          window.location.href = "<?php echo base_url(); ?>Expenditure";
          Swal.fire('Saved!', '', 'success');
        } else {
          Swal.fire({
            icon: 'error',
            title: 'Oops...',
            text: data.msg,
          })
        }
      }
    });
  });

  


   function setfootervalue(){
    $.ajax({
      type: "GET",
      dataType: "json",
      url: "<?php echo base_url(); ?>Expenditure/getExpenditureFooter",
      success : function(data){
        if (data.code == "200"){
          footer_sub_total.set(data.sub_total);
          footer_total_pay.set(data.sub_total);
          footer_remaining_debt.set(0);
        }
      }
    });
  }

});
</script>

<script type="text/javascript">
  function deletes(id, name){
   Swal.fire({
    title: 'Konfirmasi?',
    text: "Apakah Anda Yakin Menghapus Data Pesanan '"+name+"' ?",
    icon: 'warning',
    showCancelButton: true,
    confirmButtonColor: '#3085d6',
    cancelButtonColor: '#d33',
    confirmButtonText: 'Hapus'
  }).then((result) => {
    if (result.isConfirmed) {
      window.location.replace('<?php echo base_url();?>Expenditure/deleteTempExpenditure?id='+id);
      Swal.fire(
        'Hapus!',
        'Sukses Hapus Data.',
        'Sukses'
        )
    }
  })
}
</script>

