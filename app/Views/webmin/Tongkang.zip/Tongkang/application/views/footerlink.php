<!-- Control Sidebar -->
<aside class="control-sidebar control-sidebar-dark">
  <!-- Control sidebar content goes here -->
</aside>
<!-- /.control-sidebar -->

<!-- Main Footer -->
<footer class="main-footer">
  <strong>Copyright &copy; 2014-2021 <a href="https://adminlte.io">AdminLTE.io</a>.</strong>
  All rights reserved.
  <div class="float-right d-none d-sm-inline-block">
    <b>Version</b> 3.2.0
  </div>
</footer>
</div>
<!-- ./wrapper -->

<!-- REQUIRED SCRIPTS -->

<!-- jQuery -->

<script src="<?php echo base_url(); ?>asset/plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap -->

<script src="https://borneoeternityswiftlet.co.id/asset/plugins/select2/js/select2.full.min.js"></script>
<script src="<?php echo base_url(); ?>asset/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- AdminLTE -->
<script src="<?php echo base_url(); ?>asset/dist/js/adminlte.js"></script>
<script src="<?php echo base_url(); ?>asset/plugins/datatables/jquery.dataTables.js"></script>
<script src="<?php echo base_url(); ?>asset/datatables/js/dataTables.bootstrap4.min.js"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/autonumeric/4.6.0/autoNumeric.min.js"></script>


<script src="https://borneoeternityswiftlet.co.id/asset/dist/js/sweetalert2@11.js"></script>



<script type="text/javascript">
 $(function () {
     //Initialize Select2 Elements


     $('.select2').select2()

     

     $("input[data-bootstrap-switch]").each(function(){
      $(this).bootstrapSwitch('state', $(this).prop('checked'));
    })

   })
 </script>

 <script type="text/javascript">
  $(document).ready(function () {
    $('#example').DataTable();
  });
</script>




</body>
</html>
