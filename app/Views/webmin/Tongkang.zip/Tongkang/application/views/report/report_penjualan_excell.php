<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<style type="text/css">
		body{
			font-family: sans-serif;
		}
		table{
			margin: 20px auto;
			border-collapse: collapse;
		}
		table th,
		table td{
			border: 1px solid #3c3c3c;
			padding: 3px 8px;

		}
		a{
			background: blue;
			color: #fff;
			padding: 8px 10px;
			text-decoration: none;
			border-radius: 2px;
		}
	</style>

	<?php
	header("Content-type: application/vnd-ms-excel");
	header("Content-Disposition: attachment; filename=Data Penjualan.xls");
	?>


	<table border="1">
		<tr>
			<th>No Invoice</th>
			<th>Tanggal</th>
			<th>Nama Pelanggan</th>
			<th>Tipe Transaksi</th>
			<th>Sub Total</th>
			<th>PPN</th>
			<th>Discount</th>
			<th>Total</th> 
		</tr>

		<?php foreach ($data['report_penjualan'] as $key) {?>
			<tr>
				<td><?php echo $key->transaction_invoice; ?></td>
				<td><?php echo $key->transaction_date; ?></td>
				<td><?php echo $key->customer_name; ?></td>
				<?php if($key->transaction_type == 'Reng'){ ?>
					<td><?php echo "Sewa" ?></td>
				<?php } else{  ?>
					<td><?php echo "Pengiriman Barang" ?></td>
				<?php } ?>
				<td><?php echo number_format($key->transaction_subtotal)	; ?></td>
				<td><?php echo number_format($key->transaction_ppn); ?></td>
				<td><?php echo number_format($key->transaction_discount); ?></td>
				<td><?php echo number_format($key->transaction_total); ?></td>
			</tr>    
		<?php } ?>
		<?php foreach ($data['report_total_penjualan_total'] as $key) {?>
			<tr>
				<td colspan="6"></td>
				<td>Total</td>
				<td><?php echo number_format($key->total_transaksi); ?></td>
			</tr>    
		<?php } ?>  
</table>
</body>
</html>