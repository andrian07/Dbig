  <?php 
  
  define('DOC_ROOT_PATH', $_SERVER['DOCUMENT_ROOT'].'/');
  require DOC_ROOT_PATH . $this->config->item('headerlink');
  ?>


  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Report Piutang</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="<?php echo base_url(); ?>Admin">Home</a></li>
              <li class="breadcrumb-item active">Report Piutang</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">

      <!-- Default box -->
      <div class="card">
        <div class="card-header">
          <div class="row">
            <div class="col-md-4">
             <div class="form-group">
              <label>Nama Pelanggan</label>
              <select id="customer_id" class="form-control select2" style="width: 100%;">
                <option>Semua</option>
                <?php foreach($get_customer as $row){ ?>
                  <option value="<?php echo $row->customer_id ?>"><?php echo $row->customer_name ?></option>
                <?php } ?>
              </select>
            </div>
          </div>
        <div class="col-md-2">
           <div class="form-group">
            <button type="button" class="btn btn-success" style="margin-top: 32px;"onclick="excellwashreport()">Export Excell</button>
          </div>
        </div>
      </div>
      <div class="card-body">

      </div>
      <!-- /.card-body -->
      <div class="card-footer">

      </div>
      <!-- /.card-footer-->
    </div>
    <!-- /.card -->

  </section>
  <!-- /.content -->
</div>
<!-- /.content-wrapper -->
<!-- /.content-wrapper -->

<?php 
require DOC_ROOT_PATH . $this->config->item('footerlink');
?>

<script>
function excellwashreport() {
  var customer_id = $("#customer_id").val();
  window.location.href = '<?php echo base_url(); ?>Report/report_piutang_excell?customer_id='+customer_id;
}
</script>