  <?php 
  
  define('DOC_ROOT_PATH', $_SERVER['DOCUMENT_ROOT'].'/');
  require DOC_ROOT_PATH . $this->config->item('headerlink');
  ?>


  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Report Penjualan</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="<?php echo base_url(); ?>Admin">Home</a></li>
              <li class="breadcrumb-item active">Report Penjualan</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">

      <!-- Default box -->
      <div class="card">
        <div class="card-header">
          <div class="row">
            <div class="col-md-4">
             <div class="form-group">
              <label>Dari Tanggal</label>
              <input type="date" class="form-control" id="date_from" name="date_from">
            </div>
          </div>
          <div class="col-md-4">
           <div class="form-group">
            <label>Sampai Tanggal</label>
            <input type="date" class="form-control" id="date_end" name="date_end">
          </div>
        </div>
        <div class="col-md-4">
           <div class="form-group">
            <button type="button" class="btn btn-success" style="margin-top: 32px;"onclick="excellwashreport()">Export Excell</button>
          </div>
        </div>
      </div>
      <div class="card-body">

      </div>
      <!-- /.card-body -->
      <div class="card-footer">

      </div>
      <!-- /.card-footer-->
    </div>
    <!-- /.card -->

  </section>
  <!-- /.content -->
</div>
<!-- /.content-wrapper -->
<!-- /.content-wrapper -->

<?php 
require DOC_ROOT_PATH . $this->config->item('footerlink');
?>

<script>
function excellwashreport() {
  var date_end = $("#date_end").val();
  var date_from = $("#date_from").val();
  window.location.href = '<?php echo base_url(); ?>Report/report_penjualan_excell?date_from='+date_from+'&date_end='+date_end;
}
</script>