<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<style type="text/css">
		body{
			font-family: sans-serif;
		}
		table{
			margin: 20px auto;
			border-collapse: collapse;
		}
		table th,
		table td{
			border: 1px solid #3c3c3c;
			padding: 3px 8px;

		}
		a{
			background: blue;
			color: #fff;
			padding: 8px 10px;
			text-decoration: none;
			border-radius: 2px;
		}
	</style>

	<?php
	header("Content-type: application/vnd-ms-excel");
	header("Content-Disposition: attachment; filename=Laba.xls");
	?>


	<table border="1">
		<tr><th colspan="2">Total Pemasukan: </th></tr>
		<tr>
			<td>Dp Transaksi:</td><td>Rp. <?php echo number_format($data['report_total_dp_transaksi'][0]->total_dp);  ?></td>
		</tr>
		<tr>
			<td>Pelunasan Transaksi:</td><td>Rp. <?php echo number_format($data['report_total_pelunasan_transaksi'][0]->total_pay);  ?></td>
		</tr>
		<tr>
			<td>Pelunasan Hutang Karyawan:</td><td>Rp. <?php echo number_format($data['report_total_pelunasan_karyawan'][0]->loan_total);  ?></td>
		</tr>


		<tr><th colspan="2">Total Pengeluaran: </th></tr>
		<tr>
			<td>Dp Pembelian:</td><td>Rp. <?php echo number_format($data['report_total_dp_purchase'][0]->total_dp);  ?></td>
		</tr>
		<tr>
			<td>Pelunasan Pembelian:</td><td>Rp. <?php echo number_format($data['report_total_pelunasan_purchase'][0]->total_pay);  ?></td>
		</tr>
		<tr>
			<td>Peminjaman Karyawan:</td><td>Rp. <?php echo number_format($data['report_total_peminjaman_karyawan'][0]->loan_total);  ?></td>
		</tr>
		<tr>
			<td>Pengeluaran:</td><td>Rp. <?php echo number_format($data['report_total_pengeluaran'][0]->total_expenditure);  ?></td>
		</tr>
</table>
</body>
</html>