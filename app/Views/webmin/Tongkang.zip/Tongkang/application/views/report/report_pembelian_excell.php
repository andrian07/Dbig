<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<style type="text/css">
		body{
			font-family: sans-serif;
		}
		table{
			margin: 20px auto;
			border-collapse: collapse;
		}
		table th,
		table td{
			border: 1px solid #3c3c3c;
			padding: 3px 8px;

		}
		a{
			background: blue;
			color: #fff;
			padding: 8px 10px;
			text-decoration: none;
			border-radius: 2px;
		}
	</style>

	<?php
	header("Content-type: application/vnd-ms-excel");
	header("Content-Disposition: attachment; filename=Data Pembelian.xls");
	?>


	<table border="1">
		<tr>
			<th>No Invoice</th>
			<th>Tanggal</th>
			<th>Nama Supplier</th>
			<th>Tipe Pembelian</th>
			<th>PPN</th>
			<th>Discount</th>
			<th>Total</th> 
		</tr>

		<?php foreach ($data['report_pembelian'] as $key) {?>
			<tr>
				<td><?php echo $key->hd_purchase_invoice; ?></td>
				<td><?php echo $key->hd_purchase_date; ?></td>
				<td><?php echo $key->supplier_name; ?></td>
				<td><?php echo $key->hd_purchase_type; ?></td>
				<td><?php echo number_format($key->hd_purchase_ppn); ?></td>
				<td><?php echo number_format($key->hd_purchase_discount); ?></td>
				<td><?php echo number_format($key->hd_purchase_total); ?></td>
			</tr>    
		<?php } ?>
		<?php foreach ($data['report_pembelian_total'] as $key) {?>
			<tr>
				<td colspan="5"></td>
				<td>Total</td>
				<td><?php echo number_format($key->total_transaksi); ?></td>
			</tr>    
		<?php } ?>        
	<?php /*
		<?php  if($this->session->userdata['user_name'] == 'Anita' || $this->session->userdata['user_name'] == 'anita' || $this->session->userdata['user_name'] == 'adminkanazawa' || $this->session->userdata['user_name'] == 'Adminkanazawa'){?>
		 <?php foreach($datas['get_trx_partner'] as $row){?>
		<tr>	
				<td><?php echo $row->booking_partner_invoice; ?></td>
                <td><?php echo $row->booking_id; ?></td>
                <td><?php echo $row->booking_location; ?></td>
                <td><?php echo $row->patient_name; ?></td>
                <td><?php echo $row->booking_date; ?></td>
                <td><?php echo $row->product_name; ?></td>
                <td><?php echo $row->booking_partner_pay_date; ?></td>
                <td><?php echo $row->product_price; ?></td>
                <td><?php echo $row->booking_partner_discount_pay; ?></td>
                <td><?php if($row->booking_partner_status_pay == 1){ echo "Hutang"; }else{ echo "Transfer";} ?></td>
                <td><?php echo $row->partner_payment_admin; ?></td>
		</tr>	
		<?php }  ?>
	<?php } ?>

	*/?>
</table>
</body>
</html>