<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<style type="text/css">
		body{
			font-family: sans-serif;
		}
		table{
			margin: 20px auto;
			border-collapse: collapse;
		}
		table th,
		table td{
			border: 1px solid #3c3c3c;
			padding: 3px 8px;

		}
		a{
			background: blue;
			color: #fff;
			padding: 8px 10px;
			text-decoration: none;
			border-radius: 2px;
		}
	</style>

	<?php
	header("Content-type: application/vnd-ms-excel");
	header("Content-Disposition: attachment; filename=Data Pinjaman.xls");
	?>


	<table border="1">
		<tr>
			<th>Kode Karyawan</th>
			<th>Nama Karyawan</th>
			<th>Total Pinjaman</th>
		</tr>

		<?php foreach ($data['report_pinjaman'] as $key) {?>
			<tr>
				<td><?php echo $key->employee_code; ?></td>
				<td><?php echo $key->employee_name; ?></td>
				<td><?php echo number_format($key->loan_debt_remaining); ?></td>
			</tr>    
		<?php } ?>
		<?php foreach ($data['report_pinjaman_total'] as $key) {?>
			<tr>
				<td colspan="2">Total</td>
				<td style="text-decoration: bold;"><?php echo number_format($key->total_pinjaman); ?></td>
			</tr>    
		<?php } ?>  
</table>
</body>
</html>