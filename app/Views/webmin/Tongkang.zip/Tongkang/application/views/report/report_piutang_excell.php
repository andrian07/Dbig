<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<style type="text/css">
		body{
			font-family: sans-serif;
		}
		table{
			margin: 20px auto;
			border-collapse: collapse;
		}
		table th,
		table td{
			border: 1px solid #3c3c3c;
			padding: 3px 8px;

		}
		a{
			background: blue;
			color: #fff;
			padding: 8px 10px;
			text-decoration: none;
			border-radius: 2px;
		}
	</style>

	<?php
	header("Content-type: application/vnd-ms-excel");
	header("Content-Disposition: attachment; filename=Data Piutang.xls");
	?>


	<table border="1">
		 <tr>
                <th>Nama Customer</th>
                <th>Alamat</th>
                <th>Telepon</th>
                <th>Jumlah Nota</th>
                <th>Total Hutang</th>
              </tr>
            </thead>
            <tbody>
              <?php foreach($report_piutang as $row){ ?>
                <tr>
                  <td><?php echo $row->customer_name; ?></td>
                  <td><?php echo $row->customer_address; ?></td>
                  <td><?php echo $row->customer_phone; ?></td>
                  <td><?php echo $row->total_invoice; ?></td>
                  <td>Rp. <?php echo number_format($row->total_receivables); ?></td>
             
                  </tr>
		<?php } ?>
	</table>
</body>
</html>