  <?php 
  
  define('DOC_ROOT_PATH', $_SERVER['DOCUMENT_ROOT'].'/');
  require DOC_ROOT_PATH . $this->config->item('headerlink');
  ?>


  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>History Pinjaman Karyawan</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="<?php echo base_url(); ?>Admin">Home</a></li>
              <li class="breadcrumb-item active">History Pinjaman Karyawan</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">

      <!-- Default box -->
      <div class="card">
        <div class="card-header">
          <h3 class="card-title">History Pinjaman Karyawan</h3>
          <div class="card-tools">
            <button class="btn btn-primary" data-toggle="modal" data-target="#exampleModal"><i class="fas fa-plus"></i> Tambah Pinjaman</button>
            <!-- popup add -->
            <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
              <div class="modal-dialog" role="document">
                <div class="modal-content">
                  <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Input Karyawan</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                      <span aria-hidden="true">&times;</span>
                    </button>
                  </div>
                  <div class="modal-body">
                    <div class="form-group">
                      <label>Total Pinjam</label>
                      <input type="text" class="form-control" id="loan_total" value="0">
                    </div>
                    <div class="form-group">
                      <label>Tanggal Pinjam</label>
                      <input type="date" class="form-control" id="loan_date" value="<?php echo date("Y-m-d") ?>">
                    </div>
                    <div class="form-group">
                      <label>Keterangan</label>
                      <textarea class="form-control" id="loan_desc" placeholder="Keterangan" rows="4"></textarea> 
                    </div>  
                  </div>
                  <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button id="btnaddloan"  type="button" class="btn btn-primary">Save </button>
                  </div>
                </div>
              </div>
            </div>
            
            <!-- end popup add -->
          </div>
        </div>
        <div class="card-body">
          <div class="row well well-sm">

            <div class="col-md-3">

              <label>Total Bayar:</label>
              <input type="hidden" id="employee_id" name="employee_id" class="form-control text-right" value="<?php echo $_GET['id'] ?>" required="">
              <input type="text" id="total_pay_loan" name="total_pay_loan" class="form-control text-right" value="0" required="">
            </div>

            <div class="col-sm-3">
              <label>Tanggal</label>
              <input type="date" id="pay_loan_date" name="pay_loan_date" class="form-control text-right" value="<?php echo date("Y-m-d") ?>">
            </div>

            <div class="col-sm-3">
              <label>Sisa Hutang</label>
              <input type="text" id="remaining_debt_loan" name="remaining_debt_loan" class="form-control text-right calculation" value="0" readonly="">
            </div>

            <div class="col-sm-1">
              <label>&nbsp;</label>
              <div class="form-group">
                <button id="btnpayloan" class="btn btn-md btn-primary rounded-circle float-right"><i class="fas fa-plus"></i></button>
              </div>
            </div>

          </div>

          <table class="table table-sm" style="width: 100%;">
            <thead>
              <tr>
                <th>Tanggal</th>
                <th>Debit</th>
                <th>Credit</th>
                <th>Keterangan</th>
                <th>Aksi</th>
              </tr>
            </thead>
            <tbody>
              <?php foreach($list_loan_payment as $row){ ?>
                <tr>
                  <td><?php $date = date_create($row->loan_date); echo date_format($date,"d-M-Y"); ?></td>
                  <td><?php if($row->loan_type == 'Bayar'){ echo '<span class="badge badge-success">Rp. '.number_format($row->loan_total).'</span>';}else{ echo ' ';}?></td>
                  <td><?php if($row->loan_type == 'Pinjam'){ echo '<span class="badge badge-danger">Rp. '.number_format($row->loan_total).'</span>';}else{ echo ' ';}?></td>
                  <td><?php echo $row->loan_desc; ?></td>
                  <td></td>
                </tr>
              <?php } ?>
            </tbody>
          </table>
        </div>
        <!-- /.card-body -->
        <div class="card-footer">

        </div>
        <!-- /.card-footer-->
      </div>
      <!-- /.card -->

    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  <!-- /.content-wrapper -->

  <?php 
  require DOC_ROOT_PATH . $this->config->item('footerlink');
  ?>

  <script type="text/javascript">
    $(document).ready(function() {
      let loan_total = new AutoNumeric('#loan_total', { currencySymbol : 'Rp. ' });
      let total_pay_loan = new AutoNumeric('#total_pay_loan', { currencySymbol : 'Rp. ' });
      let remaining_debt_loan = new AutoNumeric('#remaining_debt_loan', { currencySymbol : 'Rp. ' });

      setremainingdebt();

      $('#btnaddloan').click(function(e){
        e.preventDefault();
        let employee_id = $("#employee_id").val();
        let loan_desc = $("#loan_desc").val();
        let loan_date = $("#loan_date").val();
        let loan_total_val = parseFloat(loan_total.getNumericString()); 
        $.ajax({
          type: "POST",
          url: "<?php echo base_url(); ?>Loan/processaddloan",
          dataType: "json",
          data: {employee_id:employee_id, loan_desc:loan_desc, loan_date:loan_date, loan_total:loan_total_val},
          success : function(data){
            if (data.code == "200"){
              location.reload();
              Swal.fire('Saved!', '', 'success');
            } else {
              Swal.fire({
                icon: 'error',
                title: 'Oops...',
                text: data.msg,
              })
            }
          }
        });
      });

      $('#btnpayloan').click(function(e){
        e.preventDefault();
        let employee_id = $("#employee_id").val();
        let total_pay_loan_val = parseFloat(total_pay_loan.getNumericString()); 
        let pay_loan_date = $("#pay_loan_date").val();
        $.ajax({
          type: "POST",
          url: "<?php echo base_url(); ?>Loan/processpayloan",
          dataType: "json",
          data: {employee_id:employee_id, total_pay_loan_val:total_pay_loan_val, pay_loan_date:pay_loan_date},
          success : function(data){
            if (data.code == "200"){
              location.reload();
              Swal.fire('Saved!', '', 'success');
            } else {
              Swal.fire({
                icon: 'error',
                title: 'Oops...',
                text: data.msg,
              })
            }
          }
        });
      });

      function setremainingdebt(){
        let id = $("#employee_id").val();
        $.ajax({
          type: "GET",
          dataType: "json",
          url: "<?php echo base_url(); ?>Loan/setremainingdebt?id="+id,
          success : function(data){
            if (data.code == "200"){
              remaining_debt_loan.set(data.loan_debt_remaining);
            }
          }
        });
      }


    });

  </script>