  <?php 
  
  define('DOC_ROOT_PATH', $_SERVER['DOCUMENT_ROOT'].'/');
  require DOC_ROOT_PATH . $this->config->item('headerlink');
  ?>


  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Pinjaman Karyawan</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="<?php echo base_url(); ?>Admin">Home</a></li>
              <li class="breadcrumb-item active">Pinjaman Karyawan</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">

      <!-- Default box -->
      <div class="card">
        <div class="card-header">
          <h3 class="card-title">Daftar Pinjaman Karyawan</h3>
          <div class="card-tools">
          </div>
        </div>
        <div class="card-body">
          <table id="example" class="table table-striped table-bordered dataTable no-footer" style="width:100%">
            <thead>
              <tr>
                <th>Kode Karyawan</th>
                <th>Nama Karyawan</th>
                <th>Total Pinjaman</th>
                <th>Aksi</th>
              </tr>
            </thead>
            <tbody>
              <?php foreach($list_loan_employee as $row){ ?>
                <tr>
                  <td><?php echo $row->employee_code; ?></td>
                  <td><?php echo $row->employee_name; ?></td>
                  <td>Rp. <?php echo number_format($row->loan_debt_remaining); ?></td>
                  <td>
                    <a href="<?php echo base_url(); ?>Loan/loanpayment?id=<?php echo $row->employee_id; ?>">
                      <button class="btn btn-sm btn-success table-menu" data-title="Detail"><i class="fas fa-eye"></i></button>
                    </a>
                    </td>
                  </tr>
                <?php } ?>
              </tbody>
            </table>
          </div>
          <!-- /.card-body -->
          <div class="card-footer">

          </div>
          <!-- /.card-footer-->
        </div>
        <!-- /.card -->

      </section>
      <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->
    <!-- /.content-wrapper -->

    <?php 
    require DOC_ROOT_PATH . $this->config->item('footerlink');
    ?>