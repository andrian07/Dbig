  <?php 
  
  define('DOC_ROOT_PATH', $_SERVER['DOCUMENT_ROOT'].'/');
  require DOC_ROOT_PATH . $this->config->item('headerlink');
  ?>

  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Transaksi</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="<?php echo base_url(); ?>Admin">Home</a></li>
              <li class="breadcrumb-item active">Transaksi</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="acontent">
      <div class="card card-default">
        <div class="card-header">
          <h3 class="card-title">Form Transaksi</h3>

          <div class="card-tools">
            <button type="button" class="btn btn-tool" data-card-widget="collapse">
              <i class="fas fa-minus"></i>
            </button>
          </div>
        </div>
        <!-- /.card-header -->

        <div class="card-body">

          <div class="row">
            <div class="col-md-4">
              <div class="form-group">
                <label class="col-form-label">No Invoice:</label>
                <input type="text" id="hd_po_invoice" class="form-control" value="AUTO" readonly="">
              </div>
              <div class="form-group">
                <label class="col-form-label">Jenis Transaksi:</label>
                <select id="transation_type" class="form-control" style="width: 100%;">
                  <option></option>
                  <option value="Shiping">Jasa Angkutan</option>
                  <option value="Rent">Penyewaan Kapal</option>
                </select>
              </div>
            </div>
            <div class="col-md-4">
              <div class="row">
                <div class="col-md-12">
                  <div class="form-group">
                    <label class="col-form-label">Pelanggan:</label>
                    <select id="customer_id" class="form-control select2" style="width: 100%;">
                      <option></option>
                      <?php foreach($datas['list_customer'] as $row){ ?>
                        <option value="<?php echo $row->customer_id ?>"><?php echo $row->customer_name ?></option>
                      <?php } ?>
                    </select>
                  </div>
                  <div class="form-group">
                    <label class="col-form-label">Tempo:</label>
                    <input type="date" id="duedate" class="form-control" value="<?php echo date("Y-m-d");   ?>">
                  </div>
                </div>
              </div>
            </div>
            <div class="col-md-4">
              <div class="row">
                <div class="col-md-12">
                  <div class="form-group">
                    <label class="col-form-label">Tanggal:</label>
                    <input type="date" class="form-control" id="date" value="<?php echo date("Y-m-d");   ?>">
                  </div>
                  <div class="form-group">
                    <label class="col-form-label">Dibuat Oleh:</label>
                    <input type="text" class="form-control" id="user_id" value="<?php echo $_SESSION['user_name']; ?>" readonly="">
                  </div> 
                </div>
              </div>
            </div>


          </div>
        </div>
        <!-- /.card-body -->
      </div>

      <!-- Default box -->
      <div class="card">
        <div class="card-header">
          <div class="row well well-sm">

            <div class="col-md-4">
              <label>Keterangan Item:</label>
              <input id="temp_id" name="temp_id" type="hidden" class="form-control text-right" readonly>
              <textarea class="form-control" id="item_desc" rows="5" placeholder="Item"></textarea>
            </div>

            <div class="col-md-8">
              <div class="row">
                <div class="col-sm-3">
                  <label>Kapal</label>
                  <select id="temp_ship" class="form-control select2" style="width: 100%;">
                    <option></option>
                    <?php foreach($datas['list_ship'] as $row){ ?>
                      <option value="<?php echo $row->ship_id ?>"><?php echo $row->ship_name ?></option>
                    <?php } ?>
                  </select>
                </div>

                <div class="col-sm-4">
                  <label>Harga</label>
                  <input type="text" id="temp_price" name="temp_price" class="form-control text-right calculation" value="0" required="" >
                </div>

                <div class="col-sm-3">

                  <!-- text input -->

                  <div class="form-group">

                    <label>PPN (per item)</label>

                    <input id="temp_ppn" name="temp_ppn" type="text" class="form-control text-right" value="0" readonly>

                  </div>

                </div>

                <div class="col-sm-1">

                  <!-- text input -->

                  <label>&nbsp;</label>

                  <div class="form-group">

                    <div class="icheck-primary d-inline">
                      <input type="checkbox" id="ppn_check" style="width:25px; height:25px;">
                      <label for="ppn_check">
                      </label>
                    </div>

                  </div>

                </div>

                <div class="col-sm-2">

                  <!-- text input -->

                  <div class="form-group">

                    <label>Qty</label>

                    <input id="temp_qty" name="temp_qty" type="text" class="form-control text-right calculation" value="1">

                  </div>

                </div>

                <div class="col-sm-3 hidden-date">

                  <!-- text input -->

                  <div class="form-group">

                    <label>Mulai Sewa</label>
                    <input type="date" id="rentstartdate" class="form-control" value="">
                  </div>

                </div>

                <div class="col-sm hidden-date">

                  <!-- text input -->

                  <div class="form-group">

                    <label>Selesai Sewa</label>

                    <input type="date" id="rentenddate" class="form-control" value="">
                  </div>

                </div>

                <div class="col-sm-3">

                  <!-- text input -->

                  <div class="form-group">

                    <label>Satuan</label>

                    <select id="temp_weight" class="form-control select2" style="width: 100%;">
                      <option></option>
                      <?php foreach($datas['list_weight'] as $row){ ?>
                        <option value="<?php echo $row->weight_code ?>"><?php echo $row->weight_code ?></option>
                      <?php } ?>
                    </select>
                  </div>

                </div>

                <div class="col-sm-6">

                  <!-- text input -->

                  <div class="form-group">

                    <label>Total</label>

                    <input id="temp_total" name="temp_total" type="text" class="form-control text-right" value="0" readonly>

                  </div>

                </div>

                <div class="col-sm-1">

                  <!-- text input -->

                  <label>&nbsp;</label>

                  <div class="form-group">

                    <button id="btnadd_temp" class="btn btn-md btn-primary rounded-circle float-right"><i class="fas fa-plus"></i></button>

                  </div>

                </div>

              </div>
            </div>
            

          </div>
          <div class="card-body" style="padding:0 !important;">
            <table id="example" class="table table-striped table-bordered dataTable no-footer" style="width:100%">
              <thead>
                <tr>
                  <th>Nama Item</th>
                  <th>Satuan</th>
                  <th>TB/TK</th>
                  <th>Harga</th>
                  <th>Qty</th>
                  <th>PPN</th>
                  <th>Total</th>
                  <th>Keterangan</th>
                  <th>Aksi</th>
                </tr>
              </thead>
              <tbody>
               <?php foreach($datas['list_temp_transaction'] as $row){ ?>
                <tr>
                  <td><?php echo $row->transaction_item; ?></td>
                  <td><?php echo $row->transaction_weight; ?></td>
                  <td><?php echo $row->ship_name; ?></td>
                  <td>Rp. <?php echo number_format($row->transaction_price) ; ?></td>
                  <td><?php echo $row->transaction_qty; ?></td>
                  <td>Rp. <?php echo number_format($row->transaction_ppn); ?></td>
                  <td>Rp. <?php echo number_format($row->transaction_total); ?></td>
                  <td><?php if($row->transaction_rent_startdate != null){ echo 'Tgl Sewa: '.$row->transaction_rent_startdate.' Sampai '.$row->transaction_rent_enddate; }?></td>
                  <td>
                    <button class="btn btn-sm btn-warning table-menu edittemp" data-id="<?php echo $row->temp_purchase_id; ?>" data-title="Edit"><i class="fas fa-edit"></i></button>
                    <button class="btn btn-sm btn-danger table-menu" onclick="deletes('<?php echo $row->temp_purchase_id; ?>', '<?php echo $row->transaction_item; ?>')" data-title="Hapus"><i class="fas fa-trash"></i></button>
                  </td>
                </tr>
              <?php } ?>
            </tbody>
          </table>
        </div>
        <!-- /.card-body -->
        <div class="row form-space footer-form">

          <div class="col-lg-5">

            <div class="form-group">

              <div class="col-sm-12">
               <textarea class="form-control" id="desc" rows="6" placeholder="Catatan"></textarea>
             </div>

           </div>

         </div>

         <div class="col-lg-7 text-right">

          <div class="form-group row">
            <label for="footer_sub_total" class="col-sm-7 col-form-label text-right:">Sub Total:</label>
            <div class="col-sm-5">
              <input id="footer_sub_total" name="footer_sub_total" type="text" class="form-control text-right" value="0" readonly="">
            </div>
          </div>

          <div class="form-group row" style="display: none;">
            <label for="footer_total_discount" class="col-sm-7 col-form-label text-right:">Discount :</label>
            <div class="col-sm-3">
              <input id="footer_total_discount" name="footer_total_discount" type="text" class="form-control calculation_footer text-right" value="0">
            </div>
            <div class="col-sm-2">
              <input id="footer_total_discount_percentage" name="footer_total_discount_percentage" type="text" class="form-control calculation_percentage text-right" value="0">
            </div>
          </div>

          <div class="form-group row">
            <label for="footer_total_ppn" class="col-sm-7 col-form-label text-right:">PPN</label>
            <div class="col-sm-5">
              <input id="footer_total_ppn" name="footer_total_ppn" type="text" class="form-control text-right" value="0" readonly>
            </div>
          </div>

          <div class="form-group row">
            <label for="footer_total_invoice" class="col-sm-7 col-form-label text-right:">Grand Total :</label>
            <div class="col-sm-5">
              <input id="footer_total_invoice" name="footer_total_invoice" type="text" class="form-control text-right" value="0" readonly="">
            </div>
          </div>

          <div class="form-group row">
            <label for="footer_total_dp" class="col-sm-7 col-form-label text-right:">DP :</label>
            <div class="col-sm-5">
              <input id="footer_total_dp" name="footer_total_dp" type="text" class="form-control text-right calculation_dp" value="0">
            </div>
          </div>

          <div class="form-group row">
            <label for="footer_total_remaining" class="col-sm-7 col-form-label text-right:">Sisa Pembayaran :</label>
            <div class="col-sm-5">
              <input id="footer_total_remaining" name="footer_total_remaining" type="text" class="form-control text-right" value="0" readonly="">
            </div>
          </div>

          <div class="form-group row">
            <div class="col-sm-12">
              <button id="btncancel" class="btn btn-danger"><i class="fas fa-times-circle"></i> Batal</button>
              <button id="btn_save" class="btn btn-success button-header-custom-save"><i class="fas fa-save"></i> Simpan</button>
            </div>
          </div>

        </div>


      </div>
      <!-- /.card-footer-->
    </div>
    <!-- /.card -->

  </section>
  <!-- /.content -->
</div>
<!-- /.content-wrapper -->
<!-- /.content-wrapper -->
<?php 
require DOC_ROOT_PATH . $this->config->item('footerlink');
?> 
<script type="text/javascript">


 $(document).ready(function() {
  let temp_price = new AutoNumeric('#temp_price', { currencySymbol : 'Rp. ' });
  let temp_total = new AutoNumeric('#temp_total', { currencySymbol : 'Rp. ' });
  let temp_ppn = new AutoNumeric('#temp_ppn', { currencySymbol : 'Rp. ' });
  let footer_sub_total = new AutoNumeric('#footer_sub_total', { currencySymbol : 'Rp. ' });
  let footer_total_discount = new AutoNumeric('#footer_total_discount', { currencySymbol : 'Rp. ' });
  let footer_total_discount_percentage = new AutoNumeric('#footer_total_discount_percentage', 'percentageUS2decPos');
  let footer_total_ppn = new AutoNumeric('#footer_total_ppn', { currencySymbol : 'Rp. ' });
  let temp_qty = new AutoNumeric('#temp_qty', 'integer');
  let footer_total_invoice = new AutoNumeric('#footer_total_invoice', { currencySymbol : 'Rp. ' });
  let footer_total_remaining = new AutoNumeric('#footer_total_remaining', { currencySymbol : 'Rp. ' });
  let footer_total_dp = new AutoNumeric('#footer_total_dp', { currencySymbol : 'Rp. ' });

  setfootervalue();


  $('#transation_type').on('change', function() {
    if($("#transation_type").val() == 'Rent'){
      $(".hidden-date").css("display", "block");
    }else{
      $(".hidden-date").css("display", "none");
    }
  });



  $('#btnadd_temp').click(function(e){
    e.preventDefault();
    let temp_id = $("#temp_id").val();
    let item_desc = $("#item_desc").val();
    let temp_ship = $("#temp_ship").val();
    let temp_price_val = parseFloat(temp_price.getNumericString());
    let temp_ppn_val = parseFloat(temp_ppn.getNumericString());
    let temp_total_val = parseFloat(temp_total.getNumericString());
    let temp_qty_val = parseFloat(temp_qty.getNumericString());
    let temp_rent_startdate = $("#rentstartdate").val();
    let temp_rent_enddate = $("#rentenddate").val();
    let temp_weight = $("#temp_weight").val();
    let transation_type = $("#transation_type").val();
    let actiontype = 'add';

    $.ajax({
      type: "POST",
      url: "<?php echo base_url(); ?>Shiping/processaddtempshipping",
      dataType: "json",
      data: {temp_id:temp_id, item_desc:item_desc, temp_ship:temp_ship, temp_price_val:temp_price_val, temp_ppn_val:temp_ppn_val, temp_total_val:temp_total_val, temp_qty_val:temp_qty_val, temp_weight:temp_weight, transation_type:transation_type, temp_rent_startdate:temp_rent_startdate, temp_rent_enddate:temp_rent_enddate, actiontype:actiontype},
      success : function(data){
        if (data.code == "200"){
          location.reload();
          Swal.fire('Saved!', '', 'success');
        } else {
          Swal.fire({
            icon: 'error',
            title: 'Oops...',
            text: data.msg,
          })
        }
      }
    });
  });

  $(document).on('input', '.calculation', function(e) {
    e.preventDefault();
    let temp_price_cal = parseFloat(temp_price.getNumericString());
    let temp_ppn_cal = parseFloat(temp_ppn.getNumericString());
    let temp_qty_cal = parseFloat(temp_qty.getNumericString());
    temp_total.set(temp_price_cal * temp_qty_cal);
    $( "#ppn_check").prop('checked', false);
    temp_ppn.set(0);
  });

  $(document).on('input', '.calculation_footer', function(e) {
    e.preventDefault();
    let footer_sub_total_cal = parseFloat(footer_sub_total.getNumericString());
    let footer_total_discount_cal = parseFloat(footer_total_discount.getNumericString());
    footer_total_discount_percentage.set(footer_total_discount_cal / footer_sub_total_cal)
    footer_total_invoice.set(footer_sub_total_cal - footer_total_discount_cal);
    footer_total_ppn.set(0);
    $('#ppn_check').prop('checked', false);
  });

  $(document).on('input', '.calculation_percentage', function(e) {
    e.preventDefault();

    let footer_sub_total_cal = parseFloat(footer_sub_total.getNumericString());
    let footer_total_discount_percentage_cal = parseFloat(footer_total_discount_percentage.getNumericString());
    let footer_total_discount_cal = parseFloat(footer_total_discount.getNumericString());
    footer_total_discount.set(footer_total_discount_percentage_cal * footer_sub_total_cal);
    footer_total_invoice.set(footer_sub_total_cal - (footer_total_discount_percentage_cal * footer_sub_total_cal));
    footer_total_ppn.set(0);
    $('#ppn_check').prop('checked', false);
  });

  $(document).on('input', '#ppn_check', function(e) {
    e.preventDefault();
    let temp_price_cal = parseFloat(temp_price.getNumericString());
    let temp_qty_cal = parseFloat(temp_qty.getNumericString());
    if ($('#ppn_check').is(":checked"))
    {
      temp_ppn.set(temp_price_cal * 0.11);
      temp_total.set((temp_price_cal * temp_qty_cal) + ((temp_price_cal * temp_qty_cal) * 0.11));
    }else{
      temp_ppn.set(0);
      temp_total.set(temp_price_cal * temp_qty_cal)
    }
  });


  $(document).on('input', '.calculation_dp', function(e) {
    e.preventDefault();
    let footer_total_invoice_cal = parseFloat(footer_total_invoice.getNumericString());
    let footer_total_dp_cal = parseFloat(footer_total_dp.getNumericString());
    footer_total_remaining.set(footer_total_invoice_cal - footer_total_dp_cal);
  });

  


  function clearinput(){
    footer_total_discount.set(0);
    footer_total_discount_percentage.set(0);
    footer_total_ppn.set(0);
    $( "#ppn_check").prop('checked', false);
  }

  function setfootervalue(){
    $.ajax({
      type: "GET",
      dataType: "json",
      url: "<?php echo base_url(); ?>Shiping/getShippingFooter",
      success : function(data){
        if (data.code == "200"){
          $("#transation_type").val(data.transaction_type);
          if(data.total_invoice > 0){
            $('#transation_type').prop('disabled', true);
          }
          if(data.transaction_type == 'Rent'){
            $(".hidden-date").css("display", "block");
          }else{
            $(".hidden-date").css("display", "none");
          }
          footer_sub_total.set(data.sub_total); 
          footer_total_invoice.set(data.total_invoice);
          let footer_sub_total_cal = parseFloat(footer_sub_total.getNumericString());
          let footer_total_discount_percentage_cal = parseFloat(footer_total_discount_percentage.getNumericString());
          let footer_total_discount_cal = parseFloat(footer_total_discount.getNumericString());
          footer_total_ppn.set((footer_sub_total_cal - footer_total_discount_cal) * 0.11);
          footer_total_invoice.set(footer_sub_total_cal - footer_total_discount_cal + ((footer_sub_total_cal - footer_total_discount_cal) * 0.11));
          footer_total_remaining.set(footer_sub_total_cal - footer_total_discount_cal + ((footer_sub_total_cal - footer_total_discount_cal) * 0.11));
        }
      }
    });
  }



  $('.edittemp').click(function(e){
    e.preventDefault();
    let id = $(this).attr("data-id");
    $.ajax({
      type: "GET",
      dataType: "json",
      url: "<?php echo base_url(); ?>Shiping/getEditTemp?id="+id,
      success : function(data){
        if (data.code == "200"){
         $("#temp_id").val(data.result.temp_po_id);
         $("#temp_item").select2("val", data.result.temp_item_id);
         temp_price.set(data.result.temp_item_price);
         temp_qty.set(data.result.temp_item_qty);
         temp_total.set(data.result.temp_item_total);
       }
     }
   });
  });



  $('#btn_save').click(function(e){
    e.preventDefault();
    let customer_id = $("#customer_id").val();
    let date = $("#date").val();

    let footer_sub_total_inp = parseFloat(footer_sub_total.getNumericString());
    let footer_total_ppn_inp = parseFloat(footer_total_ppn.getNumericString());
    let footer_total_invoice_inp = parseFloat(footer_total_invoice.getNumericString());
    let footer_total_remaining_inp = parseFloat(footer_total_remaining.getNumericString());
    let footer_total_dp_inp = parseFloat(footer_total_dp.getNumericString());

    let transation_type = $("#transation_type").val();

    $.ajax({
      type: "POST",
      url: "<?php echo base_url(); ?>Shiping/processsaveshipping",
      dataType: "json",
      data: {customer_id:customer_id, transation_type:transation_type, date:date, footer_sub_total_inp:footer_sub_total_inp, footer_total_ppn_inp:footer_total_ppn_inp, footer_total_invoice_inp:footer_total_invoice_inp, footer_total_remaining_inp:footer_total_remaining_inp, footer_total_dp_inp:footer_total_dp_inp},
      success : function(data){
        if (data.code == "200"){
          window.location.href = "<?php echo base_url(); ?>Shiping";
          Swal.fire('Saved!', '', 'success'); 
        } else {
          Swal.fire({
            icon: 'error',
            title: 'Oops...',
            text: data.msg,
          })
        }
      }
    });
  });


});
</script>


<script type="text/javascript">
  function deletes(id, name){
   Swal.fire({
    title: 'Konfirmasi?',
    text: "Apakah Anda Yakin Menghapus Data Pesanan '"+name+"' ?",
    icon: 'warning',
    showCancelButton: true,
    confirmButtonColor: '#3085d6',
    cancelButtonColor: '#d33',
    confirmButtonText: 'Hapus'
  }).then((result) => {
    if (result.isConfirmed) {
      window.location.replace('<?php echo base_url();?>Shiping/deleteTempShiping?id='+id);
      Swal.fire(
        'Hapus!',
        'Sukses Hapus Data.',
        'Sukses'
        )
    }
  })
}
</script>