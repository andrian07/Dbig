<!DOCTYPE html>
<html>
<head>


  <!-- Google Font: Source Sans Pro -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="<?php echo base_url(); ?>asset/plugins/invoice/invoice.css">
  <title></title>
</head>
<body>
  <div class="invoice-a4">

    <div class="letterhead">
      <div class="left letterhead-left text-right"><img src="<?php echo base_url(); ?>asset/images/logoDPM.png" alt="Logo DPM" width="50%"></div>
      <div class="right letterhead-right">
        <h2>PT. Dua Putri Marine</h2>
        <P> <?php echo Address; ?> </P>
      </div>
    </div>
    <div class="letterhead-border">&nbsp;&nbsp;</div>

    <div class="content-invoice">
      <?php foreach($datas['getShipingHd'] as $row) { ?>
        <h3 class="text-center">INVOICE</h3>


        <table class="info-date">
          <tr>
            <td>Date</td><td>:</td><td><?php $date = date_create($row->transaction_date); echo date_format($date,"d-M-Y"); ?></td>
          </tr>
          <tr>
            <td>No Invoice  </td><td>:</td><td><?php echo $row->transaction_invoice; ?></td>
          </tr>
        </table>

        <div class="address-content">
          <div class="left address-content-left">
            <h4 style="text-decoration: underline;">Kepada Yth</h4>
            <h4 style="margin-top: -19px;"><?php echo $row->customer_name; ?></h4>
            <P style="width: 80%;"><?php echo $row->customer_address; ?></P>
          </div>
          <div class="right address-content-right">
            <h4 style="text-decoration: underline;">Dari </h4>
            <h4 style="margin-top: -19px;">PT. Dua Putri Marine</h4>
            <p> <?php echo Address; ?></p>
          </div>
        </div>
      <?php } ?>


      <table class="item">
        <thead>
         <tr>
          <th width="35%">Keterangan</th>
          <th>Nama TB/TK</th>
          <th width="20%">Harga</th>
          <th width="15%">Qty</th>
          <th width="15%">PPN 11%</th>
        </tr>
      </thead>
      <tbody>
       <?php foreach($datas['getShipingDetail'] as $row){ ?>
        <tr>
          <td><?php echo $row->transaction_item .' '.$row->transaction_weight; ?></td>
          <td class="text-center"><?php echo $row->ship_name ?></td>
          <td class="text-center">Rp. <?php echo number_format($row->transaction_price) ?></td>
          <td class="text-center"><?php echo $row->transaction_qty ?></td>
          <td class="text-center">Rp. <?php echo number_format($row->transaction_total) ?></td>
        </tr>
      <?php } ?>
    </tbody>
    <tfoot>
     <?php foreach($datas['getShipingHd'] as $row) { ?>
      <tr>
        <td colspan="3"></td>
        <th>Subtotal</th>
        <th class="text-center">Rp. <?php echo number_format($row->transaction_subtotal) ?></th>
      </tr>
      <tr>
        <td colspan="3"></td>
        <th>Discount</th>
        <th class="text-center">Rp. <?php echo number_format($row->transaction_discount) ?></th>
      </tr>
      <tr>
        <td colspan="3"></td>
        <th>PPN (11%)</th>
        <th class="text-center">Rp. <?php echo number_format($row->transaction_ppn) ?></th>
      </tr>
      <tr>
        <td colspan="3"></td>
        <th>Total</th>
        <th class="text-center">Rp. <?php echo number_format($row->transaction_total) ?></th>
      </tr>
    <?php } ?>
  </tfoot>
</table>


<p style="width:100%; margin-top:50px;">Dengan hormat, <br />
          Dengan ini kami kirimkan permohonan pembayaran sewa tongkang lansir beserta rincian<br />
        </p>

<p>MOHON DI TRANSFER PADA REKENING KAMI:<br /> 
  - MANDIRI         : 146-00-5701999-9<br />
  - An. PT. DUA PUTRI MARINE <br />
  Demikian kami sampaikan, atas perhatian dan kerja samanya kami ucapkan terima kasih.
</p>
</div>




<div class="ttd-div">
  <?php foreach($datas['getShipingHd'] as $row) { ?>
    <p class="text-right" style="margin-right: 100px;">Pontiank, <?php $date = date_create($row->transaction_date); echo date_format($date,"d-M-Y"); ?></p>
  <?php } ?>
  <p class="text-right" style="margin-right: 120px;">Hormat Kami,</p>
  <p class="text-right" style="margin-right: 60px; font-size: 17px;margin-top: 5px;">PT. DUA PUTRI MARINE</p>
  <p class="text-right" style="text-decoration: underline; margin-right: 140px; margin-top: 100px; font-size: 17px;">MIDI</p>
</div>
</div>
</body>
</html>
<!-- DEBUG-VIEW ENDED 1 APPPATH/Views/webmin/purchase/purchaseorder_invoice.php -->

