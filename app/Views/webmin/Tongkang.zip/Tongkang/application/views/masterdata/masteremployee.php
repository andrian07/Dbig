  <?php 
  
  define('DOC_ROOT_PATH', $_SERVER['DOCUMENT_ROOT'].'/');
  require DOC_ROOT_PATH . $this->config->item('headerlink');
  ?>


  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Master Karyawan</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="<?php echo base_url(); ?>Admin">Home</a></li>
              <li class="breadcrumb-item active">Master Karyawan</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">

      <!-- Default box -->
      <div class="card">
        <div class="card-header">
          <h3 class="card-title">Daftar Karyawan</h3>
          <div class="card-tools">

            <button class="btn btn-primary" data-toggle="modal" data-target="#exampleModal"><i class="fas fa-plus"></i> Tambah</button>

            <!-- popup add -->
            <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
              <div class="modal-dialog" role="document">
                <div class="modal-content">
                  <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Input Karyawan</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                      <span aria-hidden="true">&times;</span>
                    </button>
                  </div>
                  <div class="modal-body">
                    <div class="form-group">
                      <label>Kode Karyawan</label>
                      <input type="hidden" class="form-control" id="action_type" value="add" readonly>
                      <input type="text" class="form-control" id="employee_code" value="AUTO" readonly>
                    </div>
                    <div class="form-group">
                      <label>Nama</label>
                      <input type="text" class="form-control" id="employee_name" placeholder="Nama Karyawan">
                    </div>
                    <div class="form-group">
                      <label>Gaji Pokok</label>
                      <input type="text" class="form-control" id="employee_salary" placeholder="Gaji Pokok" value="0">
                    </div>
                  </div>
                  <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button id="btnadd"  type="button" class="btn btn-primary">Save changes</button>
                  </div>
                </div>
              </div>
            </div>
            
            <!-- end popup add -->

            <!-- popup Edit -->
            <div class="modal fade" id="exampleModaledit" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
              <div class="modal-dialog" role="document">
                <div class="modal-content">
                  <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Tambah Customer</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                      <span aria-hidden="true">&times;</span>
                    </button>
                  </div>
                  <div class="modal-body">
                    <div class="modal-body">
                      <div class="form-group">
                        <label>Kode Karyawan</label>
                        <input type="hidden" class="form-control" id="action_type_edit" value="edit" readonly>
                        <input type="hidden" class="form-control" id="employee_id_edit" readonly>
                        <input type="text" class="form-control" id="employee_code_edit"  readonly>
                      </div>
                      <div class="form-group">
                        <label>Nama</label>
                        <input type="text" class="form-control" id="employee_name_edit" placeholder="Nama Karyawan">
                      </div>
                      <div class="form-group">
                        <label>Gaji Pokok</label>
                        <input type="text" class="form-control" id="employee_salary_edit" placeholder="Gaji Pokok">
                      </div>
                    </div>
                  </div>
                  <div class="modal-footer">

                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-info" id="btnedit">Edit</button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="card-body">
          <table id="example" class="table table-striped table-bordered dataTable no-footer" style="width:100%">
            <thead>
              <tr>
                <th>Kode Karyawan</th>
                <th>Nama</th>
                <th>Gaji </th>
                <th>Aksi</th>
              </tr>
            </thead>
            <tbody>
              <?php foreach($list_employee as $row){ ?>
                <tr>
                  <td><?php echo $row->employee_code; ?></td>
                  <td><?php echo $row->employee_name; ?></td>
                  <td>Rp. <?php echo number_format($row->employee_salary); ?></td>
                  <td>
                    <button data-id="<?php echo $row->employee_id; ?>" data-code="<?php echo $row->employee_code; ?>" data-name="<?php echo $row->employee_name; ?>" data-salary="<?php echo $row->employee_salary; ?>" class="btn btn-sm btn-warning table-menu" data-toggle="modal" data-target="#exampleModaledit"><i class="fas fa-edit"></i></button>
                    <button class="btn btn-sm btn-danger table-menu" onclick="deletes('<?php echo $row->employee_id; ?>', '<?php echo $row->employee_name; ?>')" data-title="Hapus"><i class="fas fa-trash"></i></button>
                  </td>
                </tr>
              <?php } ?>
            </tbody>
          </table>
        </div>
        <!-- /.card-body -->
        <div class="card-footer">

        </div>
        <!-- /.card-footer-->
      </div>
      <!-- /.card -->

    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  <!-- /.content-wrapper -->

  <?php 
  require DOC_ROOT_PATH . $this->config->item('footerlink');
  ?>

  <script type="text/javascript">
    $(document).ready(function() {
      let employee_salary = new AutoNumeric('#employee_salary', { currencySymbol : 'Rp. ' });
      let employee_salary_edit = new AutoNumeric('#employee_salary_edit', { currencySymbol : 'Rp. ' });


      $('#exampleModaledit').on('show.bs.modal', function (event) {
        var button = $(event.relatedTarget) // Button that triggered the modal
        var employee_id_edit   = button.data('id')
        var employee_code_edit   = button.data('code')
        var employee_name_edit  = button.data('name')
        var employee_salary_edits  = button.data('salary')

        var modal = $(this)
        modal.find('.modal-title').text('Edit ' + employee_name_edit)
        modal.find('#employee_id_edit').val(employee_id_edit)
        modal.find('#employee_code_edit').val(employee_code_edit)
        modal.find('#employee_name_edit').val(employee_name_edit)
        employee_salary_edit.set(employee_salary_edits)
      })

      $('#btnadd').click(function(e){
        e.preventDefault();
        let employee_code = $("#employee_code").val();
        let employee_name = $("#employee_name").val();
        let action_type = $("#action_type").val();
        let employee_salarys = parseFloat(employee_salary.getNumericString());

        $.ajax({
          type: "POST",
          url: "<?php echo base_url(); ?>Masterdata/processaddemployee",
          dataType: "json",
          data: {employee_code:employee_code, employee_name:employee_name, employee_salary:employee_salarys, action_type:action_type},
          success : function(data){
            if (data.code == "200"){
              location.reload();
              Swal.fire('Saved!', '', 'success'); 
            } else {
              Swal.fire({
                icon: 'error',
                title: 'Oops...',
                text: data.msg,
              })
            }
          }
        });
      });


      $('#btnedit').click(function(e){
        e.preventDefault();
        let employee_id = $("#employee_id_edit").val();
        let employee_code = $("#employee_code_edit").val();
        let employee_name = $("#employee_name_edit").val();
        let action_type = $("#action_type_edit").val();
        let employee_salarys = parseFloat(employee_salary_edit.getNumericString());

        $.ajax({
          type: "POST",
          url: "<?php echo base_url(); ?>Masterdata/processaddemployee",
          dataType: "json",
          data: {employee_id:employee_id, employee_code:employee_code, employee_name:employee_name, employee_salary:employee_salarys, action_type:action_type},
          success : function(data){
            if (data.code == "200"){
              location.reload();
              Swal.fire('Saved!', '', 'success'); 
            } else {
              Swal.fire({
                icon: 'error',
                title: 'Oops...',
                text: data.msg,
              })
            }
          }
        });
      });

    });

  </script>

  <script type="text/javascript">
    function deletes(id, name){
      Swal.fire({
        title: 'Konfirmasi?',
        text: "Apakah Anda Yakin Menghapus Data Karyawan '"+name+"' ?",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Hapus'
      }).then((result) => {
        if (result.isConfirmed) {
          window.location.replace('<?php echo base_url();?>Masterdata/deleteemployee?id='+id);
          Swal.fire(
            'Hapus!',
            'Sukses Hapus Data.',
            'Sukses'
            )
        }
      })
    }
  </script>