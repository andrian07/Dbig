  <?php 
  
  define('DOC_ROOT_PATH', $_SERVER['DOCUMENT_ROOT'].'/');
  require DOC_ROOT_PATH . $this->config->item('headerlink');
  ?>


  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Master Barang</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="<?php echo base_url(); ?>Admin">Home</a></li>
              <li class="breadcrumb-item active">Master Barang</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">

      <!-- Default box -->
      <div class="card">
        <div class="card-header">
          <h3 class="card-title">Daftar Barang</h3>
          <div class="card-tools">

            <button class="btn btn-primary" data-toggle="modal" data-target="#exampleModal"><i class="fas fa-plus"></i> Tambah</button>

            <!-- popup add -->
            <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
              <div class="modal-dialog" role="document">
                <div class="modal-content">
                  <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Input Barang</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                      <span aria-hidden="true">&times;</span>
                    </button>
                  </div>
                  <div class="modal-body">
                    <div class="form-group">
                      <label>Kode Barang</label>
                      <input type="hidden" class="form-control" id="action_type" value="add" readonly>
                      <input type="text" class="form-control" id="item_code" placeholder="Kode Barang">
                    </div>
                    <div class="form-group">
                      <label>Nama</label>
                      <input type="text" class="form-control" id="item_name" placeholder="Nama Barang">
                    </div>
                    <div class="form-group">
                      <label>Satuan</label>
                      <select id="item_weight_id" class="form-control select2" style="width: 100%;">
                        <option value="">-- Pilih Satuan --</option>
                        <?php foreach($datas['list_weight'] as $row){ ?>
                          <option value="<?php echo $row->weight_id ?>"><?php echo $row->weight_code ?></option>
                        <?php } ?>
                      </select>
                    </div>
                    <div class="form-group">
                      <label>Tipe Barang</label>
                      <select id="item_type" class="form-control" style="width: 100%;">
                        <option value="">-- Pilih Tipe Barang --</option>
                        <option value="stock">stock</option>
                        <option value="inventaris">inventaris</option>
                      </select>
                    </div>
                  </div>
                  <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button id="btnadd"  type="button" class="btn btn-primary">Save changes</button>
                  </div>
                </div>
              </div>
            </div>
            
            <!-- end popup add -->

            <!-- popup Edit -->
            <div class="modal fade" id="exampleModaledit" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
              <div class="modal-dialog" role="document">
                <div class="modal-content">
                  <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Tambah Customer</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                      <span aria-hidden="true">&times;</span>
                    </button>
                  </div>
                  <div class="modal-body">
                    <div class="modal-body">
                      <div class="form-group">
                        <label>Kode Barang</label>
                        <input type="hidden" class="form-control" id="action_type_edit" value="edit" readonly>
                        <input type="hidden" class="form-control" id="item_id_edit"  readonly>
                        <input type="text" class="form-control" id="item_code_edit"  readonly>
                      </div>
                      <div class="form-group">
                        <label>Nama</label>
                        <input type="text" class="form-control" id="item_name_edit" placeholder="Nama Barang">
                      </div>
                      <div class="form-group">
                        <label>Satuan</label>
                        <select id="item_weight_id_edit" class="form-control select2" style="width: 100%;">
                          <?php foreach($datas['list_weight'] as $row){ ?>
                            <option value="<?php echo $row->weight_id ?>"><?php echo $row->weight_code ?></option>
                          <?php } ?>
                        </select>
                      </div>
                      <div class="form-group">
                        <label>Tipe Barang</label>
                        <select id="item_type_edit" class="form-control" style="width: 100%;">
                          <option value="stock">stock</option>
                          <option value="inventaris">inventaris</option>
                        </select>
                      </div>
                    </div>
                  </div>
                  <div class="modal-footer">

                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-info" id="btnedit">Edit</button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="card-body">
          <table id="example" class="table table-striped table-bordered dataTable no-footer" style="width:100%">
            <thead>
              <tr>
                <th>Kode Item</th>
                <th>Nama</th>
                <th>Satuan</th>
                <th>Total Item </th>
                <th>Total Dipinjam</th>
                <th>Jenis</th>
                <th>Aksi</th>
              </tr>
            </thead>
            <tbody>
              <?php foreach($datas['list_item'] as $row){ ?>
                <tr>
                  <td><?php echo $row->item_code; ?></td> 
                  <td><?php echo $row->item_name; ?></td>
                  <td><?php echo $row->weight_code; ?></td>
                  <td><?php echo $row->item_total_qty; ?></td>
                  <td><?php echo $row->item_total_rent; ?></td>
                  <td><?php echo $row->item_type; ?></td>
                  <td>
                    <button data-id="<?php echo $row->item_id; ?>" data-code="<?php echo $row->item_code; ?>" data-name="<?php echo $row->item_name; ?>" data-weight="<?php echo $row->item_weight_id; ?>" data-type="<?php echo $row->item_type; ?>" class="btn btn-sm btn-warning table-menu" data-toggle="modal" data-target="#exampleModaledit"><i class="fas fa-edit"></i></button>
                    <button class="btn btn-sm btn-danger table-menu" onclick="deletes('<?php echo $row->item_id; ?>', '<?php echo $row->item_name; ?>')" data-title="Hapus"><i class="fas fa-trash"></i></button>
                  </td>
                </tr>
              <?php } ?>
            </tbody>
          </table>
        </div>
        <!-- /.card-body -->
        <div class="card-footer">

        </div>
        <!-- /.card-footer-->
      </div>
      <!-- /.card -->

    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  <!-- /.content-wrapper -->

  <?php 
  require DOC_ROOT_PATH . $this->config->item('footerlink');
  ?>

  <script type="text/javascript">
    $(document).ready(function() {

      $("#item_weight_id").select2({
        tags: true,
        dropdownParent: $("#exampleModal")
      });
      
      $('#exampleModaledit').on('show.bs.modal', function (event) {
        var button = $(event.relatedTarget) // Button that triggered the modal
        var item_id_edit   = button.data('id')
        var item_code_edit   = button.data('code')
        var item_name_edit  = button.data('name')
        var item_weight_edit  = button.data('weight')
        var item_type_edit  = button.data('type')

        var modal = $(this)
        modal.find('.modal-title').text('Edit ' + item_name_edit)
        modal.find('#item_id_edit').val(item_id_edit)
        modal.find('#item_code_edit').val(item_code_edit)
        modal.find('#item_name_edit').val(item_name_edit)
        modal.find('#item_weight_edit').val(item_weight_edit)
        modal.find('#item_type_edit').val(item_type_edit)
      })

      $('#btnadd').click(function(e){
        e.preventDefault();
        let item_code = $("#item_code").val();
        let item_name = $("#item_name").val();
        let item_weight_id = $("#item_weight_id").val();  
        let item_type = $("#item_type").val();
        let action_type = $("#action_type").val();

        $.ajax({
          type: "POST",
          url: "<?php echo base_url(); ?>Masterdata/processadditem",
          dataType: "json",
          data: {item_code:item_code, item_type:item_type, item_name:item_name, item_weight_id:item_weight_id, action_type:action_type},
          success : function(data){
            if (data.code == "200"){
              location.reload();
              Swal.fire('Saved!', '', 'success'); 
            } else {
              Swal.fire({
                icon: 'error',
                title: 'Oops...',
                text: data.msg,
              })
            }
          }
        });
      });


      $('#btnedit').click(function(e){
        e.preventDefault();
        let item_id = $("#item_id_edit").val();
        let item_code = $("#item_code_edit").val();
        let item_name = $("#item_name_edit").val();
        let item_weight_id = $("#item_weight_id_edit").val();
        let item_type = $("#item_type_edit").val();
        let action_type = $("#action_type_edit").val();

        $.ajax({
          type: "POST",
          url: "<?php echo base_url(); ?>Masterdata/processadditem",
          dataType: "json",
          data: {item_id:item_id, item_code:item_code, item_type:item_type, item_name:item_name, item_weight_id:item_weight_id, action_type:action_type},
          success : function(data){
            if (data.code == "200"){
              location.reload();
              Swal.fire('Saved!', '', 'success'); 
            } else {
              Swal.fire({
                icon: 'error',
                title: 'Oops...',
                text: data.msg,
              })
            }
          }
        });
      });

    });

    function setfootervalue(){
      let actUrl = base_url + '/webmin/purchase-order/get-po-footer';
      ajax_get(actUrl, null, {
        success: function(response) { 

          if (response.result.success == 'TRUE') {

            if(response.result.data.length > 0){
              if(response.result.data[0].subTotal == 'null'){
                footer_sub_total.set(0);
                footer_total_ongkir.set(0);
              }else{

                footer_sub_total.set(response.result.data[0].subTotal);
                footer_total_ongkir.set(response.result.data[0].totalOngkir);
              }
              calculation_temp_total_footer();
            }
          } else {
            message.error(response.result.message);
          }
        }
      });
    }

  </script>

  <script type="text/javascript">
    function deletes(id, name){
      Swal.fire({
        title: 'Konfirmasi?',
        text: "Apakah Anda Yakin Menghapus Data Barang '"+name+"' ?",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Hapus'
      }).then((result) => {
        if (result.isConfirmed) {
          window.location.replace('<?php echo base_url();?>Masterdata/deleteitem?id='+id);
          Swal.fire(
            'Hapus!',
            'Sukses Hapus Data.',
            'Sukses'
            )
        }
      })
    }
  </script>