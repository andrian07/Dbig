  <?php 
  
  define('DOC_ROOT_PATH', $_SERVER['DOCUMENT_ROOT'].'/');
  require DOC_ROOT_PATH . $this->config->item('headerlink');
  ?>


  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Master Pelanggan</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="<?php echo base_url(); ?>Admin">Home</a></li>
              <li class="breadcrumb-item active">Master Pelanggan</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">

      <!-- Default box -->
      <div class="card">
        <div class="card-header">
          <h3 class="card-title">Daftar Pelanggan</h3>
          <div class="card-tools">

            <button class="btn btn-primary" data-toggle="modal" data-target="#exampleModal"><i class="fas fa-plus"></i> Tambah</button>

            <!-- popup add -->
            <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
              <div class="modal-dialog" role="document">
                <div class="modal-content">
                  <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Input Pelanggan</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                      <span aria-hidden="true">&times;</span>
                    </button>
                  </div>
                  <div class="modal-body">
                    <div class="form-group">
                      <label>Nama Pelanggan</label>
                      <input type="text" class="form-control" id="customer_name" placeholder="Nama Pelanggan">
                    </div>
                    <div class="form-group">
                      <label>Alamat</label>
                      <textarea class="form-control" id="customer_address"></textarea>
                    </div>
                    <div class="form-group">
                      <label>No Telepon</label>
                      <input type="text" class="form-control" id="customer_phone" placeholder="No Telepon">
                    </div>
                    <div class="form-group">
                      <label>No NPWP</label>
                      <input type="text" class="form-control" id="customer_npwp" placeholder="No NPWP">
                    </div>

                  </div>
                  <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button id="btnadd"  type="button" class="btn btn-primary">Save changes</button>
                  </div>
                </div>
              </div>
            </div>
            
            <!-- end popup add -->

            <!-- popup Edit -->
            <div class="modal fade" id="exampleModaledit" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
              <div class="modal-dialog" role="document">
                <div class="modal-content">
                  <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Edit Pelanggan</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                      <span aria-hidden="true">&times;</span>
                    </button>
                  </div>
                  <div class="modal-body">
                    <div class="form-group">
                      <label>Nama Pelanggan</label>
                      <input type="hidden" class="form-control" id="customer_id_edit" >
                      <input type="text" class="form-control" id="customer_name_edit" placeholder="Nama Pelanggan">
                    </div>
                    <div class="form-group">
                      <label>Keterangan</label>
                      <textarea class="form-control" id="customer_address_edit"></textarea>
                    </div>
                    <div class="form-group">
                      <label>No Telepon</label>
                      <input type="text" class="form-control" id="customer_phone_edit" placeholder="No Telepon">
                    </div>
                    <div class="form-group">
                      <label>No NPWP</label>
                      <input type="text" class="form-control" id="customer_npwp_edit" placeholder="No NPWP">
                    </div>
                  </div>
                  <div class="modal-footer">

                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-info" id="btnedit">Edit</button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="card-body">
          <table id="example" class="table table-striped table-bordered dataTable no-footer" style="width:100%">
            <thead>
              <tr>
                <th>Nama Pelanggan</th>
                <th>Alamat</th>
                <th>No Hp</th>
                <th>No NPWP</th>
                <th>Aksi</th>
              </tr>
            </thead>
            <tbody>
              <?php foreach($list_customer as $row){ ?>
                <tr>
                  <td><?php echo $row->customer_name; ?></td>
                  <td><?php echo $row->customer_address; ?></td>
                  <td><?php echo $row->customer_phone; ?></td>
                  <td><?php echo $row->customer_npwp; ?></td>
                  <td>
                    <button data-id="<?php echo $row->customer_id ; ?>" data-name="<?php echo $row->customer_name; ?>" data-address="<?php echo $row->customer_address; ?>" data-phone="<?php echo $row->customer_phone; ?>" data-npwp="<?php echo $row->customer_npwp; ?>" class="btn btn-sm btn-warning table-menu" data-toggle="modal" data-target="#exampleModaledit"><i class="fas fa-edit"></i></button>
                    <button class="btn btn-sm btn-danger table-menu" onclick="deletes('<?php echo $row->customer_id; ?>', '<?php echo $row->customer_name; ?>')" data-title="Hapus"><i class="fas fa-trash"></i></button>
                  </td>
                </tr>
              <?php } ?>
            </tbody>
          </table>
        </div>
        <!-- /.card-body -->
        <div class="card-footer">

        </div>
        <!-- /.card-footer-->
      </div>
      <!-- /.card -->

    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  <!-- /.content-wrapper -->

  <?php 
  require DOC_ROOT_PATH . $this->config->item('footerlink');
  ?>

  <script type="text/javascript">
    $(document).ready(function() {

      $('#exampleModaledit').on('show.bs.modal', function (event) {
        var button = $(event.relatedTarget) // Button that triggered the modal
        var customer_id_edit   = button.data('id')
        var customer_name_edit = button.data('name')
        var customer_address_edit = button.data('address')
        var customer_phone_edit = button.data('phone')
        var customer_npwp_edit = button.data('npwp')

        var modal = $(this)
        modal.find('.modal-title').text('Edit ' + customer_name_edit)
        modal.find('#customer_id_edit').val(customer_id_edit)
        modal.find('#customer_name_edit').val(customer_name_edit)
        modal.find('#customer_address_edit').val(customer_address_edit)
        modal.find('#customer_phone_edit').val(customer_phone_edit)
        modal.find('#customer_npwp_edit').val(customer_npwp_edit)
      })

      $('#btnadd').click(function(e){
        e.preventDefault();
        let customer_name = $("#customer_name").val();
        let customer_address = $("#customer_address").val();
        let customer_phone = $("#customer_phone").val();
        let customer_npwp = $("#customer_npwp").val();
        let action_type = 'add';

        $.ajax({
          type: "POST",
          url: "<?php echo base_url(); ?>Masterdata/processaddcustomer",
          dataType: "json",
          data: {customer_name:customer_name, customer_address:customer_address, customer_phone:customer_phone, customer_npwp:customer_npwp, action_type:action_type},
          success : function(data){
            if (data.code == "200"){
              location.reload();
              Swal.fire('Saved!', '', 'success'); 
            } else {
              Swal.fire({
                icon: 'error',
                title: 'Oops...',
                text: data.msg,
              })
            }
          }
        });
      });


      $('#btnedit').click(function(e){
        e.preventDefault();
        let customer_id = $("#customer_id_edit").val();
        let customer_name = $("#customer_name_edit").val();
        let customer_address = $("#customer_address_edit").val();
        let customer_phone = $("#customer_phone_edit").val();
        let customer_npwp = $("#customer_npwp_edit").val();
        let action_type = 'edit';

        $.ajax({
          type: "POST",
          url: "<?php echo base_url(); ?>Masterdata/processaddcustomer",
          dataType: "json",
          data: {customer_id:customer_id, customer_name:customer_name, customer_address:customer_address, customer_phone:customer_phone, customer_npwp:customer_npwp, action_type:action_type},
          success : function(data){
            if (data.code == "200"){
              location.reload();
              Swal.fire('Saved!', '', 'success'); 
            } else {
              Swal.fire({
                icon: 'error',
                title: 'Oops...',
                text: data.msg,
              })
            }
          }
        });
      });

    });

  </script>

  <script type="text/javascript">
    function deletes(id, name){
      Swal.fire({
        title: 'Konfirmasi?',
        text: "Apakah Anda Yakin Menghapus Data Pelanggan '"+name+"' ?",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Hapus'
      }).then((result) => {
        if (result.isConfirmed) {
          window.location.replace('<?php echo base_url();?>Masterdata/deletecustomer?id='+id);
          Swal.fire(
            'Hapus!',
            'Sukses Hapus Data.',
            'Sukses'
            )
        }
      })
    }
  </script>