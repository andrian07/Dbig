  <?php 
  
  define('DOC_ROOT_PATH', $_SERVER['DOCUMENT_ROOT'].'/');
  require DOC_ROOT_PATH . $this->config->item('headerlink');
  ?>


  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Master Berat</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="<?php echo base_url(); ?>Admin">Home</a></li>
              <li class="breadcrumb-item active">Master Berat</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">

      <!-- Default box -->
      <div class="card">
        <div class="card-header">
          <h3 class="card-title">Daftar Berat</h3>
          <div class="card-tools">

            <button class="btn btn-primary" data-toggle="modal" data-target="#exampleModal"><i class="fas fa-plus"></i> Tambah</button>

            <!-- popup add -->
            <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
              <div class="modal-dialog" role="document">
                <div class="modal-content">
                  <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Input Berat</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                      <span aria-hidden="true">&times;</span>
                    </button>
                  </div>
                  <div class="modal-body">
                    <div class="form-group">
                      <label>Kode Berat</label>
                      <input type="text" class="form-control" id="weight_code" placeholder="Kode Berat (KG)">
                    </div>
                    <div class="form-group">
                      <label>Nama Berat</label>
                      <input type="text" class="form-control" id="weight_name" placeholder="Nama Berat (Kilogram)">
                    </div>

                  </div>
                  <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button id="btnadd"  type="button" class="btn btn-primary">Save changes</button>
                  </div>
                </div>
              </div>
            </div>
            
            <!-- end popup add -->

            <!-- popup Edit -->
            <div class="modal fade" id="exampleModaledit" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
              <div class="modal-dialog" role="document">
                <div class="modal-content">
                  <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Edit Berat</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                      <span aria-hidden="true">&times;</span>
                    </button>
                  </div>
                  <div class="modal-body">
                      <div class="form-group">
                      <label>Kode Berat</label>
                      <input type="hidden" class="form-control" id="weight_id_edit">
                      <input type="text" class="form-control" id="weight_code_edit" placeholder="Kode Berat (KG)">
                    </div>
                    <div class="form-group">
                      <label>Nama Berat</label>
                      <input type="text" class="form-control" id="weight_name_edit" placeholder="Nama Berat (Kilogram)">
                    </div>
                  </div>
                  <div class="modal-footer">

                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-info" id="btnedit">Edit</button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="card-body">
          <table id="example" class="table table-striped table-bordered dataTable no-footer" style="width:100%">
            <thead>
              <tr>
                <th>Kode Berat</th>
                <th>Nama</th>
                <th>Aksi</th>
              </tr>
            </thead>
            <tbody>
              <?php foreach($list_weight as $row){ ?>
                <tr>
                  <td><?php echo $row->weight_code; ?></td>
                  <td><?php echo $row->weight_name; ?></td>
                  <td>
                    <button data-id="<?php echo $row->weight_id ; ?>" data-code="<?php echo $row->weight_code; ?>" data-name="<?php echo $row->weight_name; ?>"  class="btn btn-sm btn-warning table-menu" data-toggle="modal" data-target="#exampleModaledit"><i class="fas fa-edit"></i></button>
                    <button class="btn btn-sm btn-danger table-menu" onclick="deletes('<?php echo $row->weight_id; ?>', '<?php echo $row->weight_code; ?>')" data-title="Hapus"><i class="fas fa-trash"></i></button>
                  </td>
                </tr>
              <?php } ?>
            </tbody>
          </table>
        </div>
        <!-- /.card-body -->
        <div class="card-footer">

        </div>
        <!-- /.card-footer-->
      </div>
      <!-- /.card -->

    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  <!-- /.content-wrapper -->

  <?php 
  require DOC_ROOT_PATH . $this->config->item('footerlink');
  ?>

  <script type="text/javascript">
    $(document).ready(function() {

      $('#exampleModaledit').on('show.bs.modal', function (event) {
        var button = $(event.relatedTarget) // Button that triggered the modal
        var weight_id_edit   = button.data('id')
        var weight_code_edit = button.data('code')
        var weight_name_edit = button.data('name')

        var modal = $(this)
        modal.find('.modal-title').text('Edit ' + weight_name_edit)
        modal.find('#weight_id_edit').val(weight_id_edit)
        modal.find('#weight_code_edit').val(weight_code_edit)
        modal.find('#weight_name_edit').val(weight_name_edit)
      })

      $('#btnadd').click(function(e){
        e.preventDefault();
        let weight_code = $("#weight_code").val();
        let weight_name = $("#weight_name").val();
        let action_type = 'add';

        $.ajax({
          type: "POST",
          url: "<?php echo base_url(); ?>Masterdata/processaddweight",
          dataType: "json",
          data: {weight_code:weight_code, weight_name:weight_name, action_type:action_type},
          success : function(data){
            if (data.code == "200"){
              location.reload();
              Swal.fire('Saved!', '', 'success'); 
            } else {
              Swal.fire({
                icon: 'error',
                title: 'Oops...',
                text: data.msg,
              })
            }
          }
        });
      });


      $('#btnedit').click(function(e){
        e.preventDefault();
        let weight_id = $("#weight_id_edit").val();
        let weight_name  = $("#weight_name_edit").val();
        let weight_code = $("#weight_code_edit").val();
        let action_type = 'edit';

        $.ajax({
          type: "POST",
          url: "<?php echo base_url(); ?>Masterdata/processaddweight",
          dataType: "json",
          data: {weight_id:weight_id, weight_code:weight_code, weight_name:weight_name, action_type:action_type},
          success : function(data){
            if (data.code == "200"){
              location.reload();
              Swal.fire('Saved!', '', 'success'); 
            } else {
              Swal.fire({
                icon: 'error',
                title: 'Oops...',
                text: data.msg,
              })
            }
          }
        });
      });

    });

  </script>

  <script type="text/javascript">
    function deletes(id, name){
      Swal.fire({
        title: 'Konfirmasi?',
        text: "Apakah Anda Yakin Menghapus Data Berat '"+name+"' ?",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Hapus'
      }).then((result) => {
        if (result.isConfirmed) {
          window.location.replace('<?php echo base_url();?>Masterdata/deleteweight?id='+id);
          Swal.fire(
            'Hapus!',
            'Sukses Hapus Data.',
            'Sukses'
            )
        }
      })
    }
  </script>