
<!-- DEBUG-VIEW START 1 APPPATH/Views/webmin/purchase/purchaseorder_invoice.php -->
<!DOCTYPE html>
<html>
<head>


  <!-- Google Font: Source Sans Pro -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="<?php echo base_url(); ?>asset/plugins/invoice/invoice.css">
  <title></title>
</head>
<body>
  <div class="invoice-a4">

    <div class="letterhead">
      <div class="letterhead-left-new" style="width:49%; float: left;">
        <div style="text-align: left;"> 
          <h2 style="color:#000000; margin-left:0px;">PT. Dua Putri Marine</h2>
        </div>
      </div>
      <div class="letterhead-right-new" style="width:50%; float: right;">
        <div style="text-align: right; padding-right: 5%;"> 
          <h2 style="text-decoration: underline; color:#000000">BON PESANAN</h2>
        </div>
      </div>
    </div>

    <div class="content-invoice">
      <?php foreach($datas['getPoHd'] as $row) { ?>
        <div class="header-info">
          
          <div class="header-info-left-po">
            <table>
              <tr>
                <td><?php echo Address; ?></td>
              </tr>
              <tr>
                <td>NPWP: 42.260.106.2-702</td>
              </tr>
            </table>
          </div>
          <div class="header-info-rihgt-po">
            <table>
              <tr>
                <td>Pontianak, </td><td>:</td><td><?php $date = date_create($row->hd_po_date); echo date_format($date,"d-M-Y"); ?></td>
              </tr>
              <tr>
                <td>No Pesanan</td><td>:</td><td><?php echo $row->hd_po_invoice; ?></td>
              </tr>
              <tr>
                <td>Kepada Yth, </td><td></td><td><?php echo $row->supplier_name; ?></td>
              </tr>
              <tr>
                <td colspan="3"><?php echo $row->supplier_address; ?></td>
              </tr>
              <tr>
                <td colspan="3"><?php echo $row->supplier_phone; ?></td>
              </tr>
            </table>
          </div>
        </div>
      <?php } ?>
      <table class="item">
        <thead>
         <tr>
          <th>Kode</th>
          <th>Nama Barang</th>
          <th>Kwantitas</th>
        </tr>
      </thead>
      <tbody>

       <?php 
       $i = 1;
       foreach($datas['getPoDetail'] as $row){ ?>
        <tr>
          <td class="text-center"><?php echo $row->item_code ?></td>
          <td><?php echo $row->item_name ?></td>
          <td class="text-center"><?php echo $row->dt_item_qty ?></td>
        </tr>
        <?php 
        $i ++;
      } ?>
      <?php
      $row_min = 9 - $datas['getCountpo'][0]->total_row;
      for($j = 1; $j < $row_min; $j++){ ?>
        <tr>
          <td class="text-center" style="height: 15px;"></td>
          <td></td>
          <td></td>
        </tr>
        <?php 
      } ?>
    </tbody>
</table>
</div>

<table style="text-align:center; margin-top: 50px; width: 100%;">
  <tr>
    <td width="50%">Disetujui,<br /><br /><br /><br /><br />
      (&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;)
    </td>
    <td width="50%">Hormat Kami,<br /><br /><br /><br /><br />
      (&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;)
    </td>
  </tr>
</table>
</div>
</body>
</html>
<!-- DEBUG-VIEW ENDED 1 APPPATH/Views/webmin/purchase/purchaseorder_invoice.php -->
