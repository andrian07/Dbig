<!DOCTYPE html>
<html>
<head>


  <!-- Google Font: Source Sans Pro -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="<?php echo base_url(); ?>asset/plugins/invoice/invoice.css">
  <title></title>
</head>
<body>
  <div class="invoice-a4">

    <div class="letterhead">
      <div class="left letterhead-left text-right"><img src="<?php echo base_url(); ?>asset/images/logoDPM.png" alt="Logo DPM" width="50%"></div>
      <div class="right letterhead-right">
        <h2>PT. Dua Putri Marine</h2>
        <P> <?php echo Address; ?> </P>
      </div>
    </div>
    <div class="letterhead-border">&nbsp;&nbsp;</div>

    <div class="content-invoice">
      <?php foreach($datas['getPoHd'] as $row) { ?>
        <h3 class="text-center">PURCHASE ORDER</h3>
        <table class="info-date">
          <tr>
            <td>Date</td><td>:</td><td><?php $date = date_create($row->hd_po_date); echo date_format($date,"d-M-Y"); ?></td>
          </tr>
          <tr>
            <td>PO</td><td>:</td><td><?php echo $row->hd_po_invoice; ?></td>
          </tr>
        </table>

        <div class="address-content">
          <div class="left address-content-left">
            <h4 style="text-decoration: underline;">Kepada Yth</h4>
            <h4 style="margin-top: -19px;"><?php echo $row->supplier_name; ?></h4>
            <P style="width: 80%;"><?php echo $row->supplier_address; ?></P>
          </div>
          <div class="right address-content-right">
            <h4 style="text-decoration: underline;">Dari </h4>
            <h4 style="margin-top: -19px;">PT. Dua Putri Marine</h4>
            <p> <?php echo Address; ?></p>
          </div>
        </div>
      <?php } ?>
      <table class="item">
        <thead>
         <tr>
          <th>Nama Barang</th>
          <th>Harga</th>
          <th>Qty</th>
          <th>subtotal</th>
        </tr>
      </thead>
      <tbody>
       <?php foreach($datas['getPoDetail'] as $row){ ?>
        <tr>
          <td><?php echo $row->item_name ?></td>
          <td class="text-center">Rp. <?php echo number_format($row->dt_item_price) ?></td>
          <td class="text-center"><?php echo $row->dt_item_qty ?></td>
          <td class="text-center">Rp. <?php echo number_format($row->dt_item_total) ?></td>
        </tr>
      <?php } ?>
    </tbody>
    <tfoot>
       <?php foreach($datas['getPoHd'] as $row) { ?>
      <tr>
        <td colspan="2"></td>
        <th>Discount</th>
        <th class="text-center">Rp. <?php echo number_format($row->hd_po_discount) ?></th>
      </tr>
      <tr>
        <td colspan="2"></td>
        <th>PPN (11%)</th>
        <th class="text-center">Rp. <?php echo number_format($row->hd_po_ppn) ?></th>
      </tr>
      <tr>
        <td colspan="2"></td>
        <th>Total</th>
        <th class="text-center">Rp. <?php echo number_format($row->hd_po_total) ?></th>
      </tr>
    <?php } ?>
    </tfoot>
  </table>
</div>




<div class="ttd-div">
  <?php foreach($datas['getPoHd'] as $row) { ?>
  <p class="text-right" style="margin-right: 100px;">Pontiank, <?php $date = date_create($row->hd_po_date); echo date_format($date,"d-M-Y"); ?></p>
   <?php } ?>
  <p class="text-right" style="margin-right: 120px;">Hormat Kami,</p>
  <p class="text-right" style="margin-right: 60px; font-size: 17px;margin-top: 5px;">PT. DUA PUTRI MARINE</p>
  <p class="text-right" style="text-decoration: underline; margin-right: 140px; margin-top: 100px; font-size: 17px;">MIDI</p>
</div>
</div>
</body>
</html>
<!-- DEBUG-VIEW ENDED 1 APPPATH/Views/webmin/purchase/purchaseorder_invoice.php -->

