  <?php 
  
  define('DOC_ROOT_PATH', $_SERVER['DOCUMENT_ROOT'].'/');
  require DOC_ROOT_PATH . $this->config->item('headerlink');
  ?>

  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Edit Purchase Order</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="<?php echo base_url(); ?>Admin">Home</a></li>
              <li class="breadcrumb-item active">Edit Purchase Order</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="card card-default">
        <div class="card-header">
          <h3 class="card-title">Form Edit PO</h3>

          <div class="card-tools">
            <button type="button" class="btn btn-tool" data-card-widget="collapse">
              <i class="fas fa-minus"></i>
            </button>
          </div>
        </div>
        <!-- /.card-header -->

        <div class="card-body">

          <div class="row">
            <div class="col-md-4">
              <div class="form-group">
                <label class="col-form-label">No Invoice:</label>
                <input type="hidden" class="form-control" value="<?php echo $_GET['id']; ?>" readonly="">
                <input type="text" class="form-control" value="AUTO" readonly="">
              </div>
              <div class="row">
                <div class="col-md-6">
                  <div class="form-group">
                    <label class="col-form-label">Tanggal:</label>
                    <input type="date" class="form-control" id="date" value="2023-01-02">
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="form-group">
                    <label class="col-form-label">Tempo:</label>
                    <input type="date" class="form-control" id="duedate" value="2023-01-02">
                  </div>
                </div>
              </div>
            </div>
            <div class="col-md-4">
              <div class="row">
                <div class="col-md-12">
                  <div class="form-group">
                    <label class="col-form-label">Supplier:</label>
                    <select id="supplier_id" class="form-control select2" style="width: 100%;">
                      <option></option>
                      <?php foreach($datas['list_supplier'] as $row){ ?>
                        <option value="<?php echo $row->supplier_id ?>"><?php echo $row->supplier_name ?></option>
                      <?php } ?>
                    </select>
                  </div>
                  <div class="form-group">
                    <label class="col-form-label">Dibuat Oleh:</label>
                    <input type="text" class="form-control" id="user_id" value="<?php echo $_SESSION['user_name']; ?>" readonly="">
                  </div>  
                </div>
              </div>

            </div>
            <div class="col-md-4">
              <div class="form-group">
                <label class="col-form-label">Jenis Pembelian:</label>
                <select id="po_type" class="form-control" style="width: 100%;">
                  <option></option>
                  <option value="inventaris">inventaris</option>
                  <option value="stock">stock</option>
                </select>
              </div>

              <div class="form-group">
                <label class="col-form-label">Alamat Pengantaran:</label>
                <select id="address" class="form-control" style="width: 100%;">
                  <option></option>
                  <?php foreach($datas['list_warehouse'] as $row){ ?>
                    <option value="<?php echo $row->warehouse_id ?>"><?php echo $row->warehouse_name ?></option>
                  <?php } ?>
                </select>
              </div>
            </div>


          </div>
        </div>
        <!-- /.card-body -->
      </div>

      <!-- Default box -->
      <div class="card">
        <div class="card-header">
          <div class="row well well-sm">

            <div class="col-md-3">

              <label>Item:</label>
              <input type="hidden" id="temp_id" name="temp_id" class="form-control">
              <select id="temp_item" class="form-control select2" style="width: 100%;">
                <option></option>
                <?php foreach($datas['list_item'] as $row){ ?>
                  <option value="<?php echo $row->item_id ?>"><?php echo $row->item_name ?></option>
                <?php } ?>
              </select>

            </div>

            <div class="col-sm-3">
              <label>Harga Beli</label>
              <input type="text" id="temp_price" name="temp_price" class="form-control text-right calculation" value="0" required="" >
            </div>



            <div class="col-sm-2">

              <!-- text input -->

              <div class="form-group">

                <label>Qty</label>

                <input id="temp_qty" name="temp_qty" type="text" class="form-control text-right calculation" value="0" required="">

              </div>

            </div>

            <div class="col-sm-3">

              <!-- text input -->

              <div class="form-group">

                <label>Total</label>

                <input id="temp_total" name="temp_total" type="text" class="form-control text-right" value="0" readonly>

              </div>

            </div>

            <div class="col-sm-1">

              <!-- text input -->

              <label>&nbsp;</label>

              <div class="form-group">

                <button id="btnadd_temp" class="btn btn-md btn-primary rounded-circle float-right"><i class="fas fa-plus"></i></button>

              </div>

            </div>

          </div>
          <div class="card-body" style="padding:0 !important;">
            <table id="example" class="table table-striped table-bordered dataTable no-footer" style="width:100%">
              <thead>
                <tr>
                  <th>Nama Item</th>
                  <th>Harga</th>
                  <th>Qty</th>
                  <th>Total</th>
                  <th>Aksi</th>
                </tr>
              </thead>
              <tbody>
               <?php foreach($datas['list_temp_po'] as $row){ ?>
                <tr>
                  <td><?php echo $row->item_name; ?></td>
                  <td>Rp. <?php echo number_format($row->temp_item_price) ; ?></td>
                  <td><?php echo $row->temp_item_qty; ?></td>
                  <td>Rp. <?php echo number_format($row->temp_item_total); ?></td>
                  <td>
                    <button class="btn btn-sm btn-warning table-menu edittemp" data-id="<?php echo $row->temp_po_id; ?>" data-title="Edit"><i class="fas fa-edit"></i></button>
                    <button class="btn btn-sm btn-danger table-menu" onclick="deletes('<?php echo $row->temp_po_id; ?>', '<?php echo $row->item_name; ?>')" data-title="Hapus"><i class="fas fa-trash"></i></button>
                  </td>
                </tr>
              <?php } ?>
            </tbody>
          </table>
        </div>
        <!-- /.card-body -->
        <div class="row form-space footer-form">

          <div class="col-lg-5">

            <div class="form-group">

              <div class="col-sm-12">
               <textarea class="form-control" id="desc" rows="6" placeholder="Catatan"></textarea>
             </div>

           </div>

         </div>

         <div class="col-lg-7 text-right">

          <div class="form-group row">
            <label for="footer_sub_total" class="col-sm-7 col-form-label text-right:">Sub Total:</label>
            <div class="col-sm-5">
              <input id="footer_sub_total" name="footer_sub_total" type="text" class="form-control text-right" value="0" readonly="">
            </div>
          </div>

          <div class="form-group row">
            <label for="footer_total_discount" class="col-sm-7 col-form-label text-right:">Discount :</label>
            <div class="col-sm-3">
              <input id="footer_total_discount" name="footer_total_discount" type="text" class="form-control calculation_footer text-right" value="0">
            </div>
            <div class="col-sm-2">
              <input id="footer_total_discount_percentage" name="footer_total_discount_percentage" type="text" class="form-control calculation_percentage text-right" value="0">
            </div>
          </div>

          <div class="form-group row">
            <label for="footer_total_ppn" class="col-sm-7 col-form-label text-right:">PPN</label>
            <div class="col-sm-4">
              <input id="footer_total_ppn" name="footer_total_ppn" type="text" class="form-control text-right" value="0" readonly>
            </div>
            <div class="col-md-1">
              <div class="icheck-primary d-inline">
                <input type="checkbox" id="ppn_check" style="width:25px; height:25px;">
                <label for="ppn_check">
                </label>
              </div>
            </div>
          </div>

          <div class="form-group row">
            <label for="footer_total_invoice" class="col-sm-7 col-form-label text-right:">Grand Total :</label>
            <div class="col-sm-5">
              <input id="footer_total_invoice" name="footer_total_invoice" type="text" class="form-control text-right" value="0" readonly="">
            </div>
          </div>

          <div class="form-group row">
            <label for="footer_total_ppn" class="col-sm-7 col-form-label text-right:">DP</label>
            <div class="col-sm-5">
              <input id="footer_total_dp" name="footer_total_dp" type="text" class="form-control text-right calculation_dp" value="0">
            </div>
          </div>

          <div class="form-group row">
            <label for="footer_total_debt_remaining" class="col-sm-7 col-form-label text-right:">Sisa Pembayaran</label>
            <div class="col-sm-5">
              <input id="footer_total_debt_remaining" name="footer_total_debt_remaining" type="text" class="form-control text-right" value="0" readonly>
            </div>
          </div>

          <div class="form-group row">
            <div class="col-sm-12">
              <button id="btncancel" class="btn btn-danger"><i class="fas fa-times-circle"></i> Batal</button>
              <button id="btn_save" class="btn btn-success button-header-custom-save"><i class="fas fa-save"></i> Simpan</button>
            </div>
          </div>

        </div>


      </div>
      <!-- /.card-footer-->
    </div>
    <!-- /.card -->

  </section>
  <!-- /.content -->
</div>
<!-- /.content-wrapper -->
<!-- /.content-wrapper -->
<?php 
require DOC_ROOT_PATH . $this->config->item('footerlink');
?> 
<script type="text/javascript">

 $(document).ready(function() {
  let temp_price = new AutoNumeric('#temp_price', { currencySymbol : 'Rp. ' });
  let temp_total = new AutoNumeric('#temp_total', { currencySymbol : 'Rp. ' });
  let footer_sub_total = new AutoNumeric('#footer_sub_total', { currencySymbol : 'Rp. ' });
  let footer_total_discount = new AutoNumeric('#footer_total_discount', { currencySymbol : 'Rp. ' });
  let footer_total_discount_percentage = new AutoNumeric('#footer_total_discount_percentage', 'percentageUS2decPos');
  let footer_total_ppn = new AutoNumeric('#footer_total_ppn', { currencySymbol : 'Rp. ' });
  let footer_total_invoice = new AutoNumeric('#footer_total_invoice', { currencySymbol : 'Rp. ' });
  let footer_total_dp = new AutoNumeric('#footer_total_dp', { currencySymbol : 'Rp. ' });
  let footer_total_debt_remaining = new AutoNumeric('#footer_total_debt_remaining', { currencySymbol : 'Rp. ' });
  let temp_qty = new AutoNumeric('#temp_qty', 'integer');

  setfootervalue();

  $('#btnadd_temp').click(function(e){
    e.preventDefault();
    let temp_id = $("#temp_id").val();
    let temp_item = $("#temp_item").val();
    let temp_price_val = parseFloat(temp_price.getNumericString());
    let temp_qty_val = parseFloat(temp_qty.getNumericString());
    let temp_total_val = parseFloat(temp_total.getNumericString());
    let actiontype = 'add';

    $.ajax({
      type: "POST",
      url: "<?php echo base_url(); ?>Transaction/processaddtemppo",
      dataType: "json",
      data: {temp_id:temp_id, temp_item:temp_item, temp_price:temp_price_val, temp_qty:temp_qty_val, temp_total:temp_total_val, actiontype:actiontype},
      success : function(data){
        if (data.code == "200"){
          location.reload();
          Swal.fire('Saved!', '', 'success'); 
        } else {
          Swal.fire({
            icon: 'error',
            title: 'Oops...',
            text: data.msg,
          })
        }
      }
    });
  });

  $(document).on('input', '.calculation', function(e) {
    e.preventDefault();
    let temp_price_cal = parseFloat(temp_price.getNumericString());
    let temp_qty_cal = parseFloat(temp_qty.getNumericString());
    temp_total.set(temp_price_cal * temp_qty_cal);
  });

  $(document).on('input', '.calculation_footer', function(e) {
    e.preventDefault();
    let footer_sub_total_cal = parseFloat(footer_sub_total.getNumericString());
    let footer_total_discount_cal = parseFloat(footer_total_discount.getNumericString());
    let footer_total_dp_cal = parseFloat(footer_total_dp.getNumericString());
    footer_total_discount_percentage.set(footer_total_discount_cal / footer_sub_total_cal)
    footer_total_invoice.set(footer_sub_total_cal - footer_total_discount_cal);
    footer_total_debt_remaining.set(footer_sub_total_cal - footer_total_discount_cal);
    footer_total_ppn.set(0);
     footer_total_dp.set(0);
    $('#ppn_check').prop('checked', false);
  });

  $(document).on('input', '.calculation_percentage', function(e) {
    e.preventDefault();

    let footer_sub_total_cal = parseFloat(footer_sub_total.getNumericString());
    let footer_total_discount_percentage_cal = parseFloat(footer_total_discount_percentage.getNumericString());
    let footer_total_discount_cal = parseFloat(footer_total_discount.getNumericString());
    footer_total_discount.set(footer_total_discount_percentage_cal * footer_sub_total_cal)
    footer_total_invoice.set(footer_sub_total_cal - (footer_total_discount_percentage_cal * footer_sub_total_cal));
    footer_total_debt_remaining.set(footer_sub_total_cal - footer_total_discount_cal);
    footer_total_ppn.set(0);
     footer_total_dp.set(0);
    $('#ppn_check').prop('checked', false);
  });

  $(document).on('input', '#ppn_check', function(e) {
    e.preventDefault();
    if ($('#ppn_check').is(":checked"))
    {
      let footer_sub_total_cal = parseFloat(footer_sub_total.getNumericString());
      let footer_total_discount_percentage_cal = parseFloat(footer_total_discount_percentage.getNumericString());
      let footer_total_discount_cal = parseFloat(footer_total_discount.getNumericString());
      footer_total_ppn.set((footer_sub_total_cal - footer_total_discount_cal) * 0.11);
      footer_total_invoice.set(footer_sub_total_cal - footer_total_discount_cal + ((footer_sub_total_cal - footer_total_discount_cal) * 0.11));
      footer_total_debt_remaining.set(footer_sub_total_cal - footer_total_discount_cal + ((footer_sub_total_cal - footer_total_discount_cal) * 0.11));
       footer_total_dp.set(0);
    }else{
      footer_total_ppn.set(0);
      let footer_sub_total_cal = parseFloat(footer_sub_total.getNumericString());
      let footer_total_discount_cal = parseFloat(footer_total_discount.getNumericString());
      footer_total_invoice.set(footer_sub_total_cal - footer_total_discount_cal);
      footer_total_debt_remaining.set(footer_sub_total_cal - footer_total_discount_cal);
      footer_total_dp.set(0);
    }
  });

   $(document).on('input', '.calculation_dp', function(e) {
    e.preventDefault();
    let footer_total_invoice_cal = parseFloat(footer_total_invoice.getNumericString());
    let footer_total_dp_cal = parseFloat(footer_total_dp.getNumericString());
    footer_total_debt_remaining.set(footer_total_invoice_cal - footer_total_dp_cal);
  });




  function setfootervalue(){
    $.ajax({
      type: "GET",
      dataType: "json",
      url: "<?php echo base_url(); ?>Transaction/getPoFooter",
      success : function(data){
        if (data.code == "200"){
          footer_sub_total.set(data.sub_total); 
          footer_total_invoice.set(data.total_invoice);
          footer_total_debt_remaining.set(data.total_invoice);
        }
      }
    });
  }

  $('.edittemp').click(function(e){
    e.preventDefault();
    let id = $(this).attr("data-id");
    $.ajax({
      type: "GET",
      dataType: "json",
      url: "<?php echo base_url(); ?>Transaction/getEditTemp?id="+id,
      success : function(data){
        if (data.code == "200"){
         $("#temp_id").val(data.result.temp_po_id);
         $("#temp_item").select2("val", data.result.temp_item_id);
         temp_price.set(data.result.temp_item_price);
         temp_qty.set(data.result.temp_item_qty);
         temp_total.set(data.result.temp_item_total);
       }
     }
   });
  });



  $('#btn_save').click(function(e){
    e.preventDefault();
    let date = $("#date").val();
    let duedate = $("#duedate").val();
    let supplier_id = $("#supplier_id").val();
    let po_type = $("#po_type").val();
    let address = $("#address").val();
    let desc = $("#desc").val();

    let footer_sub_total_inp = parseFloat(footer_sub_total.getNumericString());
    let footer_total_discount_inp = parseFloat(footer_total_discount.getNumericString());
    let footer_total_discount_percentage_inp = parseFloat(footer_total_discount_percentage.getNumericString());
    let footer_total_ppn_inp = parseFloat(footer_total_ppn.getNumericString());
    let footer_total_invoice_inp = parseFloat(footer_total_invoice.getNumericString());
    let footer_total_dp_inp = parseFloat(footer_total_dp.getNumericString());
    let footer_total_debt_remaining_inp = parseFloat(footer_total_debt_remaining.getNumericString());
    let actiontype = 'add';

    $.ajax({
      type: "POST",
      url: "<?php echo base_url(); ?>Transaction/processsavepo",
      dataType: "json",
      data: {date:date, duedate:duedate, supplier_id:supplier_id, po_type:po_type, footer_sub_total_inp:footer_sub_total_inp, footer_total_discount_inp:footer_total_discount_inp, footer_total_discount_percentage_inp:footer_total_discount_percentage_inp, footer_total_ppn_inp:footer_total_ppn_inp, footer_total_invoice_inp:footer_total_invoice_inp, footer_total_dp_inp:footer_total_dp_inp, footer_total_debt_remaining_inp:footer_total_debt_remaining_inp, desc:desc, address:address, actiontype:actiontype},
      success : function(data){
        if (data.code == "200"){
          window.location.href = "<?php echo base_url(); ?>Transaction/purchaseorder";
          Swal.fire('Saved!', '', 'success'); 
        } else {
          Swal.fire({
            icon: 'error',
            title: 'Oops...',
            text: data.msg,
          })
        }
      }
    });
  });


});
</script>


<script type="text/javascript">
  function deletes(id, name){
    Swal.fire({
      title: 'Konfirmasi?',
      text: "Apakah Anda Yakin Menghapus Data Pesanan '"+name+"' ?",
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Hapus'
    }).then((result) => {
      if (result.isConfirmed) {
        window.location.replace('<?php echo base_url();?>Transaction/deleteTempPo?id='+id);
        Swal.fire(
          'Hapus!',
          'Sukses Hapus Data.',
          'Sukses'
          )
      }
    })
  }
</script>