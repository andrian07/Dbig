  <?php 
  
  define('DOC_ROOT_PATH', $_SERVER['DOCUMENT_ROOT'].'/');
  require DOC_ROOT_PATH . $this->config->item('headerlink');
  ?>


  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Purchase Order</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="<?php echo base_url(); ?>Admin">Home</a></li>
              <li class="breadcrumb-item active">Purchase Order</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">

      <!-- Default box -->
      <div class="card">
        <div class="card-header">
          <h3 class="card-title">Daftar Purchase Order</h3>
          <div class="card-tools">

            <a href="<?php echo base_url(); ?>Transaction/inputpo"><button class="btn btn-primary" data-toggle="modal" data-target="#exampleModal"><i class="fas fa-plus"></i> Tambah</button></a>
          </div>
        </div>
        <div class="card-body">
          <table id="example" class="table table-striped table-bordered dataTable no-footer" style="width:100%">
            <thead>
              <tr>
                <th>PO Invoice</th>
                <th>Tanggal</th>
                <th>Supplier</th>
                <th>Total</th>
                <th>Status PO</th>
                <th>Aksi</th>
              </tr>
            </thead>
            <tbody>
              <?php foreach($list_po as $row){ ?>
                <tr>
                  <td><?php echo $row->hd_po_invoice; ?></td>
                  <td><?php $date = date_create($row->hd_po_date); echo date_format($date,"d-M-Y"); ?></td>
                  <td><?php echo $row->supplier_name; ?></td>
                  <td>Rp. <?php echo number_format($row->hd_po_total); ?></td>
                    <td><?php if($row->hd_po_status == 'Cancel'){ echo '<span class="badge badge-danger">Batal</span>';}else if($row->hd_po_status == 'Selesai'){echo '<span class="badge badge-success">Selesai</span>';}else{ echo '<span class="badge badge-warning">Pending</span>';} ?></td>
                    <td>
                      <button class="btn btn-sm btn-warning table-menu btn-edit" data-id="<?php echo $row->hd_po_id; ?>"><i class="fas fa-edit"></i></button>
                      <a href="<?php echo base_url();?>Transaction/detailpo?id=<?php echo $row->hd_po_id ?>">
                      <button class="btn btn-sm btn-primary table-menu"><i class="fas fa-eye"></i></button>
                      </a>
                      <button class="btn btn-sm btn-danger table-menu" onclick="deletes('<?php echo $row->hd_po_id; ?>', '<?php echo $row->hd_po_invoice; ?>', '<?php echo $row->hd_po_status; ?>')" data-title="Hapus"><i class="fas fa-trash"></i></button>
                    </td>
                  </tr>
                <?php } ?>
              </tbody>
            </table>
          </div>
          <!-- /.card-body -->
          <div class="card-footer">

          </div>
          <!-- /.card-footer-->
        </div>
        <!-- /.card -->

      </section>
      <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->
    <!-- /.content-wrapper -->

    <?php 
    require DOC_ROOT_PATH . $this->config->item('footerlink');
    ?>

    <script type="text/javascript">

     $('.btn-edit').click(function(e){
      e.preventDefault();
      let id = $(this).attr("data-id");
      console.log(id);
      $.ajax({
        type: "GET",
        dataType: "json",
        url: "<?php echo base_url(); ?>Transaction/getPoDetail?id="+id,
        success : function(data){
          if (data.code == "200"){
            window.location.replace('<?php echo base_url();?>Transaction/inputpo?id='+id);
          }else{
           Swal.fire(
            'Warning!',
            data.msg,
            'warning'
            )
         }
       }
     });
    });

     function deletes(id, name, status){
      if(status != 'Pending'){
        Swal.fire(
          'Warning!',
          'Data Yang Sudah Di Proses Tidak Dapat Di Batalkan',
          'warning'
          )
      }else{
       Swal.fire({
        title: 'Konfirmasi?',
        text: "Apakah Anda Yakin Membatalkan Data PO '"+name+"' ?",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Hapus'
      }).then((result) => {
        if (result.isConfirmed) {
          window.location.replace('<?php echo base_url();?>Transaction/cancelPo?id='+id);
          Swal.fire(
            'Hapus!',
            'Sukses Hapus Data.',
            'Sukses'
            )
        }
      })
    }
  }
</script>