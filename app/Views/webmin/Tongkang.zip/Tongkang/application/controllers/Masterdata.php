<?php

defined('BASEPATH') OR exit('No direct script access allowed');
header('Access-Control-Allow-Origin: *');
header("Access-Control-Allow-Methods: GET, OPTIONS");

class Masterdata extends CI_Controller
{
    public function __construct(){
        parent::__construct();
        $this->load->helper('url');
        $this->load->model('M_masterdata');
        $this->load->library('session');
    }

    private function check_auth(){
        if(isset($_SESSION['user_name']) == null){
            redirect('Login', 'refresh');
        }
    }


    // employee //
    public function masteremployee()
    {
        $this->check_auth();
        $list_employee['list_employee'] = $this->M_masterdata->get_employee();
        $this->load->view('masterdata/masteremployee', $list_employee);
    }



    public function processaddemployee()
    {   

        $this->check_auth();
        $employee_id = $this->input->post('employee_id');
        $employee_code = $this->input->post('employee_code');
        $employee_name = $this->input->post('employee_name');
        $employee_salary = $this->input->post('employee_salary');
        $actiontype = $this->input->post('action_type');
        if($employee_code == 'AUTO'){
            $get_last_number = $this->M_masterdata->get_last_number();
            if($get_last_number == null){
                $employee_code = 'E-00001';
            }else{
                $employee_code = $get_last_number[0]->employee_code;
                $employee_code = substr($employee_code, strpos($employee_code, "-") + 2) + 1;
                $employee_code = 'E-'.str_pad($employee_code, 5, '0', STR_PAD_LEFT);
            }
        }

        $data_insert = array(
            'employee_id'   => $employee_id,
            'employee_code' => $employee_code,
            'employee_name' => $employee_name,
            'employee_salary' => $employee_salary
        );
        if($actiontype == 'add'){
            unset($employee_id);   
            $insertemployee = $this->M_masterdata->insertemployee($data_insert);
            $msg = 'Sukses';
            echo json_encode(['code'=>200, 'msg'=>$msg]);die();
        }else{
            $editemployee = $this->M_masterdata->editemployee($data_insert, $employee_id);
            $msg = 'Sukses Edit';
            echo json_encode(['code'=>200, 'msg'=>$msg]);die();
        }     
    }

    public function deleteemployee()
    {
        $employee_id = $this->input->get('id');
        $deleteemployee = $this->M_masterdata->deleteemployee($employee_id);
        redirect(base_url().'Masterdata/masteremployee', 'refresh');
    }


    //end employee //


    //ship //
    public function mastership()
    {
        $this->check_auth();
        $list_ship['list_ship'] = $this->M_masterdata->get_ship();
        $this->load->view('masterdata/mastership', $list_ship);
    }



    public function processaddship()
    {   

        $this->check_auth();
        $ship_id = $this->input->post('ship_id');
        $ship_code = $this->input->post('ship_code');
        $ship_name = $this->input->post('ship_name');
        $ship_type = $this->input->post('ship_type');
        $ship_desc = $this->input->post('ship_desc');
        $actiontype = $this->input->post('action_type');

        if($actiontype == 'add'){
            $get_last_number_ship = $this->M_masterdata->get_last_number_ship();
            if($get_last_number_ship == null){
                $ship_code = 'S-00001';
            }else{
                $ship_code = $get_last_number_ship[0]->ship_code;
                $ship_code = substr($ship_code, strpos($ship_code, "-") + 2) + 1;
                $ship_code = 'S-'.str_pad($ship_code, 5, '0', STR_PAD_LEFT);
            }
        }

        $data_insert = array(
            'ship_id'   => $ship_id,
            'ship_code' => $ship_code,
            'ship_name' => $ship_name,
            'ship_type' => $ship_type,
            'ship_desc' => $ship_desc,
        );
        if($actiontype == 'add'){
            unset($ship_id);   
            $insertship = $this->M_masterdata->insertship($data_insert);
            $msg = 'Sukses';
            echo json_encode(['code'=>200, 'msg'=>$msg]);die();
        }else{
            $insertship = $this->M_masterdata->editship($data_insert, $ship_id);
            $msg = 'Sukses Edit';
            echo json_encode(['code'=>200, 'msg'=>$msg]);die();
        }     
    }

    public function deleteship()
    {
        $ship_id = $this->input->get('id');
        $deleteship = $this->M_masterdata->deleteship($ship_id);
        redirect(base_url().'Masterdata/mastership', 'refresh');
    }


    //end ship//


    //supplier //
    public function mastersupplier()
    {
        $this->check_auth();
        $list_supplier['list_supplier'] = $this->M_masterdata->get_supplier();
        $this->load->view('masterdata/mastersupplier', $list_supplier);
    }



    public function processaddsupplier()
    {   

        $this->check_auth();
        $supplier_id = $this->input->post('supplier_id');
        $supplier_name = $this->input->post('supplier_name');
        $supplier_address = $this->input->post('supplier_address');
        $supplier_phone = $this->input->post('supplier_phone');
        $supplier_npwp = $this->input->post('supplier_npwp');
        $actiontype = $this->input->post('action_type');

        $data_insert = array(
            'supplier_id '     => $supplier_id ,
            'supplier_name'    => $supplier_name,
            'supplier_address' => $supplier_address,
            'supplier_phone'   => $supplier_phone,
            'supplier_npwp'    => $supplier_npwp,
        );

        if($actiontype == 'add'){
            unset($supplier_id);   
            $insertsupplier = $this->M_masterdata->insertsupplier($data_insert);
            $msg = 'Sukses';
            echo json_encode(['code'=>200, 'msg'=>$msg]);die();
        }else{
            $editsupplier = $this->M_masterdata->editsupplier($data_insert, $supplier_id);
            $msg = 'Sukses Edit';
            echo json_encode(['code'=>200, 'msg'=>$msg]);die();
        }     
    }

    public function deletesupplier()
    {
        $supplier_id = $this->input->get('id');
        $deletesupplier = $this->M_masterdata->deletesupplier($supplier_id);
        redirect(base_url().'Masterdata/mastersupplier', 'refresh');
    }


    //end supplier//

    // master item //

    public function masteritem()
    {
        $this->check_auth();
        $list_item['list_item'] = $this->M_masterdata->get_item();
        $list_weight['list_weight'] = $this->M_masterdata->get_weight();
        $data['datas'] = array_merge_recursive($list_item, $list_weight);
        $this->load->view('masterdata/masteritem', $data);
    }



    public function processadditem()
    {   

        $this->check_auth();
        $item_id = $this->input->post('item_id');
        $item_code = $this->input->post('item_code');
        $item_name = $this->input->post('item_name');
        $item_weight_id = $this->input->post('item_weight_id');
        $item_type = $this->input->post('item_type');
        $actiontype = $this->input->post('action_type');
        
        if($item_code == '' || $item_name == '' || $item_weight_id == '' || $item_type == ''){
            $msg = 'Silahkan Lengkapi Semua Data';
            echo json_encode(['code'=>0, 'msg'=>$msg]);die();
        }
        
        $data_insert = array(
            'item_id '         => $item_id ,
            'item_code'        => $item_code,
            'item_name'        => $item_name,
            'item_weight_id'   => $item_weight_id,
            'item_type'        => $item_type
        );

        if($actiontype == 'add'){
            unset($item_id);   
            $insertitem = $this->M_masterdata->insertitem($data_insert);
            $msg = 'Sukses';
            echo json_encode(['code'=>200, 'msg'=>$msg]);die();
        }else{
            $edititem = $this->M_masterdata->edititem($data_insert, $item_id);
            $msg = 'Sukses Edit';
            echo json_encode(['code'=>200, 'msg'=>$msg]);die();
        }     
    }

    public function deleteitem()
    {
        $supplier_id = $this->input->get('id');
        $deleteitem = $this->M_masterdata->deleteitem($supplier_id);
        redirect(base_url().'Masterdata/masteritem', 'refresh');
    }

    // end item //

    // customer //
    public function mastercustomer()
    {
        $this->check_auth();
        $list_customer['list_customer'] = $this->M_masterdata->get_customer();
        $this->load->view('masterdata/mastercustomer', $list_customer);
    }


    public function processaddcustomer()
    {   

        $this->check_auth();
        $customer_id = $this->input->post('customer_id');
        $customer_name = $this->input->post('customer_name');
        $customer_address = $this->input->post('customer_address');
        $customer_phone = $this->input->post('customer_phone');
        $customer_npwp = $this->input->post('customer_npwp');
        $actiontype = $this->input->post('action_type');

        $data_insert = array(
            'customer_id '     => $customer_id,
            'customer_name'    => $customer_name,
            'customer_address' => $customer_address,
            'customer_phone'   => $customer_phone,
            'customer_npwp'    => $customer_npwp,
        );

        if($actiontype == 'add'){
            unset($customer_id);   
            $insertcustomer = $this->M_masterdata->insertcustomer($data_insert);
            $msg = 'Sukses';
            echo json_encode(['code'=>200, 'msg'=>$msg]);die();
        }else{
            $editcustomer = $this->M_masterdata->editcustomer($data_insert, $customer_id);
            $msg = 'Sukses Edit';
            echo json_encode(['code'=>200, 'msg'=>$msg]);die();
        }     
    }

    public function deletecustomer()
    {
        $customer_id = $this->input->get('id');
        $deletecustomer = $this->M_masterdata->deletecustomer($customer_id);
        redirect(base_url().'Masterdata/mastercustomer', 'refresh');
    }

    // end customer //


    // master weight //

    public function masterweight()
    {
        $this->check_auth();
        $list_weight['list_weight'] = $this->M_masterdata->get_weight();
        $this->load->view('masterdata/masterweight', $list_weight);
    }


    public function processaddweight()
    {   

        $this->check_auth();
        $weight_id = $this->input->post('weight_id');
        $weight_code = $this->input->post('weight_code');
        $weight_name = $this->input->post('weight_name');
        $actiontype = $this->input->post('action_type');

        $data_insert = array(
            'weight_id '     => $weight_id,
            'weight_code'    => $weight_code,
            'weight_name'    => $weight_name,
        );

        if($actiontype == 'add'){
            unset($weight_id);   
            $insertweight = $this->M_masterdata->insertweight($data_insert);
            $msg = 'Sukses';
            echo json_encode(['code'=>200, 'msg'=>$msg]);die();
        }else{
            $editweight = $this->M_masterdata->editweight($data_insert, $weight_id);
            $msg = 'Sukses Edit';
            echo json_encode(['code'=>200, 'msg'=>$msg]);die();
        }     
    }

    public function deleteweight()
    {
        $weight_id = $this->input->get('id');
        $deleteweight = $this->M_masterdata->deleteweight($weight_id);
        redirect(base_url().'Masterdata/masterweight', 'refresh');
    }

    // end master weight //

}
