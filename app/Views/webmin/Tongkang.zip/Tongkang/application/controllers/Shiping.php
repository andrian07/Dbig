<?php

defined('BASEPATH') OR exit('No direct script access allowed');
header('Access-Control-Allow-Origin: *');
header("Access-Control-Allow-Methods: GET, OPTIONS");

class Shiping extends CI_Controller
{
    public function __construct(){
        parent::__construct();
        $this->load->helper('url');
        $this->load->model('M_shiping');
        $this->load->model('M_masterdata');
        $this->load->library('session');
    }

    private function check_auth(){
        if(isset($_SESSION['user_name']) == null){
            redirect('Login', 'refresh');
        }
    }

    public function index()
    {

       $this->check_auth();
        $list_shiping['list_shiping'] = $this->M_shiping->get_shiping();
        $this->load->view('shiping/shiping', $list_shiping);
    }

    public function inputshiping()
    {
        $this->check_auth();
        $user_id = $_SESSION['user_id'];
        $id = $this->input->get('id');
        $list_customer['list_customer'] = $this->M_masterdata->get_customer();
        $list_ship['list_ship'] = $this->M_masterdata->get_ship_transaction();
        $list_weight['list_weight'] = $this->M_masterdata->get_weight();
        $list_temp_transaction['list_temp_transaction'] = $this->M_shiping->get_temp_transaction($user_id);
        $data['datas'] = array_merge_recursive($list_customer, $list_temp_transaction, $list_ship, $list_weight);
        $this->load->view('shiping/shipinginput', $data);
    }

    public function deleteTempShiping()
    {
        $this->check_auth();
        $temp_purchase_id = $this->input->get('id');
        $deleteTempShiping = $this->M_shiping->deleteTempShiping($temp_purchase_id);
        redirect(base_url().'Shiping/inputshiping', 'refresh');
    }   

    public function processaddtempshipping()
    {
        
        $this->check_auth();
        $temp_purchase_id               = $this->input->post('temp_id');
        $transaction_item               = $this->input->post('item_desc');
        $transaction_ship_id            = $this->input->post('temp_ship');
        $transaction_price              = $this->input->post('temp_price_val');
        $transaction_ppn                = $this->input->post('temp_ppn_val');
        $transaction_total              = $this->input->post('temp_total_val');
        $temp_qty                       = $this->input->post('temp_qty_val');
        $temp_weight                    = $this->input->post('temp_weight');
        $transation_type                = $this->input->post('transation_type');
        $transaction_rent_startdate     = $this->input->post('temp_rent_startdate');
        $transaction_rent_enddate       = $this->input->post('temp_rent_enddate');
        $actiontype                     = $this->input->post('actiontype');

        if($transaction_ship_id == '' || $transaction_price == '' || $transaction_total <= 0){
            $msg = 'Silahkan Isi Semua Data';
            echo json_encode(['code'=>0, 'msg'=>$msg]);die();
        }

        if($transation_type == 'Shiping'){
            if($transaction_item == ''){
                $msg = 'Silahkan Isi Keterangan Item';
                echo json_encode(['code'=>0, 'msg'=>$msg]);die();
            }
        }else{
            $transaction_item = 'Penyewaan Kapal';
        }

        if($transation_type == ''){
            $msg = 'Silahkan Isi Jenis Transaksi';
            echo json_encode(['code'=>0, 'msg'=>$msg]);die();
        }

        if($transation_type == 'Rent'){
            if($transaction_rent_startdate == '' || $transaction_rent_enddate == ''){
                $msg = 'Silahkan Isi Tanggal Sewa Kapal';
                echo json_encode(['code'=>0, 'msg'=>$msg]);die();
            }
        }

        $data_insert = array(
            'temp_purchase_id'              => $temp_purchase_id,
            'transaction_item'              => $transaction_item,
            'transaction_ship_id'           => $transaction_ship_id,
            'transaction_price'             => $transaction_price,
            'transaction_ppn'               => $transaction_ppn,
            'transaction_total'             => $transaction_total,
            'transaction_qty'               => $temp_qty,
            'transaction_weight'            => $temp_weight,
            'transaction_rent_startdate'    => $transaction_rent_startdate,
            'transaction_rent_enddate'      => $transaction_rent_enddate,
            'transaction_type'              => $transation_type,
            'user_id'                       => $_SESSION['user_id']
        );
        
        //print_r($data_insert['temp_po_id']);die();

        if($data_insert['temp_purchase_id']  == ''){
            unset($temp_purchase_id);   
            $inserttempshipping = $this->M_shiping->inserttempshipping($data_insert);
            $msg = 'Sukses';
            echo json_encode(['code'=>200, 'msg'=>$msg]);die();
        }else{
            $edittempshipping = $this->M_shiping->edittempshipping($data_insert);
            $msg = 'Sukses Edit';
            echo json_encode(['code'=>200, 'msg'=>$msg]);die();
        }   
    }


    public function getShippingFooter()
    {
        $this->check_auth();
        $user_id = $_SESSION['user_id'];
        $get_shipping_footer = $this->M_shiping->get_shipping_footer($user_id);
        $sub_total = $get_shipping_footer[0]->sub_total;
        $transaction_type = $get_shipping_footer[0]->transaction_type;
        $total_invoice = $sub_total;
        echo json_encode(['code'=>200, 'sub_total'=>$sub_total, 'total_invoice'=>$total_invoice, 'transaction_type'=>$transaction_type]);die();
    }

    public function getEditTemp()
    {
        $this->check_auth();
        $user_id = $_SESSION['user_id'];
        $get_shipping_footer = $this->M_shiping->get_shipping_footer($user_id);
        $sub_total = $get_shipping_footer[0]->sub_total;
        $total_invoice = $sub_total;
        echo json_encode(['code'=>200, 'sub_total'=>$sub_total, 'total_invoice'=>$total_invoice]);die();
    }



    public function detailshiping()
    {
        $this->check_auth();
        $hd_transaction  = $this->input->get('id');
        $getShipingHd['getShipingHd'] = $this->M_shiping->getShipingHd($hd_transaction);
        $transaction_invoice = $getShipingHd['getShipingHd'][0]->transaction_invoice;
        $getShipingDetail['getShipingDetail'] = $this->M_shiping->getShipingDetail($transaction_invoice);
        $data['datas'] = array_merge_recursive($getShipingHd, $getShipingDetail);
        $this->load->view('shiping/shipingdetail', $data);
    }

    public function processsaveshipping()
    {
        $this->check_auth();
        $customer_id                   = $this->input->post('customer_id');
        $date                          = $this->input->post('date');
        $footer_sub_total              = $this->input->post('footer_sub_total_inp');
        $footer_total_ppn              = $this->input->post('footer_total_ppn_inp');
        $footer_total_invoice          = $this->input->post('footer_total_invoice_inp');
        $footer_total_dp               = $this->input->post('footer_total_dp_inp');
        $footer_total_remaining_debt   = $this->input->post('footer_total_remaining_inp');
        $transation_type               = $this->input->post('transation_type');
        $userid                        = $_SESSION['user_id'];
        $actiontype                    = 'add';

        if($footer_total_invoice <= 0 ){
            $msg = 'Data Tidak Boleh Kososng';
            echo json_encode(['code'=>0, 'msg'=>$msg]);die();
        }
        if($customer_id == null ){
            $msg = 'Silahkan Pilih Customer';
            echo json_encode(['code'=>0, 'msg'=>$msg]);die();
        }

        $get_last_number_shipping = $this->M_shiping->get_last_number_shipping();
            if($get_last_number_shipping == null){
                $hd_purchase_invoice = '000000001/DPM-AB.ER/XI/'.date("Y");
        }else{
            $hd_purchase_invoice = $get_last_number_shipping[0]->transaction_invoice;
            $hd_purchase_invoice = substr($hd_purchase_invoice, 0, 9) + 1;
            $hd_purchase_invoice = str_pad($hd_purchase_invoice, 9, '0', STR_PAD_LEFT).'/DPM-AB.ER/XI/'.date("Y");
        }

        $data_insert = array(
            'transaction_date'                  => $date,
            'transaction_invoice'               => $hd_purchase_invoice,
            'transaction_customer_id'           => $customer_id,
            'transaction_type'                  => $transation_type,
            'transaction_subtotal'              => $footer_sub_total,
            'transaction_ppn'                   => $footer_total_ppn,
            'transaction_total'                 => $footer_total_invoice,
            'transaction_dp'                    => $footer_total_dp,
            'transaction_receivables_remaining' => $footer_total_remaining_debt,
            'transaction_created_by'            => $userid,
        );

        $insertheadershipping = $this->M_shiping->insertheadershipping($data_insert);
    

        $get_temp_transaction = $this->M_shiping->get_temp_transaction($userid);

        foreach($get_temp_transaction as $row){
            $data_insert_dt = array(
                'transaction_invoice'        => $hd_purchase_invoice,
                'transaction_item'           => $row->transaction_item,
                'transaction_ship_id'        => $row->transaction_ship_id,
                'transaction_price'          => $row->transaction_price,
                'transaction_qty'            => $row->transaction_qty,
                'transaction_weight'         => $row->transaction_weight,
                'transaction_rent_startdate' => $row->transaction_rent_startdate,
                'transaction_rent_enddate'   => $row->transaction_rent_enddate,
                'transaction_ppn'            => $row->transaction_ppn,
                'transaction_total'          => $row->transaction_total
            );
            $insertdttransaction = $this->M_shiping->insertdttransaction($data_insert_dt);

            $ship_id = $row->transaction_ship_id;
            if($transation_type == 'Rent'){
                $this->M_shiping->updateshipstatus($ship_id);
            }
        }

        $this->M_shiping->clearTempShipping($userid);

        $msg = 'Sukses';
        echo json_encode(['code'=>200, 'msg'=>$msg]);die();

    }

    public function printshiping()
    {
        $this->check_auth();
        $hd_transaction  = $this->input->get('id');
        $getShipingHd['getShipingHd'] = $this->M_shiping->getShipingHd($hd_transaction);
        $transaction_invoice = $getShipingHd['getShipingHd'][0]->transaction_invoice;
        $getShipingDetail['getShipingDetail'] = $this->M_shiping->getShipingDetail($transaction_invoice);
        $data['datas'] = array_merge_recursive($getShipingHd, $getShipingDetail);
        $this->load->view('shiping/printshiping', $data); 
    }

}
