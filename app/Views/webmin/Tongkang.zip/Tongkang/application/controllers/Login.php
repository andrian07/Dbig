<?php

defined('BASEPATH') OR exit('No direct script access allowed');
header('Access-Control-Allow-Origin: *');
header("Access-Control-Allow-Methods: GET, OPTIONS");

class Login extends CI_Controller
{
    public function __construct(){
        parent::__construct();
        $this->load->helper('url');
        $this->load->library('session');
        $this->load->model('M_user');
     }

    public function index()
    {
        $this->load->view('login/login');
    }

    public function processLogin()
    {
        $username =  $this->input->post('username');
        $password =  md5($this->input->post('password'));
        $get_admin_by_username = $this->M_user->get_admin_by_username($username, $password);
        if($get_admin_by_username != null){
            $user_name = $get_admin_by_username[0]->user_name;
            $user_id  = $get_admin_by_username[0]->user_id ;
            $user_role_id  = $get_admin_by_username[0]->user_role_id ;
            $newdata = [
                'user_name'  => $user_name,
                'user_id' => $user_id,
                'user_role_id' => $user_role_id,
                'logged_in' => TRUE,
            ];
            $this->session->set_userdata($newdata);
            $msg = 'Sukses login';
            echo json_encode(['code'=>'200', 'msg'=>$msg]); 
        }else{
            $msg = 'Username Atau Password Salah';
            echo json_encode(['code'=>0, 'msg'=>$msg]);
        }   

    }

    public function logout(){
        $this->session->sess_destroy();
        redirect('Admin/index', 'refresh');
    }
}
