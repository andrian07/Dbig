<?php

defined('BASEPATH') OR exit('No direct script access allowed');
header('Access-Control-Allow-Origin: *');
header("Access-Control-Allow-Methods: GET, OPTIONS");

class Expenditure extends CI_Controller
{
    public function __construct(){
        parent::__construct();
        $this->load->helper('url');
        $this->load->library('session');
        $this->load->model('M_expenditure');
        $this->load->model('M_masterdata');
    }


    private function check_auth(){
        if(isset($_SESSION['user_name']) == null){
            redirect('Login', 'refresh');
        }
    }

    public function index()
    {
        $this->check_auth();
        $list_expenditure['list_expenditure'] = $this->M_expenditure->get_expenditur();
        $this->load->view('expenditure/expenditure', $list_expenditure);
    }

    public function inputExpenditure()
    {
        $this->check_auth();
        $list__temp_expenditure['list__temp_expenditure'] = $this->M_expenditure->get_temp_expenditure();
        $list_customer['list_customer'] = $this->M_masterdata->get_customer();
        $data['datas'] = array_merge_recursive($list__temp_expenditure, $list_customer);
        $this->load->view('expenditure/inputexpenditure', $data);
    }

    public function detailExpenditure()
    {
        $this->check_auth();
        $id = $this->input->get('id');
        $list_hd_expenditure['list_hd_expenditure'] = $this->M_expenditure->get_hd_expenditure($id);
        $invoice = $list_hd_expenditure['list_hd_expenditure'][0]->hd_expenditure_invoice;
        $list_dt_expenditure['list_dt_expenditure'] = $this->M_expenditure->get_dt_expenditure($invoice);
        $data['datas'] = array_merge_recursive($list_dt_expenditure, $list_hd_expenditure);
        $this->load->view('expenditure/detailexpenditure', $data);
    }

     public function printExpenditure()
    {
        $this->check_auth();
        $id = $this->input->get('id');
        $list_hd_expenditure['list_hd_expenditure'] = $this->M_expenditure->get_hd_expenditure($id);
        $invoice = $list_hd_expenditure['list_hd_expenditure'][0]->hd_expenditure_invoice;
        $list_dt_expenditure['list_dt_expenditure'] = $this->M_expenditure->get_dt_expenditure($invoice);
        $count_dt_expenditure['count_dt_expenditure'] = $this->M_expenditure->get_count_dt_expenditure($invoice);
        $nilai = $list_hd_expenditure['list_hd_expenditure'][0]->hd_expenditure_total;
        $terbilang['terbilang'] = $this->terbilang($nilai);
        $data['datas'] = array_merge_recursive($list_dt_expenditure, $list_hd_expenditure, $count_dt_expenditure, $terbilang);
        $this->load->view('expenditure/printexpenditure', $data);
    }

    public function processaddtempexpenditure()
    {
        $this->check_auth();
        $temp_expenditure_id      = $this->input->post('temp_id');
        $temp_expenditure_item    = $this->input->post('temp_item');
        $temp_expenditure_price   = $this->input->post('temp_price');
        $temp_expenditure_qty     = $this->input->post('temp_qty');
        $temp_expenditure_total   = $this->input->post('temp_total');

        if($temp_expenditure_item == '' || $temp_expenditure_price == '' || $temp_expenditure_qty == '' || $temp_expenditure_total == '' || $temp_expenditure_total <= 0){
            $msg = 'Silahkan Isi Semua Data';
            echo json_encode(['code'=>0, 'msg'=>$msg]);die();
        }

        $data_insert = array(
            'temp_expenditure_id'        => $temp_expenditure_id,
            'temp_expenditure_item'      => $temp_expenditure_item,
            'temp_expenditure_price'     => $temp_expenditure_price,
            'temp_expenditure_qty'       => $temp_expenditure_qty,
            'temp_expenditure_total'     => $temp_expenditure_total,
            'temp_expenditure_user_id'   => $_SESSION['user_id'],
        );

        if($temp_expenditure_id  == ''){
            unset($temp_expenditure_id);   
            $inserttemppo = $this->M_expenditure->inserttempexpenditure($data_insert);
            $msg = 'Sukses';
            echo json_encode(['code'=>200, 'msg'=>$msg]);die();
        }else{
            $edittemppo = $this->M_expenditure->edittempexpenditure($data_insert);
            $msg = 'Sukses Edit';
            echo json_encode(['code'=>200, 'msg'=>$msg]);die();
        }   
    }

    public function getEditExpenditure()
    {
        $this->check_auth();
        $id = $this->input->get('id');
        $get_edit_temp = $this->M_expenditure->get_edit_temp($id);

        $data = array(
            'temp_expenditure_id'        => $get_edit_temp[0]->temp_expenditure_id,
            'temp_expenditure_item'      => $get_edit_temp[0]->temp_expenditure_item,
            'temp_expenditure_price'     => $get_edit_temp[0]->temp_expenditure_price,
            'temp_expenditure_qty'       => $get_edit_temp[0]->temp_expenditure_qty,
            'temp_expenditure_total'     => $get_edit_temp[0]->temp_expenditure_total
        );
        echo json_encode(['code'=>200, 'result'=>$data]);die(); 
    }

    public function deleteTempExpenditure()
    {
        $this->check_auth();
        $temp_expenditure_id = $this->input->get('id');
        $deleteTempExpenditure = $this->M_expenditure->deleteTempExpenditure($temp_expenditure_id);
        redirect(base_url().'Expenditure/inputExpenditure', 'refresh');
    }   


    public function getExpenditureFooter()
    {
        $this->check_auth();
        $getExpenditureFooter = $this->M_expenditure->get_expenditure_footer();
        $sub_total = $getExpenditureFooter[0]->sub_total;
        echo json_encode(['code'=>200, 'sub_total'=>$sub_total]);die();
    }

    public function processSaveExpenditure()
    {
        $this->check_auth();
        $customer_id                      = $this->input->post('customer_id');
        $hd_expenditure_reference         = $this->input->post('hd_expenditure_reference');
        $date                             = $this->input->post('date');
        $footer_sub_total_val             = $this->input->post('footer_sub_total_val');
        $footer_total_pay_val             = $this->input->post('footer_total_pay_val');
        $footer_remaining_debt_val        = $this->input->post('footer_remaining_debt_val');
        $desc                             = $this->input->post('desc');
        $userid                           = $_SESSION['user_id'];
        $actiontype                       = $this->input->post('actiontype');


        if($footer_sub_total_val <= 0 ){
            $msg = 'Data Tidak Boleh Kososng';
            echo json_encode(['code'=>0, 'msg'=>$msg]);die();
        }
        if($footer_remaining_debt_val < 0 ){
            $msg = 'Data Tidak Minus';
            echo json_encode(['code'=>0, 'msg'=>$msg]);die();
        }

        if($actiontype == 'add'){
            $get_last_number_expanditure = $this->M_expenditure->get_last_number_expanditure();
            if($get_last_number_expanditure == null){
                $hd_expenditure_invoice = '000000001/DPM-Expend/'.date("Y");
            }else{
                $hd_expenditure_invoice = $get_last_number_expanditure[0]->hd_expenditure_invoice;
                $hd_expenditure_invoice = substr($hd_expenditure_invoice, 0, 9) + 1;
                $hd_expenditure_invoice = str_pad($hd_expenditure_invoice, 9, '0', STR_PAD_LEFT).'/DPM-Expend/'.date("Y");
            }
        }

        $data_insert = array(
            'hd_expenditure_invoice'         => $hd_expenditure_invoice,
            'hd_expenditure_customer_name'   => $customer_id,
            'hd_expenditure_reference'       => $hd_expenditure_reference,
            'hd_expenditure_total'           => $footer_sub_total_val,
            'hd_expenditure_remaining_debt'  => $footer_remaining_debt_val,
            'hd_expenditure_date'            => $date,
            'hd_expenditure_desc'            => $desc,
            'hd_expenditure_created_by'      => $userid,
        );

        $insertheaderExpenditure = $this->M_expenditure->insertheaderExpenditure($data_insert);

        $get_temp_expenditure = $this->M_expenditure->get_temp_expenditure();

        foreach($get_temp_expenditure as $row){
            $data_insert_dt = array(
                'dt_expenditure_invoice'      => $hd_expenditure_invoice,
                'dt_expenditure_item'         => $row->temp_expenditure_item,
                'dt_expenditure_price'        => $row->temp_expenditure_price,
                'dt_expenditure_qty'          => $row->temp_expenditure_qty,
                'dt_expenditure_total'        => $row->temp_expenditure_total,
            );
        $insertdtExpenditure= $this->M_expenditure->insertdtExpenditure($data_insert_dt);
        }

        $this->M_expenditure->clearTempExpenditure($userid);

        $msg = 'Sukses';
        echo json_encode(['code'=>200, 'msg'=>$msg]);die();
    }

    function penyebut($nilai) {
        $nilai = abs($nilai);
        $huruf = array("", "satu", "dua", "tiga", "empat", "lima", "enam", "tujuh", "delapan", "sembilan", "sepuluh", "sebelas");
        $temp = "";
        if ($nilai < 12) {
            $temp = " ". $huruf[$nilai];
        } else if ($nilai <20) {
            $temp = $this->penyebut($nilai - 10). " belas";
        } else if ($nilai < 100) {
            $temp = $this->penyebut($nilai/10)." puluh". $this->penyebut($nilai % 10);
        } else if ($nilai < 200) {
            $temp = " seratus" . $this->penyebut($nilai - 100);
        } else if ($nilai < 1000) {
            $temp = $this->penyebut($nilai/100) . " ratus" . $this->penyebut($nilai % 100);
        } else if ($nilai < 2000) {
            $temp = " seribu" . $this->penyebut($nilai - 1000);
        } else if ($nilai < 1000000) {
            $temp = $this->penyebut($nilai/1000) . " ribu" . $this->penyebut($nilai % 1000);
        } else if ($nilai < 1000000000) {
            $temp = $this->penyebut($nilai/1000000) . " juta" . $this->penyebut($nilai % 1000000);
        } else if ($nilai < 1000000000000) {
            $temp = $this->penyebut($nilai/1000000000) . " milyar" . $this->penyebut(fmod($nilai,1000000000));
        } else if ($nilai < 1000000000000000) {
            $temp = $this->penyebut($nilai/1000000000000) . " trilyun" . $this->penyebut(fmod($nilai,1000000000000));
        }     
        return $temp;
    }
 
    function terbilang($nilai) {
        if($nilai<0) {
            $hasil = "minus ". trim($this->penyebut($nilai));
        } else {
            $hasil = trim($this->penyebut($nilai));
        }         
        return $hasil;
    }


}
