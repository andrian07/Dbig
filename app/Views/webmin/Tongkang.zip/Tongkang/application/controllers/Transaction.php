<?php

defined('BASEPATH') OR exit('No direct script access allowed');
header('Access-Control-Allow-Origin: *');
header("Access-Control-Allow-Methods: GET, OPTIONS");

class Transaction extends CI_Controller
{

    public function __construct(){
        parent::__construct();
        $this->load->helper('url');
        $this->load->model('M_transaction');
        $this->load->model('M_masterdata');
        $this->load->library('session');
    }

    private function check_auth(){
        if(isset($_SESSION['user_name']) == null){
            redirect('Login', 'refresh');
        }
    }


    // PO //
    public function purchaseorder()
    {
        $this->check_auth();
        $list_po['list_po'] = $this->M_transaction->get_po();
        $this->load->view('transaction/purchaseorder', $list_po);
    }

    public function detailpo()
    {
        $this->check_auth();
        $hd_po_id = $this->input->get('id');
        $getPoHd['getPoHd'] = $this->M_transaction->getPoHd($hd_po_id);
        $dt_hd_invoice = $getPoHd['getPoHd'][0]->hd_po_invoice;
        $getPoDetail['getPoDetail'] = $this->M_transaction->getPoDetail($dt_hd_invoice);
        $data['datas'] = array_merge_recursive($getPoHd, $getPoDetail);
        $this->load->view('transaction/purchaseorderdetail', $data);
    }

    public function printpo()
    {
        $this->check_auth();
        $hd_po_id = $this->input->get('id');
        $getPoHd['getPoHd'] = $this->M_transaction->getPoHd($hd_po_id);
        $dt_hd_invoice = $getPoHd['getPoHd'][0]->hd_po_invoice;
        $getPoDetail['getPoDetail'] = $this->M_transaction->getPoDetail($dt_hd_invoice);
        $getCountpo['getCountpo'] = $this->M_transaction->getCountpo($dt_hd_invoice);
        $data['datas'] = array_merge_recursive($getPoHd, $getPoDetail, $getCountpo);
        $this->load->view('transaction/poinvoice', $data);
    }

    public function inputpo()
    {
        $this->check_auth();
        $user_id = $_SESSION['user_id'];
        $id = $this->input->get('id');
        $list_supplier['list_supplier'] = $this->M_masterdata->get_supplier();
        $list_temp_po['list_temp_po'] = $this->M_transaction->get_temp_po();
        $list_item['list_item'] = $this->M_masterdata->get_item();
        $list_warehouse['list_warehouse'] = $this->M_masterdata->get_warehouse();
        $data['datas'] = array_merge_recursive($list_supplier, $list_temp_po, $list_item, $list_warehouse);
        $this->load->view('transaction/purchaseorderinput', $data);
    }

    public function processaddtemppo()
    {
        $this->check_auth();
        $temp_po_id      = $this->input->post('temp_id');
        $temp_item_id    = $this->input->post('temp_item');
        $temp_item_price = $this->input->post('temp_price');
        $temp_item_qty   = $this->input->post('temp_qty');
        $temp_item_total = $this->input->post('temp_total');
        $actiontype      = $this->input->post('actiontype');

        if($temp_item_id == '' || $temp_item_qty == ''){
            $msg = 'Silahkan Isi Semua Data';
            echo json_encode(['code'=>0, 'msg'=>$msg]);die();
        }

        $data_insert = array(
            'temp_po_id'        => $temp_po_id,
            'temp_item_id'      => $temp_item_id,
            'temp_item_price'   => $temp_item_price,
            'temp_item_qty'     => $temp_item_qty,
            'temp_item_total'   => $temp_item_total,
            'temp_item_user'    => $_SESSION['user_id'],
        );
        
        //print_r($data_insert['temp_po_id']);die();

        if($data_insert['temp_po_id']  == ''){
            unset($employee_id);   
            $inserttemppo = $this->M_transaction->inserttemppo($data_insert);
            $msg = 'Sukses';
            echo json_encode(['code'=>200, 'msg'=>$msg]);die();
        }else{
            $edittemppo = $this->M_transaction->edittemppo($data_insert);
            $msg = 'Sukses Edit';
            echo json_encode(['code'=>200, 'msg'=>$msg]);die();
        }   
    }

    public function processsavepo()
    {
        $this->check_auth();
        $po_id                            = $this->input->post('po_id');
        $date                             = $this->input->post('date');
        $supplier_id                      = $this->input->post('supplier_id');
        $address                          = $this->input->post('address');
        $po_type                          = $this->input->post('po_type');
        $footer_sub_total                 = $this->input->post('footer_sub_total_inp');
        $footer_total_discount            = $this->input->post('footer_total_discount_inp');
        $footer_total_discount_percentage = $this->input->post('footer_total_discount_percentage_inp');
        $footer_total_ppn                 = $this->input->post('footer_total_ppn_inp');
        $footer_total_invoice             = $this->input->post('footer_total_invoice_inp');
        $desc                             = $this->input->post('desc');
        $userid                           = $_SESSION['user_id'];

        if($po_id == null){
            $actiontype                       = 'add';
        }else{
            $actiontype                       = 'edit';    
        }


        if($supplier_id == null ){
            $msg = 'Silahkan Pilih Supplier';
            echo json_encode(['code'=>0, 'msg'=>$msg]);die();
        }
        if($po_type == null ){
            $msg = 'Silahkan Pilih Jenis PO';
            echo json_encode(['code'=>0, 'msg'=>$msg]);die();
        }
        if($address == null ){
            $msg = 'Silahkan Pilih Alamat Pengantaran';
            echo json_encode(['code'=>0, 'msg'=>$msg]);die();
        }


        if($actiontype == 'add'){
            $get_last_number_po = $this->M_transaction->get_last_number_po();
            if($get_last_number_po == null){
                $hd_po_invoice = '000000001/DPM-AB.ER/XI/'.date("Y");
            }else{
                $hd_po_invoice = $get_last_number_po[0]->hd_po_invoice;
                $hd_po_invoice = substr($hd_po_invoice, 0, 9) + 1;
                $hd_po_invoice = str_pad($hd_po_invoice, 9, '0', STR_PAD_LEFT).'/DPM-AB.ER/XI/'.date("Y");
            }

            $data_insert = array(
                'hd_po_invoice'              => $hd_po_invoice,
                'hd_po_date'                 => $date,
                'hd_po_supplier_id'          => $supplier_id,
                'hd_po_ppn'                  => $footer_total_ppn,
                'hd_po_discount'             => $footer_total_discount,
                'hd_po_discount_percentage'  => $footer_total_discount_percentage,
                'hd_po_total'                => $footer_total_invoice,
                'hd_po_status'               => 'Pending',
                'hd_po_type'                 => $po_type,
                'hd_po_warehouse'            => $address,
                'hd_po_creted_by'            => $userid
            );

            $insertheaderpo = $this->M_transaction->insertheaderpo($data_insert);
        }else{
            $hd_po_invoice = $this->input->post('hd_po_invoice');

            $data_edit = array(
                'hd_po_id'                   => $po_id,
                'hd_po_invoice'              => $hd_po_invoice,
                'hd_po_date'                 => $date,
                'hd_po_supplier_id'          => $supplier_id,
                'hd_po_ppn'                  => $footer_total_ppn,
                'hd_po_discount'             => $footer_total_discount,
                'hd_po_discount_percentage'  => $footer_total_discount_percentage,
                'hd_po_total'                => $footer_total_invoice,
                'hd_po_status'               => 'Pending',
                'hd_po_type'                 => $po_type,
                'hd_po_warehouse'            => $address,
                'hd_po_edit_by'              => $userid,
                'hd_po_is_edited'            => 'Y',
                'hd_po_edited_at'            => date('Y/m/d h:i:s'),
            );

            $editpo = $this->M_transaction->editpo($data_edit);
            $clearDetail = $this->M_transaction->clearDetail($hd_po_invoice);
        }

        $get_temp_po = $this->M_transaction->get_temp_po();

        foreach($get_temp_po as $row){
            $data_insert_dt = array(
                'dt_hd_invoice'        => $hd_po_invoice,
                'dt_item_id'           => $row->temp_item_id,
                'dt_item_price'        => $row->temp_item_price,
                'dt_item_qty'          => $row->temp_item_qty,
                'dt_item_total'        => $row->temp_item_total,
            );
            $insertdtpo = $this->M_transaction->insertdtpo($data_insert_dt);
        }

        $this->clearTempPo($userid);

        $msg = 'Sukses';
        echo json_encode(['code'=>200, 'msg'=>$msg]);die();

    }

    public function clearTempPo($userid)
    {
        $this->check_auth();
        $clearTempPo = $this->M_transaction->clearTempPo($userid);
    }

    public function getPoFooter()
    {
        $this->check_auth();
        $user_id = $_SESSION['user_id'];
        $get_po_footer = $this->M_transaction->get_po_footer($user_id);
        $sub_total = $get_po_footer[0]->sub_total;
        $total_invoice = $sub_total;
        echo json_encode(['code'=>200, 'sub_total'=>$sub_total, 'total_invoice'=>$total_invoice]);die();
    }


    public function getPurchaseFooter()
    {
        $this->check_auth();
        $user_id = $_SESSION['user_id'];
        $get_purchase_footer = $this->M_transaction->get_purchase_footer($user_id);
        $sub_total = $get_purchase_footer[0]->sub_total;
        $total_invoice = $sub_total;
        $temp_invoice_po = $get_purchase_footer[0]->temp_invoice_po;
        echo json_encode(['code'=>200, 'sub_total'=>$sub_total, 'total_invoice'=>$total_invoice, 'temp_invoice_po'=>$temp_invoice_po]);die();
    }

    public function getPoHeader()
    {
        $this->check_auth();
        $po_id = $this->input->get('id');
        $get_po_header = $this->M_transaction->get_po_header($po_id);
        echo json_encode(['code'=>200, 'data'=>$get_po_header]);die();
    }

    public function getPurchaseHeader()
    {
        $this->check_auth();
        $po_id = $this->input->get('id');
        $get_purchase_header = $this->M_transaction->getPoHd($po_id);
        echo json_encode(['code'=>200, 'data'=>$get_purchase_header]);die();
    }

    public function getEditTemp()
    {
        $this->check_auth();
        $id = $this->input->get('id');
        $get_edit_temp = $this->M_transaction->get_edit_temp($id);

        $data = array(
            'temp_po_id'        => $get_edit_temp[0]->temp_po_id,
            'temp_item_id'      => $get_edit_temp[0]->temp_item_id,
            'temp_item_price'   => $get_edit_temp[0]->temp_item_price,
            'temp_item_qty'     => $get_edit_temp[0]->temp_item_qty,
            'temp_item_total'   => $get_edit_temp[0]->temp_item_total
        );
        echo json_encode(['code'=>200, 'result'=>$data]);die(); 
    }


    public function deleteTempPo()
    {
        $this->check_auth();
        $temp_po_id = $this->input->get('id');
        $poid = $this->input->get('poid');
        $deletetemppo = $this->M_transaction->deletetemppo($temp_po_id);
        if($poid == ''){
            redirect(base_url().'Transaction/inputpo', 'refresh');
        }else{
            redirect(base_url().'Transaction/inputpo?id='.$poid, 'refresh'); 
        }  
    }   

    public function cancelPo()
    {
        $this->check_auth();
        $hd_po_id = $this->input->get('id');
        $cancelpo = $this->M_transaction->cancelpo($hd_po_id);
        redirect(base_url().'Transaction/purchaseorder', 'refresh');
    }


    public function getPoDetail()
    {
        $this->check_auth();
        $userid = $_SESSION['user_id'];
        $this->clearTempPo($userid);
        $hd_po_id = $this->input->get('id');
        $getPoHd = $this->M_transaction->getPoHd($hd_po_id);
        if($getPoHd[0]->hd_po_status != 'Pending'){
            $msg = 'Transaksi yang sudah selesai tidak dapat di ubah';
            echo json_encode(['code'=>0, 'msg'=>$msg]);die();
        }else if($getPoHd[0]->hd_po_is_edited == 'Y'){
            $msg = 'Transaksi sudah pernah di ubah oleh'.$getPoHd[0]->hd_po_edit_by;
            echo json_encode(['code'=>0, 'msg'=>$msg]);die();
        }else{
            $dt_hd_invoice = $getPoHd[0]->hd_po_invoice;
            $getPoDetail = $this->M_transaction->getPoDetail($dt_hd_invoice);
            foreach($getPoDetail as $row){
                $data_insert = array(
                    'temp_item_id'      => $row->dt_item_id,
                    'temp_item_price'   => $row->dt_item_price,
                    'temp_item_qty'     => $row->dt_item_qty,
                    'temp_item_total'   => $row->dt_item_total,
                    'temp_item_user'    => $_SESSION['user_id'],
                );
                $inserttemppo = $this->M_transaction->inserttemppo($data_insert);
            }
            $msg = 'Sukses';
            echo json_encode(['code'=>200, 'msg'=>$msg]);die();
        }
    }

    // End PO //




    // Purchase //

    public function purchase()
    {
        $this->check_auth();
        $list_purchase['list_purchase'] = $this->M_transaction->get_purchase();
        $this->load->view('transaction/purchase', $list_purchase);
    }



    public function inputpurchase()
    {
        $this->check_auth();
        $user_id = $_SESSION['user_id'];
        $id = $this->input->get('id');
        $list_supplier['list_supplier'] = $this->M_masterdata->get_supplier();
        $list_temp_purchase['list_temp_purchase'] = $this->M_transaction->get_temp_purchase();
        $list_item['list_item'] = $this->M_masterdata->get_item();
        $list_warehouse['list_warehouse'] = $this->M_masterdata->get_warehouse();
        $list_po['list_po'] = $this->M_transaction->get_po_list();
        $data['datas'] = array_merge_recursive($list_supplier, $list_temp_purchase, $list_item, $list_warehouse, $list_po);
        $this->load->view('transaction/purchaseinput', $data);
    }

    public function copyPo()
    {
       $this->check_auth();
       $id = $this->input->get('id');
       $userid = $_SESSION['user_id'];
       $this->clearTempPurchase($userid);
       $getPoAll = $this->M_transaction->getPoAll($id);
       foreach($getPoAll as $row){
        $data_insert = array(
            'temp_item_id'      => $row->dt_item_id,
            'temp_item_price'   => $row->dt_item_price,
            'temp_item_qty'     => $row->dt_item_qty,
            'temp_item_total'   => $row->dt_item_total,
            'temp_item_user'    => $_SESSION['user_id'],
            'temp_invoice_po'   => $id,
        );
        $inserttemppurchase = $this->M_transaction->inserttemppurchase($data_insert);
    }
    redirect(base_url().'Transaction/inputpurchase'); 
}

public function clearTempPurchase($userid)
{
    $this->check_auth();

    $clearTempPurchase = $this->M_transaction->clearTempPurchase($userid);
}

public function getEditTempPurchase()
{
    $this->check_auth();
    $id = $this->input->get('id');
    $get_edit_temp_purchase = $this->M_transaction->get_edit_temp_purchase($id);

    $data = array(
        'temp_purchase_id'  => $get_edit_temp_purchase[0]->temp_purchase_id,
        'temp_item_id'      => $get_edit_temp_purchase[0]->temp_item_id,
        'temp_item_price'   => $get_edit_temp_purchase[0]->temp_item_price,
        'temp_item_qty'     => $get_edit_temp_purchase[0]->temp_item_qty,
        'temp_item_total'   => $get_edit_temp_purchase[0]->temp_item_total
    );
    echo json_encode(['code'=>200, 'result'=>$data]);die(); 
}


public function processaddtemppurchase()
{
    $this->check_auth();
    $temp_purchase_id= $this->input->post('temp_id');
    $temp_item_id    = $this->input->post('temp_item');
    $po_number       = $this->input->post('po_number');
    $temp_item_price = $this->input->post('temp_price');
    $temp_item_qty   = $this->input->post('temp_qty');
    $temp_item_total = $this->input->post('temp_total');
    $actiontype      = $this->input->post('actiontype');

    if($temp_item_id == '' || $temp_item_price == '' || $temp_item_qty == '' || $temp_item_total == '' || $temp_item_total <= 0){
        $msg = 'Silahkan Isi Semua Data';
        echo json_encode(['code'=>0, 'msg'=>$msg]);die();
    }

    $data_insert = array(
        'temp_purchase_id'  => $temp_purchase_id,
        'temp_item_id'      => $temp_item_id,
        'temp_item_price'   => $temp_item_price,
        'temp_item_qty'     => $temp_item_qty,
        'temp_item_total'   => $temp_item_total,
        'temp_item_user'    => $_SESSION['user_id'],
        'temp_invoice_po'   => $po_number
    );

        //print_r($data_insert['temp_po_id']);die();

    if($data_insert['temp_purchase_id']  == ''){
        unset($employee_id);   
        $inserttemppurchase = $this->M_transaction->inserttemppurchase($data_insert);
        $msg = 'Sukses';
        echo json_encode(['code'=>200, 'msg'=>$msg]);die();
    }else{
        $edittemppurchase = $this->M_transaction->edittemppurchase($data_insert);
        $msg = 'Sukses Edit';
        echo json_encode(['code'=>200, 'msg'=>$msg]);die();
    }   
}


public function deleteTempPurchase()
{
    $this->check_auth();
    $temp_purchase_id = $this->input->get('id');
    $deletetemppurchase = $this->M_transaction->deletetemppurchase($temp_purchase_id);
    redirect(base_url().'Transaction/inputpurchase', 'refresh');
}

public function processsavepurchase()
{
    $this->check_auth();
    $po_number                        = $this->input->post('po_number');
    $po_number_invoice                = $this->input->post('po_number_invoice');
    $date                             = $this->input->post('date');
    $duedate                          = $this->input->post('duedate');
    $supplier_id                      = $this->input->post('supplier_id');
    $address                          = $this->input->post('address');
    $purchase_type                    = $this->input->post('purchase_type');
    $po_purchase                      = $this->input->post('po_purchase');
    $footer_sub_total                 = $this->input->post('footer_sub_total_inp');
    $footer_total_discount            = $this->input->post('footer_total_discount_inp');
    $footer_total_discount_percentage = $this->input->post('footer_total_discount_percentage_inp');
    $footer_total_ppn                 = $this->input->post('footer_total_ppn_inp');
    $footer_total_invoice             = $this->input->post('footer_total_invoice_inp');
    $footer_total_dp                  = $this->input->post('footer_total_dp_inp');
    $footer_total_debt_remaining      = $this->input->post('footer_total_debt_remaining_inp');
    $desc                             = $this->input->post('desc');
    $userid                           = $_SESSION['user_id'];
    $actiontype                       = 'add';

    if($footer_total_invoice <= 0 ){
        $msg = 'Data Tidak Boleh Kososng';
        echo json_encode(['code'=>0, 'msg'=>$msg]);die();
    }
    if($supplier_id == null ){
        $msg = 'Silahkan Pilih Supplier';
        echo json_encode(['code'=>0, 'msg'=>$msg]);die();
    }
    if($purchase_type == null ){
        $msg = 'Silahkan Pilih Jenis Purchase';
        echo json_encode(['code'=>0, 'msg'=>$msg]);die();
    }
    if($address == null ){
        $msg = 'Silahkan Pilih Alamat Pengantaran';
        echo json_encode(['code'=>0, 'msg'=>$msg]);die();
    }


    
    $get_last_number_po = $this->M_transaction->get_last_number_purchase();
    if($get_last_number_po == null){
        $hd_purchase_invoice = '000000001/PO/DPM-AB.ER/XI/'.date("Y");
    }else{
        $hd_purchase_invoice = $get_last_number_po[0]->hd_purchase_invoice;
        $hd_purchase_invoice = substr($hd_purchase_invoice, 0, 9) + 1;
        $hd_purchase_invoice = str_pad($hd_purchase_invoice, 9, '0', STR_PAD_LEFT).'/PO/DPM-AB.ER/XI/'.date("Y");
    }

    $data_insert = array(
        'hd_purchase_invoice'              => $hd_purchase_invoice,
        'hd_po_invoice'                    => $po_number_invoice,
        'hd_purchase_date'                 => $date,
        'hd_purchase_due_date'             => $duedate,
        'hd_purchase_supplier_id'          => $supplier_id,
        'hd_purchase_ppn'                  => $footer_total_ppn,
        'hd_purchase_discount'             => $footer_total_discount,
        'hd_purchase_discount_percentage'  => $footer_total_discount_percentage,
        'hd_purchase_total'                => $footer_total_invoice,
        'hd_purchase_dp'                   => $footer_total_dp,
        'hd_purchase_debt_remaining'       => $footer_total_debt_remaining,
        'hd_purchase_type'                 => $purchase_type,
        'hd_purchase_warehouse'            => $address,
        'hd_purchase_creted_by'            => $userid
    );

    $insertheaderpurchase = $this->M_transaction->insertheaderpurchase($data_insert);
    

    $get_temp_purchase = $this->M_transaction->get_temp_purchase();

    foreach($get_temp_purchase as $row){
        $data_insert_dt = array(
            'dt_hd_invoice'        => $hd_purchase_invoice,
            'dt_item_id'           => $row->temp_item_id,
            'dt_item_price'        => $row->temp_item_price,
            'dt_item_qty'          => $row->temp_item_qty,
            'dt_item_total'        => $row->temp_item_total,
        );
        $insertdtpurchase = $this->M_transaction->insertdtpurchase($data_insert_dt);


        $item_id_check = $row->temp_item_id;
        $item_qty_check = $row->temp_item_qty;
        $check_po = $this->M_transaction->check_po($item_id_check, $po_number_invoice);
        if($po_number_invoice != null){
            if($check_po[0]->dt_item_qty != $item_qty_check){
                $this->M_transaction->update_po_qty($item_id_check, $item_qty_check, $po_number_invoice);
            }
        }
        $item_id = $row->temp_item_id;
        $purchase_qty = $row->temp_item_qty;

        $last_stock = $this->M_transaction->last_stock($item_id);
        $last_stock = $last_stock[0]->item_total_qty;

        $new_stock = $last_stock + $purchase_qty;

        $updatestock = $this->M_transaction->updatestock($item_id, $new_stock);
    }

    $this->M_transaction->update_status_po($po_number);

    $this->clearTempPurchase($userid);

    $msg = 'Sukses';
    echo json_encode(['code'=>200, 'msg'=>$msg]);die();

}

public function detailpurchase()
{
    $this->check_auth();
    $hd_purchase_id = $this->input->get('id');
    $getPurchaseHd['getPurchaseHd'] = $this->M_transaction->getPurchaseHd($hd_purchase_id);
    $dt_hd_invoice  = $getPurchaseHd['getPurchaseHd'][0]->hd_purchase_invoice;
    $getPurchaseDetail['getPurchaseDetail'] = $this->M_transaction->getPurchaseDetail($dt_hd_invoice);
    $data['datas'] = array_merge_recursive($getPurchaseHd, $getPurchaseDetail);
    $this->load->view('transaction/purchasedetail', $data);
}
    // End Purchase //


}
