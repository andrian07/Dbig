<?php

defined('BASEPATH') OR exit('No direct script access allowed');
header('Access-Control-Allow-Origin: *');
header("Access-Control-Allow-Methods: GET, OPTIONS");

class Report extends CI_Controller
{
    public function __construct(){
        parent::__construct();
        $this->load->helper('url');
        $this->load->model('M_report');
        $this->load->model('M_masterdata');
        $this->load->library('session');
       
    }


    private function check_auth(){
        if(isset($_SESSION['user_name']) == null){
            redirect('Login', 'refresh');
        }
    }

    public function index()
    {
        //$this->check_auth();
        //$this->load->view('dashboard');
    }

    public function report_penjualan(){
        $this->check_auth();
        if($_POST != null){
        $date_from = $this->input->post('date_from');
        $date_end = $this->input->post('date_end');
        $report_total_penjualan['report_penjualan'] = $this->M_report->report_penjualan($date_from, $date_end);
        $report_total_penjualan_total['report_total_penjualan_total'] = $this->M_report->report_total_penjualan_total($date_from, $date_end);
        $data['data'] = array_merge($report_total_penjualan,$report_total_penjualan_total);
        $this->load->view('report/report_penjualan', $data);
        }else{
        $this->load->view('report/report_penjualan');            
        }
    }

    public function report_penjualan_excell(){
        $this->check_auth();
        $date_from = $this->input->get('date_from');
        $date_end = $this->input->get('date_end');
        $report_total_penjualan['report_penjualan'] = $this->M_report->report_penjualan($date_from, $date_end);
        $report_total_penjualan_total['report_total_penjualan_total'] = $this->M_report->report_total_penjualan_total($date_from, $date_end);
        $data['data'] = array_merge($report_total_penjualan,$report_total_penjualan_total);
        $this->load->view('report/report_penjualan_excell', $data);
    }

    public function report_pembelian(){
        $this->check_auth();
        if($_POST != null){
        $date_from = $this->input->post('date_from');
        $date_end = $this->input->post('date_end');
        $report_pembelian['report_pembelian'] = $this->M_report->report_pembelian($date_from, $date_end);
        $report_pembelian_total['report_pembelian_total'] = $this->M_report->report_pembelian_total($date_from, $date_end);
        $data['data'] = array_merge($report_pembelian,$report_pembelian_total);
        $this->load->view('report/report_pembelian', $data);
        }else{
        $this->load->view('report/report_pembelian');            
        }
    }

    public function report_pembelian_excell(){
        $this->check_auth();
        $date_from = $this->input->get('date_from');
        $date_end = $this->input->get('date_end');
        $report_pembelian['report_pembelian'] = $this->M_report->report_pembelian($date_from, $date_end);
        $report_pembelian_total['report_pembelian_total'] = $this->M_report->report_pembelian_total($date_from, $date_end);
        $data['data'] = array_merge($report_pembelian,$report_pembelian_total);
        $this->load->view('report/report_pembelian_excell', $data);
    }

    public function report_pinjaman(){
        $this->check_auth();
        $employee_id = $this->input->post('employee_id');
        if( $employee_id == null){
        $report_pinjaman['report_pinjaman'] = $this->M_report->report_pinjaman_all();
        }else{
        $report_pinjaman['report_pinjaman'] = $this->M_report->report_pinjaman($employee_id);
        }
        $get_employee['get_employee'] = $this->M_masterdata->get_employee();
        $data['data'] = array_merge($report_pinjaman,$get_employee);
        $this->load->view('report/report_pinjaman', $data);  
    }

    public function report_pinjaman_excell(){
        $this->check_auth();
        $employee_id = $this->input->get('employee_id');
        if( $employee_id == ' '){
        $report_pinjaman['report_pinjaman'] = $this->M_report->report_pinjaman_all();
        $report_pinjaman_total['report_pinjaman_total'] = $this->M_report->report_pinjaman_total_all();
        }else{
        $report_pinjaman['report_pinjaman'] = $this->M_report->report_pinjaman($employee_id);
        $report_pinjaman_total['report_pinjaman_total'] = $this->M_report->report_pinjaman_total($employee_id);
        } 

        $data['data'] = array_merge($report_pinjaman,$report_pinjaman_total);
        $this->load->view('report/report_pinjaman_excell', $data);
    }

    public function report_hutang(){
        $this->check_auth();
        if($_POST != null){
        $supplier_id = $this->input->post('supplier_id');
        $report_hutang['report_hutang'] = $this->M_report->report_hutang($supplier_id);
        $get_supplier['get_supplier'] = $this->M_masterdata->get_supplier();
        $data = array_merge($report_hutang, $supplier_id);
        $this->load->view('report/report_hutang', $data);
        }else{
        $get_supplier['get_supplier'] = $this->M_masterdata->get_supplier();
        $this->load->view('report/report_hutang', $get_supplier);            
        }
    }

    public function report_hutang_excell(){
        $this->check_auth();
        $supplier_id = $this->input->get('supplier_id');
        if($supplier_id == 'Semua'){
        $report_hutang['report_hutang'] = $this->M_report->report_hutang();
        }else{
         $report_hutang['report_hutang'] = $this->M_report->report_hutang_by_supplier($supplier_id);
        }
        $this->load->view('report/report_hutang_excell', $report_hutang);
    }

    public function report_piutang(){
        $this->check_auth();
        $get_customer['get_customer'] = $this->M_masterdata->get_customer();
        $this->load->view('report/report_piutang', $get_customer); 
    }

    public function report_piutang_excell(){
        $this->check_auth();
        $customer_id = $this->input->get('customer_id');
        if($customer_id == 'Semua'){
        $report_piutang['report_piutang'] = $this->M_report->report_piutang();
        }else{
        $report_piutang['report_piutang'] = $this->M_report->report_piutang_by_customer($customer_id);
        }
        $this->load->view('report/report_piutang_excell', $report_piutang);
    }

    public function report_laba(){
        $this->check_auth();
        $this->load->view('report/report_laba');
    }

    public function report_laba_excell(){
        $this->check_auth();
        $date_from = $this->input->get('date_from');
        $date_end = $this->input->get('date_end');
        $report_total_dp_transaksi['report_total_dp_transaksi'] = $this->M_report->report_total_dp_transaksi($date_from, $date_end);
        $report_total_pelunasan_transaksi['report_total_pelunasan_transaksi'] = $this->M_report->report_total_pelunasan_transaksi($date_from, $date_end);
        $report_total_pelunasan_karyawan['report_total_pelunasan_karyawan'] = $this->M_report->report_total_pelunasan_karyawan($date_from, $date_end);


        $report_total_dp_purchase['report_total_dp_purchase'] = $this->M_report->report_total_dp_purchase($date_from, $date_end);
        $report_total_pelunasan_purchase['report_total_pelunasan_purchase'] = $this->M_report->report_total_pelunasan_purchase($date_from, $date_end);
        $report_total_peminjaman_karyawan['report_total_peminjaman_karyawan'] = $this->M_report->report_total_peminjaman_karyawan($date_from, $date_end);
        $report_total_pengeluaran['report_total_pengeluaran'] = $this->M_report->report_total_pengeluaran($date_from, $date_end);

        $data['data'] = array_merge($report_total_dp_transaksi,$report_total_pelunasan_transaksi, $report_total_pelunasan_karyawan, $report_total_dp_purchase, $report_total_pelunasan_purchase, $report_total_peminjaman_karyawan, $report_total_pengeluaran);

        $this->load->view('report/report_laba_excell', $data);
    }


}
