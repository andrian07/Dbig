<?php

defined('BASEPATH') OR exit('No direct script access allowed');
header('Access-Control-Allow-Origin: *');
header("Access-Control-Allow-Methods: GET, OPTIONS");

class Repayment extends CI_Controller
{
    public function __construct(){
        parent::__construct();
        $this->load->helper('url');
        $this->load->model('M_repayment');
        $this->load->library('session');
    }

    private function check_auth(){
        if(isset($_SESSION['user_name']) == null){
            redirect('Login', 'refresh');
        }
    }

    public function debt()
    {
        $this->check_auth();
        $list_supplier_debt['list_supplier_debt'] = $this->M_repayment->get_supplier_debt();
        $this->load->view('repayment/debt', $list_supplier_debt);
    }

    public function receivables()
    {
        $this->check_auth();
        $list_customer_receivables['list_customer_receivables'] = $this->M_repayment->get_customer_receivables();
        $this->load->view('repayment/receivables', $list_customer_receivables);
    }

    public function debtpayment()
    {
        $this->check_auth();
        $id = $this->input->get('id');
        $userid = $_SESSION['user_id'];
        //$this->M_repayment->clearTemp($userid);
        //$this->moveToTemp($id);
        $list_purchase_debt_temp['list_purchase_debt_temp'] = $this->M_repayment->get_purchase_debt_temp($id);
        $list_supplier_debt_supplier['list_supplier_debt_supplier'] = $this->M_repayment->get_supplier_debt_header($id);
        $data['datas'] = array_merge_recursive($list_purchase_debt_temp, $list_supplier_debt_supplier);
        $this->load->view('repayment/debtpayment', $data);
    }

    public function receivablespayment()
    {
        $this->check_auth();
        $id = $this->input->get('id');
        $userid = $_SESSION['user_id'];
        $list_transaction_receivables_temp['list_transaction_receivables_temp'] = $this->M_repayment->get_transaction_receivables_temp($id);
        $list_customer_receivables['list_customer_receivables'] = $this->M_repayment->get_customer_receivables_header($id);
        $data['datas'] = array_merge_recursive($list_transaction_receivables_temp, $list_customer_receivables);
        $this->load->view('repayment/receivablespayment', $data);
    }

    public function moveToTemp($id)
    {
        $list_purchase_debt = $this->M_repayment->get_purchase_debt($id);
        foreach($list_purchase_debt as $row){
            $data_insert = array(
                'temp_debt_purchase_id'  => $row->hd_purchase_id,
                'temp_debt_invoice'      => $row->hd_purchase_invoice,
                'temp_debt_pay'          => 0,
                'temp_debt_desc'         => '',
                'temp_debt_user_id'      => $_SESSION['user_id'],
            );
            $inserttempdebt = $this->M_repayment->inserttempdebt($data_insert);
        }  
    }

    public function get_debt_repayment()
    {
        $this->check_auth();
        $id = $this->input->get('id');
        $get_debt_repayment = $this->M_repayment->get_debt_repayment($id);
        echo json_encode(['code'=>200, 'result'=>$get_debt_repayment]);die();
    }

    public function get_receivables_repayment()
    {
        $this->check_auth();
        $id = $this->input->get('id');
        $get_receivables_repayment = $this->M_repayment->get_receivables_repayment($id);
        echo json_encode(['code'=>200, 'result'=>$get_receivables_repayment]);die();
    }

    public function processadddebt()
    {

        $this->check_auth();
        $purchase_id      = $this->input->post('purchase_id');
        $purchase_invoice    = $this->input->post('purchase_invoice');
        $repayment_remark = $this->input->post('repayment_remark');
        $repayment_total_val   = $this->input->post('repayment_total_val');
        $new_remaining_debt_val = $this->input->post('new_remaining_debt_val');

        if($repayment_total_val == '' || $new_remaining_debt_val <= 0){
            $msg = 'Silahkan Isi Semua Data';
            echo json_encode(['code'=>0, 'msg'=>$msg]);die();
        }

        $data_insert = array(
            'temp_debt_purchase_id'       => $purchase_id,
            'temp_debt_invoice'           => $purchase_invoice,
            'temp_debt_pay'               => $repayment_total_val,
            'temp_debt_desc'              => $repayment_remark,
            'temp_debt_remaining'         => $new_remaining_debt_val,
            'temp_debt_user_id'           => $_SESSION['user_id'],
        );

        $check_input = $this->M_repayment->check_input($purchase_id);
        if($check_input == null){
            $inserttempdebt = $this->M_repayment->inserttempdebt($data_insert);
        }else{
            $data_update = array(
                'temp_debt_pay'               => $repayment_total_val,
                'temp_debt_desc'              => $repayment_remark,
                'temp_debt_remaining'         => $new_remaining_debt_val
            );
            $updatetempdebt = $this->M_repayment->updatetempdebt($data_update, $purchase_id);
        }
        echo json_encode(['code'=>200, 'msg'=>'Sukses']);die();

    }

    public function processsavedebt()
    {

        $this->check_auth();
        $supplier_id      = $this->input->post('supplier_id');
        $repayment_date    = $this->input->post('repayment_date');
        $footer_total_pay_val = $this->input->post('footer_total_pay_val');
        $footer_total_nota_val   = $this->input->post('footer_total_nota_val');
        $userid = $_SESSION['user_id'];

        $get_last_number_debt = $this->M_repayment->get_last_number_debt();
        if($get_last_number_debt == null){
            $hd_debt_transaction_no = '000000001/PH-DPM/'.date("Y");
        }else{
            $hd_debt_transaction_no = $get_last_number_debt[0]->hd_debt_transaction_no;
            $hd_debt_transaction_no = substr($hd_debt_transaction_no, 0, 9) + 1;
            $hd_debt_transaction_no = str_pad($hd_debt_transaction_no, 9, '0', STR_PAD_LEFT).'/PH-DPM/'.date("Y");
        }

        $data_insert = array(
            'hd_debt_transaction_no'    => $hd_debt_transaction_no,
            'hd_debt_supplier_id'       => $supplier_id,
            'hd_debt_total_pay'         => $footer_total_pay_val,
            'hd_debt_total_invoice'     => $footer_total_nota_val,
            'hd_debt_date'              => $repayment_date,
            'hd_debt_user_id'           => $_SESSION['user_id'],
        );

        $insertdebt = $this->M_repayment->insertdebt($data_insert);

        $get_temp = $this->M_repayment->get_temp($userid);
        foreach($get_temp as $row){
            $data_insert_dt = array(
                'dt_debt_transaction_no'     => $hd_debt_transaction_no,
                'dt_debt_invoice    '        => $row->temp_debt_invoice,
                'dt_debt_pay'                => $row->temp_debt_pay,
                'dt_debt_desc'               => $row->temp_debt_desc,
            );

        $insertdtdebt = $this->M_repayment->insertdtdebt($data_insert_dt);

        $hd_purchase_invoice = $row->temp_debt_invoice;
        $new_remianing_debt = $row->temp_debt_remaining;

        $update_remaining_purchase = $this->M_repayment->update_remaining_purchase($hd_purchase_invoice, $new_remianing_debt);

        }

        $this->M_repayment->clearTemp($userid);
        echo json_encode(['code'=>200, 'msg'=>'Sukses']);die();
    }


    public function processsavereceivables()
    {

        $this->check_auth();
        $customer_id      = $this->input->post('customer_id');
        $repayment_date    = $this->input->post('repayment_date');
        $footer_total_pay_val = $this->input->post('footer_total_pay_val');
        $footer_total_nota_val   = $this->input->post('footer_total_nota_val');
        $userid = $_SESSION['user_id'];

        $get_last_number_receivables = $this->M_repayment->get_last_number_receivables();
        if($get_last_number_receivables == null){
            $hd_receivables_transaction_no = '000000001/PH-DPM/'.date("Y");
        }else{
            $hd_receivables_transaction_no = $get_last_number_receivables[0]->hd_receivables_transaction_no;
            $hd_receivables_transaction_no = substr($hd_receivables_transaction_no, 0, 9) + 1;
            $hd_receivables_transaction_no = str_pad($hd_receivables_transaction_no, 9, '0', STR_PAD_LEFT).'/PH-DPM/'.date("Y");
        }

        $data_insert = array(
            'hd_receivables_transaction_no'    => $hd_receivables_transaction_no,
            'hd_receivables_customer_id'       => $customer_id,
            'hd_receivables_total_pay'         => $footer_total_pay_val,
            'hd_receivables_total_invoice'     => $footer_total_nota_val,
            'hd_receivables_date'              => $repayment_date,
            'hd_receivables_user_id'           => $_SESSION['user_id'],
        );

        $insertreceivables = $this->M_repayment->insertreceivables($data_insert);

        $get_temp_receivables = $this->M_repayment->get_temp_receivables($userid);
        foreach($get_temp_receivables as $row){
            $data_insert_dt = array(
                'dt_receivables_transaction_no'     => $hd_receivables_transaction_no,
                'dt_receivables_invoice'            => $row->temp_receivables_invoice,
                'dt_receivables_pay'                => $row->temp_receivables_pay,
                'dt_receivables_desc'               => $row->temp_receivables_desc,
            );

        $insertdtreceivables = $this->M_repayment->insertdtreceivables($data_insert_dt);

        $transaction_invoice = $row->temp_receivables_invoice;
        $new_remianing_debt = $row->temp_receivables_remaining;

        $update_remaining_sales = $this->M_repayment->update_remaining_sales($transaction_invoice, $new_remianing_debt);

        }

        $this->M_repayment->clearTempreceivables($userid);
        echo json_encode(['code'=>200, 'msg'=>'Sukses']);die();
    }


    public function getfooterdebt()
    {
        $this->check_auth();
        $userid = $_SESSION['user_id'];
        $get_footer_debt = $this->M_repayment->get_footer_debt($userid);
        echo json_encode(['code'=>200, 'result'=>$get_footer_debt]);die();
    }

    public function getfooterreceivables()
    {
         $this->check_auth();
        $userid = $_SESSION['user_id'];
        $get_footer_receivables = $this->M_repayment->get_footer_receivables($userid);
        echo json_encode(['code'=>200, 'result'=>$get_footer_receivables]);die();
    }

     public function processaddreceivables()
    {

        $this->check_auth();
        $sales_id      = $this->input->post('sales_id');
        $sales_invoice    = $this->input->post('sales_invoice');
        $repayment_remark = $this->input->post('repayment_remark');
        $repayment_total_val   = $this->input->post('repayment_total_val');
        $new_remaining_sales_val = $this->input->post('new_remaining_sales_val');

        if($repayment_total_val == '' || $new_remaining_sales_val <= 0){
            $msg = 'Silahkan Isi Semua Data';
            echo json_encode(['code'=>0, 'msg'=>$msg]);die();
        }

        $data_insert = array(
            'temp_receivables_sales_id'          => $sales_id,
            'temp_receivables_invoice'           => $sales_invoice,
            'temp_receivables_pay'               => $repayment_total_val,
            'temp_receivables_remaining'         => $new_remaining_sales_val,
            'temp_receivables_desc'              => $repayment_remark,
            'temp_receivables_user_id'           => $_SESSION['user_id'],
        );

        $check_input_receivables = $this->M_repayment->check_input_receivables($sales_id);
        if($check_input_receivables == null){
            $inserttempreceivables = $this->M_repayment->inserttempreceivables($data_insert);
        }else{
            $data_update = array(
                'temp_receivables_pay'               => $repayment_total_val,
                'temp_receivables_desc'              => $repayment_remark,
                'temp_receivables_remaining'         => $new_remaining_sales_val
            );
        $updatetempreceivables = $this->M_repayment->updatetempreceivables($data_update, $sales_id);
        }
        echo json_encode(['code'=>200, 'msg'=>'Sukses']);die();

    }


}
