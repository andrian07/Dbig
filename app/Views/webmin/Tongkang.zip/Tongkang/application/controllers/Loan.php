<?php

defined('BASEPATH') OR exit('No direct script access allowed');
header('Access-Control-Allow-Origin: *');
header("Access-Control-Allow-Methods: GET, OPTIONS");

class Loan extends CI_Controller
{
    public function __construct(){
        parent::__construct();
        $this->load->helper('url');
        $this->load->model('M_loan');
        $this->load->model('M_masterdata');
        $this->load->library('session');
    }

    private function check_auth(){
        if(isset($_SESSION['user_name']) == null){
            redirect('Login', 'refresh');
        }
    }

    public function index()
    {
        $this->check_auth();
        $list_loan_employee['list_loan_employee'] = $this->M_loan->get_loan_employee();
        $this->load->view('Loan/loan', $list_loan_employee);
    }

    public function loanpayment()
    {
        $this->check_auth();
        $id = $this->input->get('id');
        $list_loan_payment['list_loan_payment'] = $this->M_loan->get_loan_payment($id);
        $this->load->view('Loan/loanpayment', $list_loan_payment);
    }

    public function processaddloan()
    {
        $this->check_auth();
        $employee_id = $this->input->post('employee_id');
        $loan_total = $this->input->post('loan_total');
        $loan_desc = $this->input->post('loan_desc');
        $loan_date = $this->input->post('loan_date');
        $loan_type = 'Pinjam';
        $user_id = $_SESSION['user_id'];

        if($loan_total == null ){
            $msg = 'Silahkan Isi Jumlah Pinjaman';
            echo json_encode(['code'=>0, 'msg'=>$msg]);die();
        }

        $data_insert = array(
            'loan_employee_id'   => $employee_id,
            'loan_date'          => $loan_date,
            'loan_type'          => $loan_type,
            'loan_total'         => $loan_total,
            'loan_desc'          => $loan_desc,
            'created_by'         => $user_id
        );

        $get_remaining_loan = $this->M_loan->get_remaining_loan($employee_id);

        $loan_debt_remaining = $get_remaining_loan[0]->loan_debt_remaining;
        $new_debt = $loan_debt_remaining + $loan_total;

        $update_debt_remaining = $this->M_loan->update_debt_remaining($employee_id, $new_debt);

        $insertloan = $this->M_loan->insertloan($data_insert);
        $msg = 'Sukses';
        echo json_encode(['code'=>200, 'msg'=>$msg]);die(); 
    }

    public function processpayloan()
    {
        $this->check_auth();
        $employee_id = $this->input->post('employee_id');
        $loan_total = $this->input->post('total_pay_loan_val');
        $loan_date = $this->input->post('pay_loan_date');
        $loan_type = 'Bayar';
        $user_id = $_SESSION['user_id'];

        if($loan_total == null ){
            $msg = 'Silahkan Isi Jumlah Pinjaman';
            echo json_encode(['code'=>0, 'msg'=>$msg]);die();
        }

        $data_insert = array(
            'loan_employee_id'   => $employee_id,
            'loan_date'          => $loan_date,
            'loan_type'          => $loan_type,
            'loan_total'         => $loan_total,
            'created_by'         => $user_id
        );

        $get_remaining_loan = $this->M_loan->get_remaining_loan($employee_id);

        $loan_debt_remaining = $get_remaining_loan[0]->loan_debt_remaining;
        $new_debt = $loan_debt_remaining - $loan_total;

        $update_debt_remaining = $this->M_loan->update_debt_remaining($employee_id, $new_debt);

        $insertloan = $this->M_loan->insertloan($data_insert);
        $msg = 'Sukses';
        echo json_encode(['code'=>200, 'msg'=>$msg]);die(); 
    }

    public function setremainingdebt()
    {
        $this->check_auth();
        $id = $this->input->get('id');
        $get_loan_payment = $this->M_loan->get_remaining_loan($id);
        $loan_debt_remaining = $get_loan_payment[0]->loan_debt_remaining;
        echo json_encode(['code'=>200, 'loan_debt_remaining'=>$loan_debt_remaining]);die();
    }

}
