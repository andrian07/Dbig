<?php defined('BASEPATH') OR exit('No direct script access allowed'); 

class M_expenditure extends CI_Model { 


	public function inserttempexpenditure($data_insert)
	{
		$this->db->insert('temp_exoenditure', $data_insert);
	}

    public function insertheaderExpenditure($data_insert)
    {
        $this->db->insert('hd_expenditure', $data_insert);
    }

    public function insertdtExpenditure($data_insert_dt)
    {
        $this->db->insert('dt_exoenditure', $data_insert_dt);
    }

    public function edittempexpenditure($data_insert)
    {
        $temp_expenditure_id = $data_insert['temp_expenditure_id'];
        $this->db->set($data_insert);
        $this->db->where('temp_expenditure_id', $temp_expenditure_id);
        $this->db->update('temp_exoenditure');
    }

    public function deleteTempExpenditure($temp_expenditure_id)
    {
        $this->db->where('temp_expenditure_id', $temp_expenditure_id);
        $this->db->delete('temp_exoenditure');
    }

    public function clearTempExpenditure($userid)
    {
        $this->db->where('temp_expenditure_user_id', $userid);
        $this->db->delete('temp_exoenditure');
    }

	public function get_expenditur()
	{
		$query = $this->db->query("select * from hd_expenditure where  is_deleted = 'N'");
        $result = $query->result();
        return $result;
	}

    public function get_dt_expenditure($invoice)
    {
        $query = $this->db->query("select * from dt_exoenditure where dt_expenditure_invoice = '".$invoice."'");
        $result = $query->result();
        return $result;
    }

    public function get_hd_expenditure($id)
    {
        $query = $this->db->query("select * from hd_expenditure a, master_user c where a.hd_expenditure_created_by = c.user_id and hd_expenditure_id = '".$id."'");
        $result = $query->result();
        return $result;
    }

    public function get_last_number_expanditure()
    {
        $query = $this->db->query("select hd_expenditure_id, hd_expenditure_invoice from hd_expenditure order by hd_expenditure_id desc limit 1");
        $result = $query->result();
        return $result;
    }


    public function get_temp_expenditure()
    {
        $userid = $_SESSION['user_id'];   
        $query = $this->db->query("select * from temp_exoenditure where temp_expenditure_user_id = '".$userid."'");
        $result = $query->result();
        return $result;
    }

     public function get_edit_temp($id)
    {
        $user_id = $_SESSION['user_id'];   
         $query = $this->db->query("select * from temp_exoenditure where temp_expenditure_user_id = '".$user_id."' and temp_expenditure_id = '".$id."'");
         $result = $query->result();
         return $result;
    }

     public function get_expenditure_footer()
    {
        $user_id = $_SESSION['user_id'];   
         $query = $this->db->query("select sum(temp_expenditure_total) as sub_total from temp_exoenditure where temp_expenditure_user_id = '".$user_id."'");
         $result = $query->result();
         return $result;
    }

    public function get_count_dt_expenditure($invoice)
    {
        $query = $this->db->query("select count(*) as total_row from dt_exoenditure where dt_expenditure_invoice = '".$invoice."'");
        $result = $query->result();
        return $result;
    }

}