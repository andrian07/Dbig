<?php defined('BASEPATH') OR exit('No direct script access allowed'); 

class M_repayment extends CI_Model { 

    public function inserttempdebt($data_insert)
    {
        $this->db->insert('temp_debt', $data_insert);
    }

    public function insertdebt($data_insert)
    {
        $this->db->insert('hd_debt', $data_insert);
    }

     public function inserttempreceivables($data_insert)
    {
        $this->db->insert('temp_receivables', $data_insert);
    }
    public function insertdtdebt($data_insert_dt)
    {
         $this->db->insert('dt_debt', $data_insert_dt);
    }

    public function insertdtreceivables($data_insert_dt)
    {
        $this->db->insert('dt_receivables', $data_insert_dt);
    }

    public function insertreceivables($data_insert)
    {
        $this->db->insert('hd_receivables', $data_insert);
    }

    public function get_last_number_debt()
    {
        $query = $this->db->query("select hd_debt_id, hd_debt_transaction_no from hd_debt order by hd_debt_id desc limit 1");
        $result = $query->result();
        return $result;
    }

    public function get_last_number_receivables()
    {
        $query = $this->db->query("select hd_receivables_id, hd_receivables_transaction_no from hd_receivables order by hd_receivables_id desc limit 1");
        $result = $query->result();
        return $result;
    }

    public function get_supplier_debt()
    {
        $query = $this->db->query("select *, sum(hd_purchase_debt_remaining) as total_debt, count(*) as total_invoice from hd_purchase a, master_supplier b where a.hd_purchase_supplier_id = b.supplier_id and  hd_purchase_debt_remaining > 0");
        $result = $query->result();
        return $result;
    }

    public function get_customer_receivables()
    {
        $query = $this->db->query("select *, sum(transaction_receivables_remaining) as total_receivables, count(*) as total_invoice from hd_transaction a, master_customer b where a.transaction_customer_id = b.customer_id and  transaction_receivables_remaining > 0 ");
        $result = $query->result();
        return $result;
    }

     public function get_supplier_debt_header($id)
    {
        $query = $this->db->query("select *, sum(hd_purchase_debt_remaining) as total_debt, count(*) as total_invoice from hd_purchase a, master_supplier b where a.hd_purchase_supplier_id = b.supplier_id and  hd_purchase_debt_remaining > 0 and hd_purchase_supplier_id = '".$id."' ");
        $result = $query->result();
        return $result;
    }

     public function get_customer_receivables_header($id)
    {
        $query = $this->db->query("select *, sum(transaction_receivables_remaining) as total_receivables, count(*) as total_invoice from hd_transaction a, master_customer b where a.transaction_customer_id = b.customer_id and  transaction_receivables_remaining > 0 and transaction_customer_id = '".$id."' ");
        $result = $query->result();
        return $result;
    }

    public function get_purchase_debt($id)
    {
        $query = $this->db->query("select * from hd_purchase a, master_supplier b where a.hd_purchase_supplier_id = b.supplier_id and  hd_purchase_debt_remaining > 0 and hd_purchase_supplier_id = '".$id."'");
        $result = $query->result();
        return $result;
    }

    public function get_purchase_debt_temp($id)
    {
        $query = $this->db->query("select * FROM hd_purchase LEFT JOIN temp_debt ON temp_debt.temp_debt_purchase_id = hd_purchase.hd_purchase_id where hd_purchase_debt_remaining > 0 and hd_purchase_supplier_id = '".$id."'");
        $result = $query->result();
        return $result;
    }

    public function get_transaction_receivables_temp($id)
    {
        $query = $this->db->query("select * FROM hd_transaction LEFT JOIN temp_receivables ON temp_receivables.temp_receivables_sales_id = hd_transaction.hd_transaction where transaction_receivables_remaining > 0 and transaction_customer_id = '".$id."'");
        $result = $query->result();
        return $result;
    }

    public function get_temp($userid)
    {
        $query = $this->db->query("select * from temp_debt where temp_debt_user_id = '".$userid."'");
        $result = $query->result();
        return $result;
    }

    public function get_temp_receivables($userid)
    {
        $query = $this->db->query("select * from temp_receivables where temp_receivables_user_id = '".$userid."'");
        $result = $query->result();
        return $result;
    }

    public function get_debt_repayment($id)
    {
        $query = $this->db->query("select * from hd_purchase where hd_purchase_id = '".$id."'");
        $result = $query->result();
        return $result;
    }

    public function get_receivables_repayment($id)
    {
        $query = $this->db->query("select * from hd_transaction where hd_transaction = '".$id."'");
        $result = $query->result();
        return $result;
    }

    public function check_input($purchase_id)
    {
        $query = $this->db->query("select * from temp_debt where temp_debt_purchase_id = '".$purchase_id."'");
        $result = $query->result();
        return $result;
    }
    
    public function check_input_receivables($sales_id)
    {
        $query = $this->db->query("select * from temp_receivables where temp_receivables_sales_id = '".$sales_id."'");
        $result = $query->result();
        return $result;
    }

    public function clearTemp($userid)
    {
        $this->db->where('temp_debt_user_id', $userid);
        $this->db->delete('temp_debt');
    }

    public function clearTempreceivables($userid)
    {
        $this->db->where('temp_receivables_user_id', $userid);
        $this->db->delete('temp_receivables');
    }

    public function updatetempdebt($data_update, $purchase_id)
    {
        $this->db->set($data_update);
        $this->db->where('temp_debt_purchase_id', $purchase_id);
        $this->db->update('temp_debt');
    }

    public function updatetempreceivables($data_update, $sales_id)
    {
        $this->db->set($data_update);
        $this->db->where('temp_receivables_sales_id', $sales_id);
        $this->db->update('temp_receivables');
    }



    public function update_remaining_purchase($hd_purchase_invoice, $new_remianing_debt)
    {
        $this->db->set('hd_purchase_debt_remaining', $new_remianing_debt);
        $this->db->where('hd_purchase_invoice', $hd_purchase_invoice);
        $this->db->update('hd_purchase');
    }

    public function update_remaining_sales($transaction_invoice, $new_remianing_debt)
    {
        $this->db->set('transaction_receivables_remaining', $new_remianing_debt);
        $this->db->where('transaction_invoice', $transaction_invoice);
        $this->db->update('hd_transaction');
    }

    

    public function get_footer_debt($userid)
    {
        $query = $this->db->query("select sum(temp_debt_pay) as total_pay_footer, count(*) as total_inv_footer from temp_debt where temp_debt_user_id = '".$userid."'");
        $result = $query->result();
        return $result;
    }

    public function get_footer_receivables($userid)
    {
        $query = $this->db->query("select sum(temp_receivables_pay) as total_pay_footer, count(*) as total_inv_footer from temp_receivables where temp_receivables_user_id = '".$userid."'");
        $result = $query->result();
        return $result;
    }

}