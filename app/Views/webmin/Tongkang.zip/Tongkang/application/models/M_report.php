<?php defined('BASEPATH') OR exit('No direct script access allowed'); 

class M_report extends CI_Model { 

    public function report_penjualan($date_from, $date_end)
    {
        $query = $this->db->query("select * from hd_transaction a, master_customer b where a.transaction_customer_id = b.customer_id and transaction_date between '".$date_from."' and '".$date_end."'");
        $result = $query->result();
        return $result;
    }

    public function report_total_penjualan_total($date_from, $date_end)
    {
        $query = $this->db->query("select sum(transaction_total) as total_transaksi from hd_transaction where transaction_date between '".$date_from."' and '".$date_end."'");
        $result = $query->result();
        return $result;
    }

    public function report_pembelian($date_from, $date_end)
    {
        $query = $this->db->query("select * from hd_purchase a, master_supplier b where a.hd_purchase_supplier_id = b.supplier_id and hd_purchase_date between '".$date_from."' and '".$date_end."'");
        $result = $query->result();
        return $result;
    }

    public function report_pembelian_total($date_from, $date_end)
    {
        $query = $this->db->query("select sum(hd_purchase_total) as total_transaksi from hd_purchase a, master_supplier b where a.hd_purchase_supplier_id = b.supplier_id and hd_purchase_date between '".$date_from."' and '".$date_end."'");
        $result = $query->result();
        return $result;
    }

    public function report_pinjaman_all()
    {
        $query = $this->db->query("select * from master_employee");
        $result = $query->result();
        return $result;
    }

    public function report_pinjaman($employee_id)
    {
        $query = $this->db->query("select * from master_employee where employee_id = '".$employee_id."'");
        $result = $query->result();
        return $result;
    }

    public function report_pinjaman_total($employee_id)
    {
        $query = $this->db->query("select sum(loan_debt_remaining) as total_pinjaman from master_employee where employee_id = '".$employee_id."'");
        $result = $query->result();
        return $result;
    }

    public function report_pinjaman_total_all()
    {
        $query = $this->db->query("select sum(loan_debt_remaining) as total_pinjaman from master_employee");
        $result = $query->result();
        return $result;
    }

     public function report_hutang()
    {
        $query = $this->db->query("select *, sum(hd_purchase_debt_remaining) as total_debt, count(*) as total_invoice from hd_purchase a, master_supplier b where a.hd_purchase_supplier_id = b.supplier_id and  hd_purchase_debt_remaining > 0");
        $result = $query->result();
        return $result;
    }

    public function report_hutang_by_supplier($supplier_id)
    {
        $query = $this->db->query("select *, sum(hd_purchase_debt_remaining) as total_debt, count(*) as total_invoice from hd_purchase a, master_supplier b where a.hd_purchase_supplier_id = b.supplier_id and  hd_purchase_debt_remaining > 0 and supplier_id = '".$supplier_id."'");
        $result = $query->result();
        return $result;
    }

    public function report_piutang()
    {
        $query = $this->db->query("select *, sum(transaction_receivables_remaining) as total_receivables, count(*) as total_invoice from hd_transaction a, master_customer b where a.transaction_customer_id = b.customer_id and  transaction_receivables_remaining > 0 ");
        $result = $query->result();
        return $result;
    }

    public function report_piutang_by_customer($customer_id)
    {
        $query = $this->db->query("select *, sum(transaction_receivables_remaining) as total_receivables, count(*) as total_invoice from hd_transaction a, master_customer b where a.transaction_customer_id = b.customer_id and  transaction_receivables_remaining > 0 and customer_id = '".$customer_id."'");
        $result = $query->result();
        return $result;
    }

    public function report_total_dp_transaksi($date_from, $date_end)
    {
        $query = $this->db->query("select sum(transaction_dp) as total_dp from hd_transaction where transaction_date between '".$date_from."' and '".$date_end."' ");
        $result = $query->result();
        return $result;
    }

    public function report_total_pelunasan_transaksi($date_from, $date_end)
    {
        $query = $this->db->query("select sum(hd_receivables_total_pay) as total_pay from hd_receivables where hd_receivables_date between '".$date_from."' and '".$date_end."' ");
        $result = $query->result();
        return $result;
    }

    public function report_total_pelunasan_karyawan($date_from, $date_end)
    {
        $query = $this->db->query("select sum(loan_total) as loan_total from tbl_loan where loan_date between '".$date_from."' and '".$date_end."' and loan_type = 'Bayar'");
        $result = $query->result();
        return $result;
    }



     public function report_total_dp_purchase($date_from, $date_end)
    {
        $query = $this->db->query("select sum(hd_purchase_dp) as total_dp from hd_purchase where hd_purchase_date between '".$date_from."' and '".$date_end."' ");
        $result = $query->result();
        return $result;
    }

    public function report_total_pelunasan_purchase($date_from, $date_end)
    {
        $query = $this->db->query("select sum(hd_debt_total_pay) as total_pay from hd_debt where hd_debt_date between '".$date_from."' and '".$date_end."' ");
        $result = $query->result();
        return $result;
    }

    public function report_total_peminjaman_karyawan($date_from, $date_end)
    {
        $query = $this->db->query("select sum(loan_total) as loan_total from tbl_loan where loan_date between '".$date_from."' and '".$date_end."' and loan_type = 'Pinjam'");
        $result = $query->result();
        return $result;
    }
    public function report_total_pengeluaran($date_from, $date_end)
    {
        $query = $this->db->query("select sum(hd_expenditure_total) as total_expenditure from hd_expenditure where hd_expenditure_date between '".$date_from."' and '".$date_end."' ");
        $result = $query->result();
        return $result;
    }

}