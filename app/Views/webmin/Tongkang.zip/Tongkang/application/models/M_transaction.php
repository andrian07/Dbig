<?php defined('BASEPATH') OR exit('No direct script access allowed'); 

class M_transaction extends CI_Model { 

    public function inserttemppo($data_insert)
    {
        $this->db->insert('temp_po', $data_insert);
    }

    public function insertheaderpo($data_insert)
    {
        $this->db->insert('hd_po', $data_insert);
    }

    public function insertheaderpurchase($data_insert)
    {
        $this->db->insert('hd_purchase', $data_insert);
    }

    public function insertdtpo($data_insert_dt)
    {
        $this->db->insert('dt_po', $data_insert_dt);
    }

    public function insertdtpurchase($data_insert_dt)
    {
        $this->db->insert('dt_purchase', $data_insert_dt);
    }


    public function inserttemppurchase($data_insert)
    {
        $this->db->insert('temp_purchase', $data_insert);
    }

    public function deletetemppo($temp_po_id)
    {
        $this->db->where('temp_po_id', $temp_po_id);
        $this->db->delete('temp_po');
    }

    public function deletetemppurchase($temp_purchase_id)
    {
        $this->db->where('temp_purchase_id', $temp_purchase_id);
        $this->db->delete('temp_purchase');
    }


    public function clearTempPo($userid)
    { 
        $this->db->where('temp_item_user', $userid);
        $this->db->delete('temp_po');
    }

    public function clearTempPurchase($userid)
    {

        $this->db->where('temp_item_user', $userid);
        $this->db->delete('temp_purchase');
    }

    public function clearDetail($hd_po_invoice)
    {
        $this->db->where('dt_hd_invoice', $hd_po_invoice);
        $this->db->delete('dt_po');
    }

    public function update_status_po($po_number)
    {
        $this->db->set('hd_po_status', 'Selesai');
        $this->db->where('hd_po_id ', $po_number);
        $this->db->update('hd_po');
    }

    public function update_po_qty($item_id_check, $item_qty_check, $po_number_invoice)
    {
        $this->db->set('dt_item_qty', $item_qty_check);
        $this->db->where('dt_hd_invoice', $po_number_invoice);
        $this->db->where('dt_item_id', $item_id_check);
        $this->db->update('dt_po');
    }

    public function updatestock($item_id, $new_stock)
    {
        $this->db->set('item_total_qty', $new_stock);
        $this->db->where('item_id', $item_id);
        $this->db->update('master_item');
    }

    public function edittemppo($data_insert)
    {   
        $temp_po_id = $data_insert['temp_po_id'];
        $this->db->set($data_insert);
        $this->db->where('temp_po_id', $temp_po_id);
        $this->db->update('temp_po');
    }

     public function edittemppurchase($data_insert)
    {   
        $temp_purchase_id = $data_insert['temp_purchase_id'];
        $this->db->set($data_insert);
        $this->db->where('temp_purchase_id', $temp_purchase_id);
        $this->db->update('temp_purchase');
    }

    public function editpo($data_edit)
    {
        $hd_po_id = $data_edit['hd_po_id'];
        $this->db->set($data_edit);
        $this->db->where('hd_po_id', $hd_po_id);
        $this->db->update('hd_po');
    }

    public function cancelpo($hd_po_id)
    {

        $this->db->set('hd_po_status', 'Cancel');
        $this->db->where('hd_po_id', $hd_po_id);
        $this->db->update('hd_po');
    }

    public function get_po()
    {
        $query = $this->db->query("select * from hd_po a, master_supplier b where a.hd_po_supplier_id = b.supplier_id");
        $result = $query->result();
        return $result;
    }

    public function last_stock($item_id)
    {
        $query = $this->db->query("select item_total_qty from master_item where item_id = '".$item_id."' ");
        $result = $query->result();
        return $result;
    }

    public function get_purchase()
    {
        $query = $this->db->query("select * from hd_purchase a, master_supplier b where a.hd_purchase_supplier_id = b.supplier_id");
        $result = $query->result();
        return $result;
    }

    public function get_temp_po()
    {    
         $user_id = $_SESSION['user_id'];   
         $query = $this->db->query("select * from temp_po a, master_item b where a.temp_item_id = b.item_id and temp_item_user = '".$user_id."'");
         $result = $query->result();
         return $result;
    }

    public function get_temp_purchase()
    {
        $user_id = $_SESSION['user_id'];   
         $query = $this->db->query("select * from temp_purchase a, master_item b where a.temp_item_id = b.item_id and temp_item_user = '".$user_id."'");
         $result = $query->result();
         return $result;
    }

    public function get_edit_temp($id)
    {
        $user_id = $_SESSION['user_id'];   
         $query = $this->db->query("select * from temp_po where temp_item_user = '".$user_id."' and temp_po_id = '".$id."'");
         $result = $query->result();
         return $result;
    }

    public function get_edit_temp_purchase($id)
    {
        $user_id = $_SESSION['user_id'];   
         $query = $this->db->query("select * from temp_purchase where temp_item_user = '".$user_id."' and temp_purchase_id = '".$id."'");
         $result = $query->result();
         return $result;
    }

    public function get_po_footer()
    {
        $user_id = $_SESSION['user_id'];   
         $query = $this->db->query("select sum(temp_item_total) as sub_total from temp_po where temp_item_user = '".$user_id."'");
         $result = $query->result();
         return $result;
    }

    public function get_purchase_footer()
    {
         $user_id = $_SESSION['user_id'];   
         $query = $this->db->query("select sum(temp_item_total) as sub_total, temp_invoice_po from temp_purchase where temp_item_user = '".$user_id." ' group by temp_invoice_po");
         $result = $query->result();
         return $result;
    }

    public function get_po_header($po_id)
    {  
         $query = $this->db->query("select * from hd_po where hd_po_id = '".$po_id."'");
         $result = $query->result();
         return $result;
    }

     public function get_last_number_po()
    {
        $query = $this->db->query("select hd_po_id, hd_po_invoice from hd_po order by hd_po_id desc limit 1");
        $result = $query->result();
        return $result;
    }

     public function get_last_number_purchase()
    {
        $query = $this->db->query("select hd_purchase_id, hd_purchase_invoice from hd_purchase order by hd_purchase_id desc limit 1");
        $result = $query->result();
        return $result;
    }

    public function getPoHd($hd_po_id)
    {
        $query = $this->db->query("select * from hd_po a, master_supplier b, master_user c where a.hd_po_supplier_id = b.supplier_id and  a.hd_po_creted_by = c.user_id and hd_po_id = '".$hd_po_id."'");
        $result = $query->result();
        return $result;
    }

    public function getPurchaseHd($hd_purchase_id)
    {
        $query = $this->db->query("select * from hd_purchase a, master_supplier b, master_user c where a.hd_purchase_supplier_id = b.supplier_id and  a.hd_purchase_creted_by = c.user_id and hd_purchase_id = '".$hd_purchase_id."'");
        $result = $query->result();
        return $result;
    }

    public function getPoDetail($dt_hd_invoice)
    {
        $query = $this->db->query("select * from dt_po a, master_item b where a.dt_item_id = b.item_id and dt_hd_invoice = '".$dt_hd_invoice."'");
        $result = $query->result();
        return $result;
    }

     public function getCountpo($dt_hd_invoice)
    {
        $query = $this->db->query("select count(*) as total_row from dt_po a, master_item b where a.dt_item_id = b.item_id and dt_hd_invoice = '".$dt_hd_invoice."'");
        $result = $query->result();
        return $result;
    }

    public function getPurchaseDetail($dt_hd_invoice)
    {
        $query = $this->db->query("select * from dt_purchase a, master_item b where a.dt_item_id = b.item_id and dt_hd_invoice = '".$dt_hd_invoice."'");
        $result = $query->result();
        return $result;
    }

    public function get_header_po($id)
    {
        $query = $this->db->query("select * from hd_po where hd_po_id = '".$id."'");
        $result = $query->result();
        return $result;
    }

    public function get_po_list()
    {
        $query = $this->db->query("select * from hd_po where hd_po_status = 'Pending'");
        $result = $query->result();
        return $result;
    }

    public function getPoAll($id)
    {
        $query = $this->db->query("select * from hd_po a, dt_po b  where a.hd_po_invoice = b.dt_hd_invoice and hd_po_id = '".$id."'");
        $result = $query->result();
        return $result;
    }

    public function check_po($item_id_check, $po_number_invoice)
    {  
         $query = $this->db->query("select * from dt_po where dt_hd_invoice = '".$po_number_invoice."' and dt_item_id = '".$item_id_check."'");
         $result = $query->result();
         return $result;
    }




}