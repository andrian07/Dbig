<?php defined('BASEPATH') OR exit('No direct script access allowed'); 

class M_loan extends CI_Model { 


	public function insertloan($data_insert)
	{
		$this->db->insert('tbl_loan', $data_insert);
	}

    public function update_debt_remaining($employee_id, $new_debt)
    {
        $this->db->set('loan_debt_remaining', $new_debt);
        $this->db->where('employee_id', $employee_id);
        $this->db->update('master_employee');
    }

	public function get_loan_employee()
	{
		$query = $this->db->query("select * from master_employee where  is_deleted = 'N'");
        $result = $query->result();
        return $result;
	}

    public function get_last_number_loan()
    {
        $query = $this->db->query("select hd_transaction, transaction_invoice from hd_transaction order by hd_transaction desc limit 1");
        $result = $query->result();
        return $result;
    }

    public function get_loan_payment($id)
    {
        $query = $this->db->query("select * from tbl_loan a, master_employee b where a.loan_employee_id = b.employee_id and a.is_deleted = 'N' and loan_employee_id = '".$id."' order by a.created_at desc");
        $result = $query->result();
        return $result;
    }

    public function get_remaining_loan($id)
    {
        $query = $this->db->query("select * from  master_employee  where employee_id = '".$id."'");
        $result = $query->result();
        return $result;
    }



}