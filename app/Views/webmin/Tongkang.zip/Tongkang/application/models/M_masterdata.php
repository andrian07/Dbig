<?php defined('BASEPATH') OR exit('No direct script access allowed'); 

class M_masterdata extends CI_Model { 

    public function insertemployee($data_insert)
    {
        $this->db->insert('master_employee', $data_insert);
    }

    public function insertweight($data_insert)
    {
        $this->db->insert('master_weight', $data_insert);
    }

    public function insertship($data_insert)
    {
        $this->db->insert('master_ship', $data_insert);
    }

    public function insertsupplier($data_insert)
    {
        $this->db->insert('master_supplier', $data_insert);
    }

    public function insertcustomer($data_insert)
    {
        $this->db->insert('master_customer', $data_insert);
    }

    public function insertitem($data_insert)
    {
         $this->db->insert('master_item', $data_insert);
    }

    public function deleteemployee($employee_id)
    {
        $this->db->set('is_deleted', 'Y');
        $this->db->where('employee_id', $employee_id);
        $this->db->update('master_employee');
    }

    public function deleteitem($item_id)
    {
        $this->db->set('is_deleted', 'Y');
        $this->db->where('item_id', $item_id);
        $this->db->update('master_item');
    }

    public function deleteweight($weight_id)
    {
        $this->db->set('is_deleted', 'Y');
        $this->db->where('weight_id', $weight_id);
        $this->db->update('master_weight');
    }

    public function deleteship($ship_id)
    {
        $this->db->set('is_deleted', 'Y');
        $this->db->where('ship_id', $ship_id);
        $this->db->update('master_ship');
    }

     public function deletesupplier($supplier_id)
    {
        $this->db->set('is_deleted', 'Y');
        $this->db->where('supplier_id', $supplier_id);
        $this->db->update('master_supplier');
    }

    public function deletecustomer($customer_id)
    {
        $this->db->set('is_deleted', 'Y');
        $this->db->where('customer_id', $customer_id);
        $this->db->update('master_customer');
    }
    
    public function editemployee($data_insert, $employee_id)
    {
        $this->db->set($data_insert);
        $this->db->where('employee_id', $employee_id);
        $this->db->update('master_employee');
    }

    public function editcustomer($data_insert, $customer_id)
    {
        $this->db->set($data_insert);
        $this->db->where('customer_id', $customer_id);
        $this->db->update('master_customer');
    }

    public function editship($data_insert, $ship_id)
    {
        $this->db->set($data_insert);
        $this->db->where('ship_id', $ship_id);
        $this->db->update('master_ship');
    }

    public function editweight($data_insert, $weight_id)
    {
        $this->db->set($data_insert);
        $this->db->where('weight_id', $weight_id);
        $this->db->update('master_weight');
    }

    public function edititem($data_insert, $item_id)
    {
        $this->db->set($data_insert);
        $this->db->where('item_id', $item_id);
        $this->db->update('master_item');
    }

    public function editsupplier($data_insert, $supplier_id)
    {
        $this->db->set($data_insert);
        $this->db->where('supplier_id', $supplier_id);
        $this->db->update('master_supplier');
    }

    public function get_employee()
    {
        $query = $this->db->query("select * from master_employee where is_deleted = 'N'");
        $result = $query->result();
        return $result;
    }
     public function get_customer()
    {
        $query = $this->db->query("select * from master_customer where is_deleted = 'N'");
        $result = $query->result();
        return $result;
    }


    public function get_ship()
    {
       $query = $this->db->query("select * from master_ship where is_deleted = 'N'");
        $result = $query->result();
        return $result; 
    }

    public function get_ship_transaction()
    {
        $query = $this->db->query("select * from master_ship where is_deleted = 'N' and is_rent = 'N'");
        $result = $query->result();
        return $result;
    }

     public function get_supplier()
    {
        $query = $this->db->query("select * from master_supplier where is_deleted = 'N'");
        $result = $query->result();
        return $result;
    }

    public function get_item()
    {
        $query = $this->db->query("select * from master_item a, master_weight b where a.item_weight_id = b.weight_id and a.is_deleted = 'N'");
        $result = $query->result();
        return $result;
    }

    public function get_weight()
    {
        $query = $this->db->query("select * from master_weight where is_deleted = 'N'");
        $result = $query->result();
        return $result;
    }

    public function get_warehouse()
    {
        $query = $this->db->query("select * from master_warehouse where is_deleted = 'N'");
        $result = $query->result();
        return $result;
    }

    public function get_last_number()
    {
        $query = $this->db->query("select employee_id, employee_code from master_employee where is_deleted = 'N' order by employee_id desc");
        $result = $query->result();
        return $result;
    }

    public function get_last_number_ship()
    {
        $query = $this->db->query("select ship_id, ship_code from master_ship where is_deleted = 'N' order by ship_id desc");
        $result = $query->result();
        return $result;
    }

    public function get_last_number_supplier()
    {
        $query = $this->db->query("select supplier_id, supplier_code from master_supplier where is_deleted = 'N' order by supplier_id desc");
        $result = $query->result();
        return $result;
    }

}