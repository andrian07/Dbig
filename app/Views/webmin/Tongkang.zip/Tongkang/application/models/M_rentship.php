<?php defined('BASEPATH') OR exit('No direct script access allowed'); 

class M_rentship extends CI_Model { 



	public function get_rentship()
	{
		$query = $this->db->query("select * from hd_transaction a, master_customer b where a.transaction_customer_id = b.customer_id");
        $result = $query->result();
        return $result;
	}


}