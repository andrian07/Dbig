<?php defined('BASEPATH') OR exit('No direct script access allowed'); 

class M_shiping extends CI_Model { 


	public function inserttempshipping($data_insert)
	{
		$this->db->insert('temp_transaction', $data_insert);
	}

	public function insertdttransaction($data_insert_dt)
	{
		$this->db->insert('dt_transaction', $data_insert_dt);
	}

	public function insertheadershipping($data_insert)
	{
		$this->db->insert('hd_transaction', $data_insert);
	}

	public function edittempshipping($data_insert)
    {   
        $temp_purchase_id = $data_insert['temp_purchase_id'];
        $this->db->set($data_insert);
        $this->db->where('temp_purchase_id', $temp_purchase_id);
        $this->db->update('temp_transaction');
    }

    public function updateshipstatus($ship_id)
    {
        $this->db->set('is_rent', 'Y');
        $this->db->where('ship_id', $ship_id);
        $this->db->update('master_ship');
    }

    public function deleteTempShiping($temp_purchase_id)
    {
        $this->db->where('temp_purchase_id', $temp_purchase_id);
        $this->db->delete('temp_transaction');
    }

    public function clearTempShipping($userid)
    { 
        $this->db->where('user_id', $userid);
        $this->db->delete('temp_transaction');
    }

    public function get_shiping()
    {
        $query = $this->db->query("select * from hd_transaction a, master_customer b where a.transaction_customer_id = b.customer_id");
        $result = $query->result();
        return $result;
    }

    public function get_temp_transaction($user_id)
    {
      $query = $this->db->query("select * from temp_transaction a, master_ship b where a.transaction_ship_id = b.ship_id and user_id = '".$user_id."'");
      $result = $query->result();
      return $result;
  }

  public function get_shipping_footer()
  {
    $user_id = $_SESSION['user_id'];   
    $query = $this->db->query("select transaction_type, sum(transaction_total) as sub_total from temp_transaction where user_id = '".$user_id."'");
    $result = $query->result();
    return $result;
}

public function get_last_number_shipping()
{
    $query = $this->db->query("select hd_transaction, transaction_invoice from hd_transaction order by hd_transaction desc limit 1");
    $result = $query->result();
    return $result;
}

public function getShipingHd($hd_transaction)
{
    $query = $this->db->query("select * from hd_transaction a, master_customer b, master_user c where a.transaction_customer_id = b.customer_id and a.transaction_created_by = c.user_id and hd_transaction  = '".$hd_transaction."'");
    $result = $query->result();
    return $result;
}

public function getShipingDetail($transaction_invoice)
{
 $query = $this->db->query("select * from dt_transaction a, master_ship b where  a.transaction_ship_id = b.ship_id and transaction_invoice = '".$transaction_invoice."'");
 $result = $query->result();
 return $result;
}

}