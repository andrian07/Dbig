<?php

class M_user extends CI_Model {

    public function get_admin_by_username($username, $password){
        $query = $this->db->query("select * from master_user where user_name = '".$username."' and user_password = '".$password."' and is_active = 'Y'");
        $result = $query->result();
        return $result;
    }

}

?>